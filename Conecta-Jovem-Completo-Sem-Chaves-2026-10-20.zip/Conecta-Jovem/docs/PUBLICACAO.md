# Publicação e Gmail

O aplicativo está publicado em https://conecta-jovem-two.vercel.app, no projeto Vercel conecta-jovem, equipe beckerr11s-projects. Não é necessário comprar domínio para usar esse endereço HTTPS.

## Configuração concluída

- API Express em Vercel Functions, região gru1, Node 24.
- Contas, perfis, candidaturas, favoritos e anúncios persistidos no PostgreSQL Neon.
- Variáveis privadas do servidor na Vercel; nenhuma credencial é enviada ao JavaScript do navegador.
- Agendamento diário às 09:00 UTC (06:00 em São Paulo), protegido por CRON_SECRET. Consultas ao catálogo também acionam atualização em segundo plano quando o último sucesso tem mais de seis horas; tentativas respeitam intervalo mínimo de uma hora, inclusive entre instâncias.
- Cadastro/candidatura/etapas/notificações validados em PostgreSQL isolado. HTTPS, login e catálogo conferidos na hospedagem.

## Gmail configurado

1. Crie a conta Gmail que fará os envios.
2. Ative a verificação em duas etapas.
3. Gere uma senha de app em https://myaccount.google.com/apppasswords.
4. Preencha apenas no arquivo .env local, sem colocar a senha no chat:

```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=465
SMTP_USER=seu-email@gmail.com
SMTP_PASSWORD=senha_de_app_sem_espacos
EMAIL_FROM=
APP_PUBLIC_URL=https://conecta-jovem-two.vercel.app
```

5. Execute `npm run publish-env` e `vercel --prod --yes` para atualizar as variáveis privadas e aplicar a configuração.
6. Use "Esqueci minha senha" com uma conta sua cadastrada no produto. Confirme o recebimento e teste o link de recuperação. O proprietário confirmou o recebimento da recuperação na hospedagem. O remetente atual é conectajovememailreserch@gmail.com, configurado localmente e na Vercel com autenticação SMTP por TLS validada. Após a troca do remetente, confira novamente o recebimento de uma recuperação.

As credenciais Gmail estão ativas na implantação atual. Se o serviço for desconfigurado, a recuperação pública informa a indisponibilidade sem simular envio.

## Manutenção

- `npm run check-db`: confirma conexão e contagens PostgreSQL.
- `npm run backup`: snapshot consistente em JSON em data/backups (arquivo privado, contém dados de contas). É um snapshot de dados; restauração exige importação controlada ou restauração pelo Neon.
- `npm run migrate`: aplica o schema versionado usando conexão direta.
- `npm run admin`: redefine a senha administrativa no banco ativo e invalida suas sessões. Guarde a senha gerada.
- `npm test`: validação isolada local. Testes PostgreSQL usam exclusivamente a branch de verificação.

Os arquivos SQLite anteriores e o backup pré-migração foram preservados. Eles não são usados pela implantação pública.
