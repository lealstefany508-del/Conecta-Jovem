# Verificação do pacote de compartilhamento

Data: 20/10/2026. Ambiente: Windows, Node v26.7.0; o projeto declara Node 24.x como versão recomendada.

- npm ci --no-audit --no-fund: concluído; houve aviso de versão do Node diferente de 24.x.
- npm run build: concluído (Vite 7.3.6).
- npm test: 24 testes aprovados, zero falhas, zero ignorados.
- Execução na cópia separada sem .env, banco ou credenciais do autor.
- Não foram repetidos testes com serviços remotos: PostgreSQL, carga Neon, restauração remota, entrega Gmail e catálogo Adzuna precisam de credenciais próprias.
- Arquivo final conferido quanto a integridade ZIP, hashes do manifesto, caminhos proibidos e ocorrência dos valores privados dos arquivos de ambiente originais.

Não foram incluídos bancos, backups, sessões, acessos administrativos, .env privados, .neon, .vercel, .git, .agents, skills-lock.json, node_modules, dist, logs ou capturas históricas. Código, migrações, testes, documentação, lockfile e PDF de requisitos estão incluídos. Dependências e build são reproduzidos com npm ci e npm run build.

A senha Testing2026!safe e valores TEST-ONLY encontrados nos testes são fixtures públicas de teste isolado, não acessos do autor. Não reutilize essas senhas na sua instalação.
