# Evolução do produto

O escopo autorizado inclui recuperação real, busca, alertas opcionais, moderação de empresas, PWA, observabilidade, restauração e privacidade/acessibilidade.

Empresas precisam de aprovação administrativa para publicar e abrir vagas. Mudanças de identificação pedem nova análise. A aprovação não equivale a validação automática em um registro oficial. O administrador analisa site, identificação e vínculo, registra motivo e pode suspender ou rejeitar.

Alertas exigem opção explícita e confirmação de e-mail. Os critérios usam título, área, localização e tipo; informações ausentes não são inventadas. Cada usuário recebe no máximo um resumo por dia, com até dez anúncios novos. O ledger evita repetir anúncios já enviados. Nenhum destinatário de teste é criado no banco de produção.

PWA inclui manifest, ícones, abertura independente e página offline. API, perfil, candidaturas e tokens não são cacheados. A instalação depende do navegador; iPhone usa Compartilhar → Adicionar à Tela de Início. Ver referência oficial: https://web.dev/learn/pwa/web-app-manifest.

Eventos operacionais registram apenas categoria, rota sanitizada e horário. Não registram corpo de requisição, mensagens, token, senha ou perfil. Retenção de eventos: sete dias. O painel administrativo mostra eventos e solicitações sobre dados. `npm run monitor -- --watch` verifica a saúde pública continuamente enquanto o processo local estiver ativo e envia alertas de falha e recuperação para a própria conta do projeto. Backup remoto criptografado, restauração e limites operacionais estão descritos em [OPERACOES.md](OPERACOES.md).

Snapshots privados são gerados por `npm run backup`. `node scripts/restore-postgres.mjs caminho-do-snapshot.json` exige RESTORE_DATABASE_URL de uma branch isolada vazia. O comando bloqueia o endpoint de produção e valida contagens e sequências. Para substituir a produção, valide primeiro o snapshot e use o fluxo de restauração controlado do Neon.

A política pública descreve o tratamento implementado e permite exportação, edição, exclusão e solicitações à administração. Revisão técnica de privacidade não constitui declaração de conformidade jurídica integral. O proprietário indicou Stefany Ferreira dos Santos como responsável, autorizou o contato público conectajovememailreserch@gmail.com e definiu retenção de sete dias. A rotina IMAP de seleção autenticada dos backups está ativa. Referência ANPD para estudantes adolescentes: https://www.gov.br/anpd/pt-br/assuntos/noticias/anpd-divulga-enunciado-sobre-o-tratamento-de-dados-pessoais-de-criancas-e-adolescentes.

## Validações realizadas

Snapshot de produção restaurado em schema vazio da branch de verificação, com contagens conferidas. Testes de API e navegador usam schemas isolados; anúncios e contas de teste não entram na produção. A entrega do e-mail de recuperação foi confirmada pelo proprietário. O remetente foi transferido para conectajovememailreserch@gmail.com no ambiente local e na Vercel, com autenticação SMTP por TLS validada. Esse endereço foi autorizado como contato público de privacidade.

O envio de alertas é dividido em lotes de até dois destinatários por execução, para respeitar o tempo da função. O agendamento diário e acessos ao catálogo drenam destinatários elegíveis, com trava persistente e limite de um resumo por usuário a cada 24 horas. Não há promessa de entrega instantânea.
