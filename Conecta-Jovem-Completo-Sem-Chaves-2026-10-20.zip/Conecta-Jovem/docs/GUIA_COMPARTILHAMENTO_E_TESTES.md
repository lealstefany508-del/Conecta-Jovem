# Conecta Jovem — instalação e roteiro completo de testes

Preparado em 20/10/2026. Leia este guia antes dos relatórios históricos. O ZIP contém código-fonte, dependências declaradas com lockfile, testes, migrações, documentação e o PDF de requisitos. Não contém credenciais, bancos, usuários, sessões, backups, vínculos Vercel/Neon nem dependências instaladas. Capturas históricas foram omitidas para não compartilhar dados de contas; os testes geram novas capturas.

Relatórios em docs descrevem verificações anteriores do projeto original. Números, disponibilidade de vagas e estado dos serviços não são uma verificação atual desta nova instalação. Links públicos nos relatórios são referências históricas, não acesso às contas do autor. Nome da responsável e contato de privacidade publicados no código/documentação não são credenciais; substitua-os pelos seus antes de operar uma instalação independente (public/privacidade.html e server/age-policy.js).

## 1. Instalar e iniciar, sem serviço externo

Requisitos: Node.js **24.x**, npm, navegador e internet para baixar as dependências. Windows/PowerShell é usado nos exemplos. Extraia o ZIP completamente; abra o terminal na pasta que contém package.json. Não execute dentro do visualizador do ZIP.

```powershell
node --version
npm --version
npm ci
npx playwright install chromium
Copy-Item .env.example .env
npm run build
npm run dev
```

Deixe DATABASE_URL e DATABASE_URL_UNPOOLED vazias no .env para usar SQLite local. APP_PUBLIC_URL pode ser http://localhost:3000. Não defina NODE_ENV=production para HTTP local: cookies de produção exigem HTTPS. Abra http://localhost:3000. Ctrl+C encerra o servidor. npm run develop reinicia o servidor ao editar seus arquivos; alterações da interface precisam de novo npm run build e atualização da página.

O primeiro início cria data/conecta.sqlite, sem estudantes, empresas ou vagas fictícias. A conta administrativa padrão é admin@conecta.local; a senha aleatória inicial aparece no terminal. Guarde-a privadamente. É possível definir ADMIN_EMAIL e ADMIN_PASSWORD no .env **antes do primeiro início**; alterar essas variáveis depois não troca a conta existente. Não use as senhas literais das fixtures dos testes para sua instalação.

Para trocar a senha do administrador padrão já criado, em outro terminal na mesma pasta:

```powershell
npm run admin
```

Se usou outro endereço: npm run admin -- seu-admin@example.com. O comando mostra a nova senha e invalida sessões anteriores. Acesse http://localhost:3000/admin. Cadastro público não concede papel administrativo.

## 2. Testes automatizados locais

Depois do build e da instalação do Chromium, execute na raiz, preferencialmente em um terminal sem variáveis de banco de testes herdadas:

```powershell
npm test
```

São 24 testes na versão entregue. Critério de sucesso: zero falhas e código de saída 0. Usam SQLite temporário e transportes de e-mail simulados; não exigem Gmail, Adzuna ou Neon e não comprovam entrega de mensagens reais. Os testes de navegador iniciam seus próprios servidores. Execute as suítes em sequência, sem outra cópia dos testes usando as mesmas portas.

| Arquivo | O que verifica | Porta de teste, se usada |
| --- | --- | --- |
| tests/system.test.js | Contas, autenticação, vagas, permissões empresariais, candidatura única, prazos, etapas, recuperação e histórico | 3101 |
| tests/browser.test.js | Jornada estudante/empresa, formulário, perfil, publicação, candidatura e interface responsiva | 3102 |
| tests/accessibility.test.js | Navegação e verificações axe de acessibilidade | 3103 |
| tests/compliance.test.js | Idade, autorização de responsável, privacidade e regras adicionais | 3106 |
| tests/admin.test.js | Sete seções administrativas, moderação, correções, auditoria e bloqueio de usuário comum | 3108 |
| tests/product.test.js | Favoritos, notificações, preferências e controles de dados | — |
| tests/normalization.test.js | Migração, integridade e modelo profissional normalizado | — |
| tests/source.test.js | Conector externo, cache, fonte e filtros | — |
| tests/mail.test.js | Contrato SMTP/Resend, usando transporte simulado | — |
| tests/operations.test.js | Operações, snapshots cifrados e monitoramento | — |
| tests/retention.test.js | Seleção autenticada de backups e preservação de conteúdo estranho/recente | — |

Para repetir somente uma suíte:

```powershell
node --test tests/admin.test.js
node --test tests/browser.test.js
```

Outras verificações locais, depois de iniciar a aplicação pelo menos uma vez:

```powershell
npm run build
npm run check-db
npm run backup
node scripts/pilot-automated.mjs
```

check-db deve indicar integridade válida e ausência de violações de chaves estrangeiras. backup produz uma cópia local em data/backups. Em SQLite, o arquivo de backup contém dados legíveis: mantenha-o privado. O piloto automatizado gera docs/evidencias/piloto-automatizado.json com atores simulados; não substitui feedback de participantes.

## 3. Roteiro manual — estudante, empresa e admin

Use sua instalação local e contas de exercício identificadas. Para testar e-mails reais, utilize caixas que você controla. Use janelas/perfis de navegador separados para cada papel.

1. **Cadastro e acesso:** cadastre um estudante adulto; confirme rejeição de e-mail repetido, senha inválida, entrada com senha errada e logout. Sem SMTP, recuperação real fica indisponível; isso não indica que os testes simulados falharam.
2. **Perfil:** preencha cidade, curso, instituição, semestre, objetivo, interesses, disponibilidade e modalidade; inclua duas formações, projetos, cursos, idiomas e habilidades. Salve, recarregue e confira persistência. Experiência, foto e telefone são opcionais. Teste erro de campo sem perder o preenchimento.
3. **Empresa:** crie uma conta empresarial e preencha a organização. Antes da aprovação, publicar deve ser bloqueado. No admin, analise e aprove a empresa, informando motivo quando solicitado.
4. **Vaga interna:** com a empresa aprovada, crie uma vaga de exercício com prazo futuro, atividades, requisitos, benefícios, modalidade, cidade, bolsa, jornada, cursos e habilidades. Revise e confirme. Confira edição, pausa, reabertura e encerramento.
5. **Busca e afinidade:** com o estudante, busque título/área, aplique cidade/curso/modalidade/bolsa/jornada e teste nenhum resultado. Confira a explicação do percentual de afinidade, sem promessa de contratação. Salve e remova um favorito.
6. **Candidatura:** candidate-se à vaga aberta com perfil completo. Deve existir uma candidatura, histórico inicial e notificação. Tentar novamente não pode duplicar. Perfil incompleto, vaga pausada/encerrada/vencida e perfil privado devem bloquear a ação.
7. **Recrutamento:** na empresa, filtre candidatos por vaga/etapa, consulte o perfil autorizado e avance Enviada → Em análise → Pré-selecionada → Entrevista → Aprovada. Confira histórico e notificação do estudante. Teste alternativas Não selecionada e cancelamento antes do resultado final com outras candidaturas de exercício. Transição inválida deve ser recusada.
8. **Isolamento:** cadastre outra empresa; ela não deve acessar candidatos/vagas privativas da primeira. Adicione/suspenda/revogue um recrutador e confira a perda de permissão. O último proprietário ativo não pode ser removido.
9. **Admin:** confira Contas, Empresas, Vagas, Denúncias, Candidaturas, Operação e Auditoria, suas buscas e estados vazios. Teste suspensão/reativação, moderação, denúncia e resposta de privacidade com motivos. Correção excepcional de resultado final precisa de motivo, histórico e auditoria. Um estudante acessando /admin não ganha poderes de admin.
10. **Privacidade:** confira preferências, visibilidade, exportação dos próprios dados, solicitação à administração e exclusão de uma conta de exercício. Não use sua única conta de teste para todos os cenários destrutivos.
11. **Idade:** abaixo de 16 deve ser bloqueado. Aos 16/17, candidatura depende de confirmação explícita do responsável por e-mail. Esse percurso real exige SMTP e duas caixas sob seu controle; token vencido/usado não deve liberar acesso novamente.
12. **Interface:** confira 360, 768 e 1280 pixels; use Tab, Shift+Tab, Enter e Escape em formulários e modais. Confira carregamento, falha, vazio e sucesso. Teste PWA/tela offline; perfis e API não devem ficar disponíveis em cache offline.

## 4. Conectar suas próprias integrações

Edite .env somente na sua máquina. Reinicie o servidor após alterações. Não coloque segredos em src, public, variáveis VITE_*, Git, prints ou mensagens.

| Serviço | Variáveis/configuração | Como confirmar |
| --- | --- | --- |
| Adzuna | ADZUNA_APP_ID, ADZUNA_APP_KEY; ADZUNA_LOCATION opcional | Crie suas credenciais no portal developer.adzuna.com. Confira operação/admin, sincronização e cards com fonte e link Adzuna. Sem chave, o catálogo externo fica vazio; não são geradas vagas falsas. |
| Gmail | SMTP_HOST=smtp.gmail.com, SMTP_PORT=465, SMTP_USER, SMTP_PASSWORD; APP_PUBLIC_URL; EMAIL_FROM vazio ou remetente autorizado | Use sua conta com verificação em duas etapas e senha de app. Cadastre uma conta controlada e solicite recuperação. Confirme recebimento, link e uso único. Não basta o servidor aceitar o envio. |
| Resend, alternativa ao Gmail | RESEND_API_KEY, EMAIL_FROM verificado, APP_PUBLIC_URL | Configure remetente/domínio na sua conta e repita a recuperação. Gmail tem preferência se ambos estiverem configurados. |
| Neon PostgreSQL | DATABASE_URL com pool; DATABASE_URL_UNPOOLED direta | Use banco próprio; execute npm run migrate, npm run check-neon e npm run check-db. Deixe DB_PATH ausente/vazio para selecionar PostgreSQL. |
| Backup remoto | OPERATIONS_EMAIL igual ao próprio SMTP_USER; BACKUP_ENCRYPTION_KEY, CRON_SECRET | Gere chave privada de 32 bytes em hexadecimal; guarde-a separada do backup. Veja docs/OPERACOES.md. |

Gerar cada segredo aleatório novo, sem reutilizar os do autor:

```powershell
node --input-type=module -e "import {randomBytes} from 'node:crypto'; console.log(randomBytes(32).toString('hex'))"
```

Use um resultado para BACKUP_ENCRYPTION_KEY e outro para CRON_SECRET. Não substitua a chave de backups existentes sem preservar a antiga. BACKUP_RETENTION_ENABLED começa em 0; só ative após validar backup recente e IMAP na sua conta. Essa rotina pode excluir seus backups vencidos autenticados. Simulação: node scripts/retain-backups.mjs --dry-run. Execução sem --dry-run efetua retenção.

## 5. PostgreSQL, carga e restauração em ambiente separado

Esses testes não estão incluídos na execução local sem credenciais. Crie uma branch/banco de testes próprio, com endpoint diferente do banco da sua aplicação. Não use a branch de produção para fixtures. Em .env, DATABASE_URL identifica seu banco principal; crie .env.neon-test contendo **somente a connection string da branch de testes**, sem nome de variável ou aspas, em uma linha. Esse formato difere de .env.

```powershell
npm run test-postgres
node scripts/verify-load.mjs
node scripts/verify-restore.mjs
```

- test-postgres executa cinco suítes (10 testes na versão entregue) em schemas de verificação. **Remove e recria** system_verification, product_verification, compliance_verification, browser_verification e admin_verification. Não mantenha dados úteis nesses schemas e não execute duas cópias em paralelo.
- verify-load cria/remove um schema próprio, gera 100 sessões distintas, 20 vagas internas e 100 externas de exercício, executa 600 consultas e escreve docs/evidencias/carga.json. Sucesso: zero erros e máximo abaixo de 3000 ms. Mede API local + Neon, não 100 navegadores na hospedagem pública.
- verify-restore cria schemas isolados, verifica conteúdo, sequências, recusa de destino preenchido e deduplicação de backup. Sucesso: verified/restored verdadeiros e término sem erro. Não restaura seu banco real.

Para uma restauração operacional, leia docs/OPERACOES.md e scripts/restore-postgres.mjs. O destino precisa estar vazio, com tabelas migradas, endpoint diferente do principal e RESTORE_DATABASE_URL configurada. npm run migrate também cria administrador: para preparar destino realmente vazio, aplique as migrações SQL em um schema vazio sem semear usuários. Não execute a restauração como teste exploratório no banco principal. O comando é npm run restore -- caminho-do-snapshot.backup.json; backup cifrado exige a chave correspondente.

## 6. Cache real, publicação e monitoramento

`node tests/verify-live.mjs` exige SQLite local já populado por sua própria Adzuna. Usa cópia temporária e porta 3103; não funciona com banco vazio nem é a ferramenta para cache exclusivo de PostgreSQL. Gera capturas em docs/screenshots. Não o execute junto da suíte de acessibilidade, que usa a mesma porta.

Para publicar uma cópia: use sua conta Vercel e um projeto novo, Node 24 e PostgreSQL próprio. A pasta .vercel não foi enviada, portanto não há vínculo automático ao projeto original. Configure no painel Vercel as variáveis de seu ambiente (incluindo segredos e APP_PUBLIC_URL HTTPS), confirme o projeto escolhido e publique. Consulte vercel.json e docs/PUBLICACAO.md como referência, substituindo nomes/IDs históricos. Não publique SQLite na Vercel. Nunca use apenas as variáveis VITE_* para segredos.

Depois de configurar a própria hospedagem, administrador, Gmail/backup e catálogo real, execute node scripts/verify-deployment.mjs com APP_PUBLIC_URL, ADMIN_EMAIL e ADMIN_PASSWORD do seu ambiente. O script exige HTTPS, anúncios Adzuna e registro de backup aceito; não é um smoke test genérico para instalação vazia. Faz login/logout, percorre admin em três larguras e consulta recuperação para endereço inexistente. Só aponte para ambiente que você administra.

`npm run monitor` consulta a saúde do APP_PUBLIC_URL e usa suas configurações operacionais. O monitor local para com o computador desligado. Os scripts start-monitor.ps1 e install-monitor-startup.ps1 são específicos do Windows; o segundo instala início ao login e só deve ser executado se você quiser isso. Um monitor externo gratuito precisa ser criado/ativado na sua própria conta. scripts/request-uptime.mjs solicita monitor para seu OPERATIONS_EMAIL e URL; não é teste local nem acesso ao monitor original.

`npm run publish-env` envia valores à Vercel vinculada usando o CLI global instalado no caminho Windows esperado pelo script. É uma ferramenta de alteração remota, não um teste; prefira configurar pelo painel e confirme a conta/projeto antes de usá-la. neon.ts é opcional para o fluxo Neon CLI; a aplicação usa pg e suas variáveis, sem precisar receber o vínculo .neon do autor.

## 7. Diagnóstico rápido

| Sintoma | Ação |
| --- | --- |
| node:sqlite indisponível | Instale Node 24.x e reabra o terminal. |
| npm bloqueado pelo PowerShell | Use npm.cmd e npx.cmd nos mesmos comandos. |
| Chromium ausente | Execute npx playwright install chromium. No Linux pode ser necessário npx playwright install --with-deps chromium. |
| Porta em uso ou teste trava ao iniciar | Encerre a outra suíte/servidor que usa a porta; execute testes em sequência. |
| Interface antiga ou dist ausente | Repita npm run build, reinicie o servidor e atualize a página. |
| Login local não persiste | Remova NODE_ENV=production no HTTP local; confira localhost e limpe cookies da instalação antiga. |
| Sem vagas externas | Configure sua Adzuna e confira erro/atualização no admin; não confunda ausência de chave com defeito de dados. |
| Recuperação ou responsável indisponível | Confira SMTP e APP_PUBLIC_URL, senha de app e recebimento na sua caixa. |
| PostgreSQL recusado ou testes bloqueados | Confira endpoint, credenciais, TLS e branch isolada; não reutilize o endpoint principal em .env.neon-test. |
| Senha admin esquecida | Use npm run admin com o endereço da conta administrativa existente. |

## 8. Relatar a validação

Registre data, Node, sistema, banco, comando, resultado, logs sem segredos e telas sem dados privados. Evidências históricas não substituem suas execuções. Para aderência ao PDF, leia docs/CONFERENCIA_FINAL_PDF.md; o piloto humano, feedback e metas posteriores seguem pendentes no projeto original. Chat, agenda, currículo exportável e app nativo são evoluções futuras do PDF.

Use docs/PILOTO.md e docs/piloto-template.csv para participação real. Nunca apresente atores automatizados como participantes humanos, nem vagas de exercício como oportunidades reais. Guarde credenciais e dados gerados fora de qualquer novo ZIP de compartilhamento.
