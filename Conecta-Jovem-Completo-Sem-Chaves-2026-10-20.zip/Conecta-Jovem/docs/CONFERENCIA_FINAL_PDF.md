# Conferência final do PDF — 02/10/2026

Referência: Conecta_Jovem_Documentacao.pdf, versão 1.0, 14 páginas, lidas integralmente nesta revisão. Produto: https://conecta-jovem-two.vercel.app. Administração: https://conecta-jovem-two.vercel.app/admin.

**O MVP técnico está implementado e passou nos cenários verificados. A conclusão integral do plano da página 14 permanece pendente do piloto com participantes, coleta de feedback e definição de metas após esse piloto.** O proprietário informou que ainda não dispõe de participantes. Não há resultados humanos inventados.

Esta é a conferência atual. AUDITORIA_DOCUMENTACAO.md e as revisões anteriores de ENTREGA_DOCUMENTACAO.md preservam o histórico, incluindo números de verificações anteriores.

## Requisitos funcionais — página 6

| Requisito | Situação | Implementação e evidência |
| --- | --- | --- |
| RF01 — cadastro de estudante | Verificado | E-mail único e campos obrigatórios; server/index.js, tests/system.test.js. |
| RF02 — autenticação, saída e recuperação | Verificado | Hash, sessão, logout, recuperação de uso único e SMTP; tests/system.test.js, tests/compliance.test.js, tests/mail.test.js. Recebimento real de recuperação confirmado anteriormente pelo proprietário. |
| RF03 — empresa e recrutadores | Verificado | Cadastro, aprovação, vínculos autorizados e revogação; tests/system.test.js. |
| RF04 — perfil profissional | Verificado | Múltiplas formações, projetos, cursos, idiomas e habilidades; src/profile-editor.jsx, server/normalize.js, tests/normalization.test.js, tests/browser.test.js. Experiência, foto e telefone opcionais. |
| RF05 — gestão das próprias vagas | Verificado | Criar, editar, revisar, publicar, pausar e encerrar; autorização empresarial; tests/system.test.js, tests/browser.test.js. |
| RF06 — busca por título e área | Verificado | Busca textual normalizada e estados vazios; src/search.js, tests/source.test.js. |
| RF07 — filtros | Verificado | Cidade, curso, modalidade, salário e jornada; src/search.js, tests/source.test.js. Informação ausente em anúncio externo não é inventada. |
| RF08 — candidatura e duplicidade | Verificado | Perfil mínimo, vaga disponível, par estudante/vaga único e confirmação; tests/system.test.js, tests/browser.test.js. |
| RF09 — situação e histórico | Verificado | Consulta aos próprios processos e alterações; tests/system.test.js. |
| RF10 — compatibilidade explícita | Verificado | Critérios, pesos, dados ausentes e explicação; server/rules.js, tests/system.test.js. |
| RF11 — chat | Futuro | O PDF situa este recurso após o MVP. Não é apresentado como implementado. |
| RF12 — organização de candidatos | Verificado | Empresa consulta suas candidaturas, com agrupamento por vaga e filtro de etapa; src/main.jsx, tests/system.test.js, tests/browser.test.js. |
| RF13 — notificações internas | Verificado | Candidatura e mudança de etapa, leitura e preferências; server/product.js, tests/product.test.js. |
| RF14 — administração | Verificado | Contas, empresas, vagas, denúncias, candidaturas, operação e auditoria; src/admin.jsx, tests/admin.test.js. APIs negam acesso ao estudante. |
| RF15 — favoritos | Verificado | Salvar e remover vagas na conta; server/product.js, tests/product.test.js. |
| RF16 — visibilidade e exclusão | Verificado | Preferências, restrição do perfil e solicitação de exclusão; server/product.js, tests/product.test.js, tests/admin.test.js. |

Candidatura, compatibilidade e acompanhamento interno referem-se às vagas publicadas pelas empresas no Conecta Jovem. Anúncios Adzuna têm fonte e link reais; candidatura e andamento ocorrem na origem. A integração complementa os fluxos nativos, sem simular processos de empresas externas.

## Qualidade — página 7

| Requisito | Evidência e alcance |
| --- | --- |
| RNF01 — usabilidade e feedback | Rótulos, validação junto aos campos, valores preservados e estados de carregamento, vazio, falha e sucesso; tests/browser.test.js, tests/admin.test.js. Avaliação por pessoas depende do piloto. |
| RNF02 — proteção e autorização | Hash scrypt, HTTPS, cookie seguro, papel/vínculo no servidor, tokens e limitação de tentativas; tests/system.test.js, tests/compliance.test.js e verificação pública. |
| RNF03 — busca até 3 segundos, 100 usuários | Passou no cenário documentado: 100 sessões distintas, 600 respostas válidas, zero erros, máximo 585 ms. API local Node 26 + PostgreSQL Neon isolado e dados de exercício. Não mede 100 navegadores nem carga na Vercel pública. Evidência: evidencias/carga.json. |
| RNF04 — monitor, backup e restauração | UptimeRobot externo confirmado Up, intervalo de cinco minutos; backup cifrado diário, retenção autenticada e restauração isolada aprovada. tests/operations.test.js, tests/retention.test.js, scripts/verify-restore.mjs, OPERACOES.md. |
| RNF05 — responsividade | Percursos e seções administrativas em 360, 768 e 1280 pixels, inclusive na implantação; tests/browser.test.js, tests/admin.test.js, scripts/verify-deployment.mjs. |
| RNF06 — dados mínimos e visibilidade | Perfil restrito à candidatura autorizada; nascimento e dados do responsável excluídos da visualização empresarial; tests/product.test.js, tests/compliance.test.js. |
| RNF07 — separação de responsabilidades | Interface em src; regras, validação, normalização e persistência em módulos próprios de server; decisões e modelo documentados. |
| RNF08 — acessibilidade | Teclado, foco, rótulos e verificações automatizadas nos percursos cobertos; tests/accessibility.test.js, tests/browser.test.js, tests/admin.test.js. Não equivale a avaliação manual de todas as telas com todos os leitores de tela. |

## Regras de negócio — página 7

| Regra | Resultado verificado |
| --- | --- |
| RN01 | Candidatura exige sessão de estudante. |
| RN02 | Recrutador ativo só gerencia vagas da empresa autorizada. |
| RN03 | Banco e API impedem duplicidade estudante/vaga. |
| RN04 | Publicação exige campos obrigatórios válidos. |
| RN05 | Vaga pausada, encerrada ou vencida bloqueia candidatura. |
| RN06 | Alteração normal de etapa é empresarial, com histórico; exceção administrativa terminal exige motivo e auditoria, conforme página 9. |
| RN07 | Mudança de etapa produz notificação interna. |
| RN08 | Visibilidade e vínculo de candidatura restringem consulta ao perfil. |
| RN09 | Perfil sem experiência é permitido. |
| RN10 | Compatibilidade expressa afinidade, sem aprovação automática. |

Evidências: testes system, product, compliance e admin, incluindo tentativas negadas e histórico de correção.

## Casos de uso, interface e modelo — páginas 8 a 13

| Item | Resultado e referência |
| --- | --- |
| UC01 — montar perfil | Validação preserva preenchimento e permite formações/projetos/cursos/habilidades múltiplos; tests/browser.test.js. |
| UC02 — publicar vaga | Revisão antes de confirmar, campos e prazo validados; tests/browser.test.js, tests/system.test.js. |
| UC03 — candidatar | Confirmação, perfil incompleto direcionado ao preenchimento, duplicidade direcionada ao processo existente e indisponibilidade bloqueada; tests/browser.test.js, tests/system.test.js. |
| UC04 — atualizar etapa | Transições válidas, histórico e notificação; transição indevida bloqueada; tests/system.test.js, tests/admin.test.js. |
| UC05 — acompanhar | Histórico individual e estado vazio com ação; tests/browser.test.js, tests/system.test.js. |
| Jornadas e estados — p. 9 | Enviada → Em análise → Pré-selecionada → Entrevista → Aprovada; alternativa Não selecionada; cancelamento antes do término; encerramento preserva histórico. server/rules.js. |
| Compatibilidade — p. 10 | Curso 30%, habilidades 30%, disponibilidade 20%, modalidade/localidade 20%; critérios não utilizados saem do denominador; informação essencial ausente não gera percentual enganoso. Experiência e dados sensíveis não pontuam. |
| Telas e estados — p. 11 | Acesso, estudante, empresa e administração; identidade azul/branco/lilás, componentes arredondados, carregamento/vazio/erro/sucesso e confirmação. Evidências em screenshots. |
| Modelo — p. 12 | Entidades profissionais normalizadas, PK/FK, múltiplas formações, relações N:N e histórico anterior/novo. DER.md, DICIONARIO_DADOS.md, migração 003 e tests/normalization.test.js. JSON legado é arquivo de migração, sem uso como armazenamento profissional atual; cache externo tem escopo separado. |
| Tecnologia e privacidade — p. 13 | React, Node e PostgreSQL; permissões, visibilidade, política pública e identificação de Stefany Ferreira dos Santos. Mínimo de 16 anos e confirmação por e-mail do responsável abaixo de 18, conforme decisão do proprietário. |
| Aceitação — p. 13 | E-mail repetido, perfil sem experiência, candidatura válida/duplicada, vaga indisponível, outra empresa bloqueada, histórico/notificação e busca vazia exercitados. |

## Verificações repetidas nesta revisão

- `npm test`: **24 aprovados**, zero falhas.
- `npm run test-postgres`: **10 aprovados**, zero falhas, schemas isolados.
- `npm run build`: concluído.
- Restauração: 34 tabelas e 21 linhas de exercício; conteúdo, sequência, recusa de destino preenchido e deduplicação concorrente confirmados.
- Carga: 600 respostas HTTP 200, 100 sessões distintas, máximo 585 ms no cenário limitado descrito acima.
- Implantação: login admin, APIs, sete seções em três larguras, cookie seguro e ausência de erros JavaScript no percurso; **59 anúncios reais Adzuna** observados. Catálogo variável.
- Monitor: painel UptimeRobot 804157427 observado **Up**, verificação recente e resposta exibida de 233 ms. Esse valor é de saúde, não de carga.

Cadastro empresarial, recrutamento, candidatura, correção e restauração usam dados de exercício exclusivamente em ambientes isolados. Não foram criadas vagas ou empresas fictícias no catálogo público para aparentar atividade real. Implantação verificada: dpl_CcZyiVqfP74GzN5htFtHMajrFKwk.

## Fechamento ainda pendente — página 14

**Executar o piloto com estudantes e recrutadores, registrar feedback, analisar indicadores e definir/aprovar metas após o piloto.** Roteiro em [PILOTO.md](PILOTO.md), com modelo de coleta sem resultados fabricados. A automação de sete cenários registrada anteriormente é evidência técnica, não participação humana nem pesquisa de satisfação.

Cadastros, perfis, candidaturas e alterações fornecem dados para os indicadores previstos. Taxa de conclusão de tarefas por pessoas, facilidade percebida e metas posteriores precisam dessa avaliação. Eventuais correções apontadas pelo feedback devem integrar seu fechamento.

Chat, agenda de entrevistas, descoberta de interesses, currículo exportável e app nativo são evoluções futuras do documento, não pendências do MVP. PWA e exportação de dados em JSON não são anunciadas como equivalentes a esses recursos.
