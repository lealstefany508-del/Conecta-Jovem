# Decisões e escopo da entrega

## Origem dos requisitos

Referência: `Conecta_Jovem_Documentacao.pdf`, versão 1.0, 14 páginas. O MVP é web responsiva para estudantes buscando estágio e primeiro emprego. O proprietário autorizou operações reais, interface premium, vagas reais e integração externa, e posteriormente a resolução das lacunas da auditoria.

## Plataforma e persistência

React na interface, Express/Node.js 24 na API, PostgreSQL Neon no produto publicado na Vercel. SQLite permanece para desenvolvimento explicitamente local e testes temporários; a cópia anterior não é o banco da publicação. As operações aplicam autorização empresarial, unicidade, chaves estrangeiras e transações no servidor. Não há persistência de processos em localStorage.

O modelo normalizado e suas associações estão descritos em `DER.md` e `DICIONARIO_DADOS.md`. Migrações versionadas e backfill preservam os dados preexistentes; o arquivo legado serve à transição e não deve ser tratado como a fonte de edição do perfil normalizado.

## Operação e critérios

- Vagas internas são publicadas por recrutadores vinculados a empresas aprovadas. Aprovação é análise operacional, não certificação automática de CNPJ ou garantia da oferta.
- Vagas Adzuna mantêm crédito e link de origem. Não inventam remuneração, modalidade, formação ou compatibilidade. Candidatura externa não gera processo interno.
- Recuperação é integrada por Gmail SMTP. O proprietário confirmou recebimento na hospedagem; testes isolados validam expiração, uso único e invalidação de sessões. Conferência SMTP isolada não comprova chegada de cada mensagem à caixa de entrada.
- Público definido: 16 anos ou mais, com autorização de responsável para menores de 18. Responsável publicamente indicada pelo proprietário: Stefany Ferreira dos Santos. Conecta Jovem é o nome do produto; contato: conectajovememailreserch@gmail.com.
- Exportação, edição, visibilidade, exclusão de estudante e solicitações de privacidade fazem parte do produto. Exclusão empresarial exige transferência de responsabilidade e atendimento administrativo.
- Monitoramento, backup e restauração possuem procedimentos em `OPERACAO.md`; evidências de execução devem ser preservadas sem publicar credenciais ou dados pessoais.

## Validação e limites

`npm test` executa suites locais isoladas; `npm run test-postgres` repete jornadas em branch PostgreSQL separada. `node scripts/verify-load.mjs` usa 100 estudantes e cookies distintos, três rodadas por endpoint e volumes documentados; salva latência/erros em `evidencias/carga.json`. A execução isolada após a leitura em lote completou 600 respostas válidas, sem erros, máximo de 798 ms: meta técnica atendida nesse cenário. Isso não demonstra comportamento de 100 pessoas na Vercel. O JSON registra runtime e contagens de fixtures.

O piloto de pessoas está preparado em `PILOTO.md` e permanece pendente de participantes e autorização do proprietário. Indicadores e metas de produto não têm resultados inventados. Chat, contratos, pagamentos, app nativo e agenda de entrevistas permanecem fora do MVP.

