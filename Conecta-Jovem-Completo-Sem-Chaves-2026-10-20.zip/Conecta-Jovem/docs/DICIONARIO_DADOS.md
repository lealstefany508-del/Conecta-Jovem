# Dicionário de dados

Fonte: migrações SQL 001–003. `PK`: chave primária; `FK`: chave estrangeira; `UQ`: única; `?`: aceita NULL. TEXT comporta texto, inclusive UUID; INTEGER é inteiro; BIGINT é inteiro longo (época Unix em milissegundos nas colunas de prazo técnico); DOUBLE PRECISION é número aproximado. Datas de negócio são TEXT ISO; instantes de histórico são TEXT UTC ISO. Senhas contêm hash scrypt com salt, nunca senha aberta.

## Identidade, perfil e formação

| Tabela | Campos e tipos | Chaves, regras e finalidade |
| --- | --- | --- |
| users | id INTEGER; name/email/password/role TEXT; active INTEGER? | PK id identidade; UQ email; nome/e-mail/hash/papel obrigatórios. active padrão 1. Papel global validado na API. |
| student_details | user_id INTEGER; city/interest/objective/availability/modality/experience/phone/visibility/photo TEXT; notifications INTEGER; birth_date/guardian_email/guardian_token/guardian_confirmed_at/policy_version TEXT?; guardian_status TEXT; guardian_expires BIGINT? | PK/FK usuário, CASCADE. Textos padrão vazio; visibility Candidaturas/Público/Privado; notifications 0/1 padrão 1. guardian_status unverified/pending/confirmed/adult, padrão unverified; UQ token. Dados e autorização etária. |
| educations | id TEXT; user_id INTEGER; course/institution/semester/period TEXT; position INTEGER | PK UUID; FK usuário CASCADE; UQ (user_id,position). Curso/instituição obrigatórios; semestre/período padrão vazio. Múltiplas formações ordenadas. |
| skills | id/name/normalized_name TEXT | PK UUID; UQ name e normalized_name, todos obrigatórios. Nome normalizado sem acentos e em minúsculas evita duplicidade sem perder nome de exibição. |
| student_skills | user_id INTEGER; skill_id TEXT | PK composta; FKs usuário CASCADE e habilidade. Relação N:N. |
| projects | id TEXT; user_id INTEGER; title/description/link TEXT; position INTEGER | PK UUID; FK usuário CASCADE; UQ (user_id,position). Título obrigatório; descrição/link padrão vazio. |
| project_skills | project_id/skill_id TEXT | PK composta; FK projeto CASCADE e habilidade. Relação N:N. |
| complementary_courses | id TEXT; user_id INTEGER; title/institution/period TEXT; position INTEGER | PK UUID; FK usuário CASCADE; UQ (user_id,position). Título obrigatório; instituição/período padrão vazio. |
| profile_languages | id TEXT; user_id INTEGER; name/level TEXT; position INTEGER | PK UUID; FK usuário CASCADE; UQ (user_id,position). Nome obrigatório; nível padrão vazio. |
| profiles | user_id INTEGER; data TEXT | PK/FK usuário CASCADE. JSON legado obrigatório para migração; não é a fonte profissional normalizada. |

## Empresas, vagas e processos

| Tabela | Campos e tipos | Chaves, regras e finalidade |
| --- | --- | --- |
| companies | id INTEGER; name TEXT; city/description/identifier TEXT? | PK identidade; nome obrigatório. Identificação fornecida, sem certificação automática. |
| recruiters | user_id/company_id INTEGER | PK composta; FKs usuário CASCADE e empresa. Associação base preservada para compatibilidade. |
| recruiter_memberships | user_id/company_id INTEGER; membership_role/membership_status TEXT | PK composta; FK composta recruiters CASCADE. role owner/recruiter padrão recruiter; status active/suspended/revoked padrão active. Permissões do vínculo. |
| company_verifications | company_id INTEGER; status/website/notes TEXT; reviewed_by INTEGER?; updated BIGINT | PK/FK empresa; FK revisor usuário SET NULL. status padrão Pendente; website/notes vazio; updated obrigatório. Análise administrativa. |
| jobs | id/company_id INTEGER; data TEXT; status TEXT? | PK identidade; FK empresa. JSON legado obrigatório; status padrão Aberta. Identificador e estado continuam nesta tabela. |
| job_details | job_id INTEGER; title/description/area/city/modality/deadline/activities/benefits/shift/kind TEXT; salary DOUBLE PRECISION; hours/experience INTEGER | PK/FK vaga CASCADE. Campos obrigatórios; salary >=0; hours 1–8 (diárias); experience 0/1 padrão 0; kind Estágio/Aprendiz padrão Estágio. |
| job_courses | job_id INTEGER; course TEXT | PK composta; FK vaga CASCADE. Curso aceito por vaga. |
| job_skills | job_id INTEGER; skill_id TEXT | PK composta; FK vaga CASCADE e habilidade. Critério de habilidade. |
| applications | id/user_id/job_id INTEGER; status/created TEXT? | PK identidade; UQ (user_id,job_id); FK usuário CASCADE e vaga. status padrão Enviada; created UTC gerado. Estado atual validado na API. |
| history | id/application_id INTEGER; author_id INTEGER?; status/reason/created TEXT? | PK identidade; FK candidatura CASCADE; FK autor SET NULL. Novo status/motivo, UTC gerado. Registro imutável de etapas. |
| history_previous | history_id INTEGER; previous_status TEXT? | PK/FK history CASCADE. NULL no primeiro evento; etapa anterior inclusive correção administrativa. |
| favorites | user_id/job_id INTEGER | PK composta; FK usuário CASCADE e vaga. Favorito interno. |
| notifications | id/user_id INTEGER; message/created TEXT?; read INTEGER? | PK identidade; FK usuário CASCADE. read padrão 0, created UTC gerado. |
| reports | id INTEGER; user_id/job_id INTEGER?; reason/status TEXT? | PK identidade; FK usuário SET NULL e vaga. status padrão Pendente. |
| audit | id INTEGER; author_id INTEGER?; action/reason/created TEXT? | PK identidade; FK autor SET NULL; created UTC gerado. Ação administrativa/motivo. |

## Autenticação, integração, privacidade e operação

| Tabela | Campos e tipos | Chaves, regras e finalidade |
| --- | --- | --- |
| sessions | token TEXT; user_id INTEGER?; expires BIGINT? | PK token; FK usuário CASCADE. Sessão opaca e expiração Unix ms. |
| resets | token TEXT; user_id INTEGER?; expires BIGINT? | PK token; FK usuário CASCADE. Recuperação de uso único. |
| external_jobs | source/source_id/data TEXT; updated BIGINT? | PK (source,source_id). Documento de origem/cache, sem empresa local inventada. |
| integrations | source TEXT; last_success/last_attempt BIGINT?; error TEXT? | PK fonte. Últimos instantes/erro de sincronização. |
| external_favorites | user_id INTEGER; source/source_id TEXT | PK composta; FK usuário CASCADE. Chave externa sem FK ao cache. |
| auth_rate | key TEXT; started BIGINT; count INTEGER | PK chave, demais obrigatórios. Janela e contagem de autenticação. |
| alert_subscriptions | user_id INTEGER; enabled/confirmed INTEGER; filters TEXT; token TEXT?; expires BIGINT?; last_sent BIGINT | PK/FK usuário CASCADE; enabled/confirmed padrão 0; filters obrigatório (JSON); last_sent padrão 0. Confirmação e preferências de alerta. |
| alert_deliveries | user_id INTEGER; job_key TEXT; sent BIGINT | PK (user_id,job_key); FK usuário CASCADE. Deduplicação de envio. |
| app_events | id/kind/route TEXT; created BIGINT | PK UUID; obrigatórios. Evento técnico sanitizado sem conteúdo pessoal. |
| privacy_requests | id TEXT; user_id INTEGER?; reason/status TEXT; created BIGINT | PK UUID; FK usuário CASCADE. status padrão Pendente; motivo e data obrigatórios. |
| schema_migrations | name/applied_at TEXT | PK nome; instante obrigatório. Marca aplicação de backfill. |
| operation_backup_runs | day/status/created TEXT; sent_at TEXT?; bytes INTEGER?; error TEXT? | PK dia; status/created obrigatórios. Ledger técnico de backup. |
| operations_monitor_state | key/status/updated TEXT; failures INTEGER | PK chave; status/updated obrigatórios; failures padrão 0. Estado/contagem do monitor. |

Campos sem indicação `?` são NOT NULL ou componentes de chave usados pelo runtime. Algumas FKs compostas das migrações legadas não possuem NOT NULL explícito no SQL; a API sempre fornece seus componentes. Estados de processo e papel global são validados na aplicação, enquanto enums marcados acima também possuem CHECK no banco. A migração e a API são a referência para alterações futuras deste dicionário.
