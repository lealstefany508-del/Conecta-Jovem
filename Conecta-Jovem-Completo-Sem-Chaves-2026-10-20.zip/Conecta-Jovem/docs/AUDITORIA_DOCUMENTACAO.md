# Comparação com a documentação do Conecta Jovem

Data: 01/10/2026 (America/Sao_Paulo). Referência: Conecta_Jovem_Documentacao.pdf, versão 1.0, 14 páginas. Auditoria da implementação atual; nenhum código funcional ou configuração de produção foi alterado.

## Resultado

Os fluxos principais do MVP existem e passaram pelos testes atuais. A implementação ainda não corresponde integralmente ao documento: modelagem normalizada, múltiplas formações, alguns detalhes da interface, gestão completa de recrutadores e correções administrativas de resultados permanecem incompletos. A validação de desempenho e as definições operacionais também não estão completas.

Anúncios externos da Adzuna são uma ampliação autorizada pelo proprietário. Eles levam à candidatura na fonte original; não oferecem automaticamente os filtros completos, a compatibilidade, o envio do perfil e o histórico de seleção previstos para vagas publicadas diretamente no Conecta Jovem. Não devem ser apresentados como demonstração desses fluxos internos.

## Pendências prioritárias

| Prioridade | Exigência do PDF | Situação e evidência | Trabalho necessário |
| --- | --- | --- | --- |
| Alta | Entidades separadas, múltiplas formações, relações de habilidades e conferência de 3FN; DER e dicionário (pp. 12 e 14) | `server/migrations/001-postgres.sql:2` armazena o perfil em `data TEXT`; a linha 5 faz o mesmo com vagas. Habilidades são arrays dentro desses documentos, cursos e projetos são textos, e o perfil tem uma única formação. Não existem as entidades Formacao, Habilidade, EstudanteHabilidade, VagaHabilidade, Projeto e CursoComplementar propostas, nem DER/dicionário definitivos nos arquivos consultados. | Modelar as entidades e associações, migrar os dados existentes, atualizar API e formulários e produzir DER/dicionário. O PostgreSQL e as migrações já existem; a lacuna é a estrutura. |
| Alta | Definir política de idade, tratamento e eventuais autorizações antes da operação pública (p. 13) | `public/privacy.html:1` menciona adolescentes genericamente. Cadastro em `src/main.jsx:14` e `server/index.js:74` não implementa uma política de elegibilidade etária ou fluxo de autorização. | O proprietário deve definir o público etário e a política; depois implementar os controles correspondentes. Esta constatação compara o produto ao PDF, sem concluir conformidade jurídica. |
| Média | Correções administrativas de estados finais com motivo e registro (p. 9) | `server/index.js:306` restringe atualizações a recrutador/estudante e às transições normais. `server/index.js:422` não possui ação administrativa para candidatura. A tabela `history` guarda o novo status, autor, data e motivo, mas não uma coluna de status anterior (`001-postgres.sql:7`). | Criar correção administrativa excepcional auditada; registrar explicitamente status anterior e novo, preservando o histórico. |
| Média | Gerenciar recrutadores com papel e situação (pp. 6, 11 e 12) | Existem listagem e inclusão (`server/index.js:345`), porém a associação só possui IDs (`001-postgres.sql:4`). Todos os recrutadores têm o mesmo poder sobre a empresa, inclusive adicionar outros. A interface (`src/main.jsx:46`) não permite remover vínculo, suspender recrutador na empresa ou definir papel. | Introduzir papéis/situação e controle do responsável pela organização, com revogação e gerenciamento na interface. |
| Média | Organizar candidaturas por etapa (pp. 5 e 11; RF12) | `src/main.jsx:37` mostra uma lista geral com etiquetas de status. É possível abrir o perfil e mudar etapas, mas não filtrar/agrupar candidatos por vaga e etapa. | Acrescentar filtros por vaga/status e organização por etapa. |
| Média | Erro próximo ao campo; perfil incompleto direciona à edição; candidatura duplicada apresenta registro anterior (pp. 8 e 11) | Campos HTML obrigatórios têm validação nativa. Erros da API, porém, usam mensagem geral ou toast (`src/main.jsx:14` e `:22`). A candidatura incompleta retorna 422 (`server/index.js:274`), mas a ação em `src/main.jsx:51` não direciona ao perfil. Duplicidade é bloqueada corretamente, sem abrir o registro anterior. | Associar erros da API aos campos, oferecer ação para completar perfil e abrir a candidatura já existente. |
| Média | Meta de busca em até 3 segundos com 100 usuários simultâneos, em cenário documentado (p. 7; RNF03) | `README.md:76` registra 100 consultas ao catálogo SQLite local. `tests/verify-live.mjs:21` utiliza o mesmo cookie de uma sessão para todas as requisições. Isso não demonstra 100 usuários em PostgreSQL/Vercel. | Executar e documentar teste representativo com sessões distintas, volume definido e métricas de latência/erros em ambiente de teste. |
| Média | Monitoramento de falhas e manutenção de backups (p. 7; RNF04) | Eventos técnicos, painel, health check e scripts de backup/restauração existem. `scripts/monitor.mjs:2` faz uma consulta pontual; `docs/MELHORIAS.md` reconhece que o monitor externo contínuo ainda não está conectado. Não há rotina de agendamento/retenção dos snapshots demonstrada pelos arquivos consultados. | Definir periodicidade e retenção de backups e conectar monitoramento contínuo com aviso de indisponibilidade. A documentação registra restauração previamente validada; ela não foi repetida nesta auditoria. |
| Baixa | Foto opcional (p. 5) | `server/db.js:4` e `src/main.jsx:60` têm telefone e experiência opcionais, mas não foto; o avatar usa iniciais. | Implementar foto opcional com armazenamento e controles apropriados, caso se mantenha esse requisito na especificação. |
| Baixa | Indicadores e teste piloto com estudantes/recrutadores (p. 14) | Há estatísticas individuais e testes automatizados, mas não uma avaliação piloto documentada com conclusão de tarefas, tempo de candidatura e metas dos indicadores. | Realizar piloto autorizado e registrar resultados e metas. As metas são previstas para definição após o piloto. |
| Baixa | Documentação operacional coerente com o produto | `docs/DECISOES.md` ainda descreve SQLite e envio de recuperação desconectado. `README.md:66` mistura backup PostgreSQL com instruções de restauração SQLite, e `:79` ainda descreve recuperação como aguardando confirmação, já fornecida pelo proprietário. | Atualizar esses trechos para refletir Neon, Gmail, restauração PostgreSQL e validações efetivamente concluídas. |

## Requisitos funcionais (p. 6)

Legenda: Atendido = implementado nos fluxos próprios do produto e com evidência no código/testes; Parcial = existe, mas falta detalhe especificado; Futuro = explicitamente fora do MVP. Esta matriz não implica validação integral de produção ou de todos os casos extremos.

| ID | Situação | Evidência / limite |
| --- | --- | --- |
| RF01 | Atendido | Cadastro, e-mail único e validação no servidor; `server/index.js:74`; teste de duplicidade em `tests/system.test.js`. |
| RF02 | Atendido | Login, logout e recuperação; `server/index.js:92`, `:102`, `:124` e `:224`; testes de token de uso único e invalidação de sessões. O proprietário confirmou recebimento; após trocar o remetente, esta auditoria não repete entrega à caixa de entrada. |
| RF03 | Parcial | Empresa e associação de recrutadores existentes; falta gestão de papel/situação/revogação. |
| RF04 | Parcial | Perfil, cursos, projetos e habilidades editáveis; formação única, cursos/projetos em texto livre, foto ausente e estrutura diferente do modelo proposto. |
| RF05 | Atendido | Criar, editar, abrir, pausar e encerrar vagas próprias; aprovação empresarial adicional; `server/index.js:373`, `:382`, `:391`. |
| RF06 | Atendido | Busca por título/área com normalização e combinação de termos; `src/search.js:2`. |
| RF07 | Parcial | Cidade, curso, modalidade, bolsa mínima e máximo de horas existem; bolsa não possui limite superior da faixa. Nas vagas externas os dados desconhecidos não são inferidos e filtros que dependem deles não retornam esses anúncios. |
| RF08 | Atendido | Candidatura ligada ao perfil e unicidade estudante/vaga no banco e API; `001-postgres.sql:6`, `server/index.js:269`. Perfil atual é consultado pela empresa, sem snapshot imutável, que não é exigido no PDF. |
| RF09 | Atendido | Status atual e histórico ao estudante; `server/index.js:286`, `src/main.jsx:62`. |
| RF10 | Atendido nas vagas internas | Pesos 30/30/20/20, explicação e indicação de perfil incompleto; `server/rules.js:2`. Anúncios Adzuna não recebem porcentagem inventada. |
| RF11 | Futuro | Chat vinculado ao processo é explicitamente posterior ao MVP. Sua ausência não impede a entrega inicial. |
| RF12 | Parcial | Acesso restrito aos candidatos da empresa e mudança de etapas; falta organizar/filtrar a lista por vaga e etapa. |
| RF13 | Atendido | Notificações internas ao candidatar/alterar status e marcação como lidas; `server/index.js:278`, `:322`, `:327`. Preferência pode desativar seu recebimento. |
| RF14 | Atendido no escopo básico | Administração de contas, vagas e denúncias, com autor/data/motivo; `server/index.js:412`, `:422`. Correção de resultados finais é pendência adicional da p. 9. |
| RF15 | Atendido | Favoritos persistentes de vagas próprias e externas; `server/index.js:199`, `:253`. |
| RF16 | Atendido para estudante | Visibilidade, solicitação sobre dados, exportação e exclusão; `server/index.js:231`, `:451` e `server/product.js`. Exclusão empresarial requer tratamento administrativo e transferência de responsabilidade. |

## Qualidade e regras (p. 7)

| Item | Situação |
| --- | --- |
| RNF01 — Usabilidade | Parcial: rótulos e feedback existem; faltam detalhes de validação e navegação descritos acima. |
| RNF02 — Segurança | Hash scrypt, sessão em cookie, HTTPS na publicação, TLS no PostgreSQL e autorização no servidor. Testes atuais cobrem bloqueios importantes; não equivalem a auditoria completa de segurança. |
| RNF03 — Desempenho | Não comprovado no cenário exigido de 100 usuários; há evidência limitada de consultas locais. |
| RNF04 — Disponibilidade | Parcial: instrumentos e restauração documentada existem; operação contínua e retenção/agendamento precisam ser definidos. |
| RNF05 — Responsividade | Teste de navegador passou em 360/768/1280, incluindo acesso a configurações no celular; não houve perda de funções no percurso testado. |
| RNF06 — Privacidade | Controles implementados; política etária e detalhes operacionais continuam pendentes. |
| RNF07 — Separação | Interface, regras, servidor, persistência e migrações separados. |
| RNF08 — Acessibilidade | Teste axe passou em acesso/cadastro/painel/configurações; foco visível, labels e tratamento de foco de modais presentes. Não comprova acessibilidade de todas as telas nem teste com leitores de tela. |
| RN01–RN07 | Regras presentes e exercitadas nos testes de autenticação, propriedade, unicidade, publicação, prazo, transições e notificações. |
| RN08 | Perfil privado oculta dados e bloqueia novas candidaturas; dados de candidatos são restritos à empresa vinculada. |
| RN09 | Perfil sem experiência é permitido e testado. |
| RN10 | Interface explica que afinidade não garante aprovação; experiência não compõe a pontuação. |

## Casos de uso e critérios de aceitação

UC01–UC05 têm o percurso principal implementado. As alternativas de UC01/UC03 ainda precisam do tratamento de erro por campo e direcionamento/abertura do registro anterior. UC02 valida dados antes de publicar, mas não oferece uma etapa separada de revisão. UC04 aplica as transições normais e gera histórico/notificação. UC05 apresenta histórico e estado vazio.

Os testes verificam os principais cenários da p. 13: e-mail repetido, perfil sem experiência, candidatura válida/duplicada, vaga pausada/encerrada, tentativa de operação por outra empresa, alteração de status e estado vazio. Não há um teste específico que avance o relógio para expirar uma vaga já publicada: a verificação de prazo existe no código e a publicação com prazo passado é testada, mas essa variante de aceitação merece cobertura direta.

## Recursos que o PDF deixa para depois

Chat com bloqueio/denúncia, descoberta de interesses, exportação de currículo, agenda de entrevistas e app nativo não são exigidos na primeira entrega. Exportar dados em JSON não equivale a exportar currículo. PWA instalável não equivale a app nativo. Jovem aprendiz, integração de anúncios externos e e-mails já foram adicionados por solicitação posterior do proprietário.

Contratos, pagamento de bolsas e integração com instituições de ensino permanecem fora do escopo inicial, conforme a p. 4.

## Verificação nesta auditoria

- Leitura textual integral das 14 páginas e inspeção da composição visual do documento.
- Inspeção dos componentes, regras, rotas, esquema PostgreSQL, testes e documentação operacional.
- `npm test`: 12 testes passaram, nenhum falhou. Os testes usam bancos temporários e atualizam capturas de evidência; não criam contas/vagas fictícias em produção.
- `npm run test-postgres`: 7 testes passaram em schemas isolados da branch de verificação, com limpeza ao final; API, regras do produto e jornada no navegador.
- Publicação: `/api/health` respondeu HTTP 200 com `status: ok`.
- Não foi executado teste de carga de produção, teste piloto com pessoas ou revisão jurídica. Não foi feita alteração do código, de credenciais ou da publicação durante esta auditoria.

## Ordem recomendada para fechar a documentação

1. Definir política etária e decisões operacionais que dependem do proprietário.
2. Concluir modelagem, migração segura, DER e dicionário.
3. Completar recrutadores, correções administrativas, organização das candidaturas e detalhes dos formulários/perfil/filtros.
4. Validar o cenário de carga, rotina de monitoramento/backups e casos extremos de aceitação.
5. Atualizar documentação operacional e realizar o piloto de avaliação.
