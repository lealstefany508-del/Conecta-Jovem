# Configuração Neon concluída

- Neon CLI 7.0.6 instalado globalmente e login concluído.
- `neon skills -y`: skills instaladas em `.agents/skills` para Codex.
- `neon mcp -y`: configuração MCP instalada para os agentes detectados pelo CLI.
- Projeto vinculado: `young-river-98490350`.
- Organização: `org-empty-mouse-59934798`.
- Branch: `production` (`br-dawn-bonus-b6o9815c`).
- `neon config init`: pacotes `@neon/config` e `@neon/env` instalados.
- `neon.ts` contém exatamente a configuração vazia solicitada.
- `neon deploy`: concluído, sem alterações remotas porque a branch já corresponde à política vazia. Serviço utilizado: Postgres.
- Variáveis `DATABASE_URL`, `DATABASE_URL_UNPOOLED` e `NEON_BRANCH` sincronizadas pelo CLI no `.env`.
- `.env` e `.neon` ignorados pelo Git.
- Conexão PostgreSQL validada via driver `pg` no banco `neondb`, com TLS 1.3 e verificação do certificado.

Para repetir a verificação sem mostrar credenciais:

```powershell
npm run check-neon
```

## Aplicação integrada

A API usa PostgreSQL quando DATABASE_URL está configurada. A migração versionada fica em server/migrations/001-postgres.sql e é aplicada por npm run migrate. A migração dos dados locais foi validada na branch conecta-migration-check antes da aplicação em production. Foram preservadas duas contas e 59 anúncios externos; sessões locais não foram transferidas.

O runtime usa conexão com pool, TLS verificado e transações com cliente dedicado. Migrações usam conexão direta. Testes de API e navegador foram executados em schemas isolados da branch de teste, sem dados fictícios em production.
