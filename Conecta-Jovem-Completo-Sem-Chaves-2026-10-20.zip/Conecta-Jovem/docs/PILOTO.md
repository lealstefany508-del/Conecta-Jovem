# Piloto com estudantes e recrutadores

Estado: protocolo preparado; piloto com participantes reais **não realizado**. Testes automatizados e carga sintética não substituem a avaliação de uso. Não há resultados de pessoas, satisfação ou metas validadas nesta entrega.

As jornadas foram executadas pelo agente com atores simulados em banco isolado: `node scripts/pilot-automated.mjs`, 7 cenários aprovados. O resultado e os tempos dos cenários estão em `evidencias/piloto-automatizado.json`; essa evidência é funcional e não representa sete participantes.

## Preparação

- Responsável indicada pelo proprietário: Stefany Ferreira dos Santos; contato operacional: conectajovememailreserch@gmail.com; a marca Conecta Jovem não identifica por si só uma pessoa jurídica controladora.
- Convidar, mediante autorização do proprietário, pelo menos cinco estudantes e dois recrutadores; usar ambiente separado e empresas/vagas de exercício identificadas. Nenhuma fixture entra no produto público.
- Público de 16 anos ou mais; participantes de 16 e 17 anos devem cumprir o fluxo de autorização de responsável e a política etária do produto antes de acessar.
- Explicar finalidade, duração, tarefas, dados anotados, acesso aos registros e data de eliminação. Obter concordância voluntária, permitir desistência e evitar gravação de tela contendo dados pessoais sem autorização específica.
- Definir previamente a duração de retenção e armazenar notas privadas com acesso restrito. Usar códigos de participante, sem e-mails, nome civil ou telefone na planilha de resultados.

## Roteiro e critérios

| Público | Tarefa | Resultado observável |
| --- | --- | --- |
| Estudante | Criar conta e completar perfil, com duas formações e habilidades | Perfil salvo; campos obrigatórios compreendidos; retomada após erro |
| Estudante | Buscar estágio por cidade, curso, bolsa e modalidade | Localizar uma oportunidade adequada; distinguir fonte externa |
| Estudante | Favoritar e candidatar a vaga interna | Uma candidatura criada; registro anterior acessível ao tentar repetir |
| Estudante | Consultar histórico, exportar dados e ajustar visibilidade | Encontrar etapa e motivo; compreender acesso empresarial |
| Recrutador | Completar empresa e solicitar aprovação | Compreender o bloqueio de publicação até a análise administrativa |
| Recrutador | Publicar e editar vaga com critérios | Dados exibidos correspondem ao anúncio revisado |
| Recrutador | Filtrar candidatos por vaga/etapa e mudar status | Histórico e notificações correspondem à ação |
| Responsável empresarial | Adicionar, suspender e revogar recrutador | Usuário revogado perde acesso às operações da organização |

Para cada tarefa registrar: código do participante, tarefa, início/fim, duração em segundos, sucesso sem ajuda/com ajuda/falha, quantidade de erros, trecho da interface e comentário voluntário. Cronometrar da orientação inicial à confirmação visível. Separar tempo de espera por aprovação empresarial do tempo de interação.

## Indicadores e cálculo

| Indicador | Definição | Evidência |
| --- | --- | --- |
| Conclusão de tarefas | tarefas concluídas / tarefas iniciadas | Ficha observacional, distinguindo ajuda |
| Tempo de candidatura | mediana e p95 entre abrir vaga e confirmação | Ficha observacional, nunca tempo inventado |
| Perfil completo | estudantes ativos com curso, instituição, cidade, disponibilidade e modalidade / estudantes ativos | Consulta das entidades normalizadas; mesma regra da API |
| Processos atualizados | candidaturas com pelo menos uma mudança depois de Enviada / candidaturas criadas no período | applications + history; excluir registro inicial |
| Falhas na busca | respostas inválidas ou erro / consultas | Evidência de carga e observação de sessão |

As metas de produto serão aprovadas após o primeiro piloto, como previsto na documentação original. Para carga técnica a meta permanece resposta em menos de três segundos no cenário de 100 sessões simultâneas. `node scripts/verify-load.mjs` salva dados medidos em `docs/evidencias/carga.json`, com o cenário e seus limites.

## Relatório a preencher após execução

Data/ambiente: pendente. Participantes convidados/aceites/concluintes: pendente. Autorizações de responsáveis quando aplicáveis: pendente. Resultados por tarefa: pendente. Erros prioritários: pendente. Metas aprovadas e responsável: pendente. Data de descarte dos registros: pendente. Não publicar notas individuais nem inserir dados pessoais neste documento.


Consultas agregadas de referência (PostgreSQL), sem revelar perfis individuais:

```sql
SELECT count(*) AS estudantes_ativos,
       count(*) FILTER (WHERE trim(COALESCE(d.city,''))<>''
          AND trim(COALESCE(d.availability,''))<>''
          AND trim(COALESCE(d.modality,''))<>''
          AND EXISTS (SELECT 1 FROM educations e WHERE e.user_id=u.id
              AND e.position=0 AND trim(e.course)<>'' AND trim(e.institution)<>'')) AS perfis_completos
FROM users u LEFT JOIN student_details d ON d.user_id=u.id
WHERE u.role='student' AND u.active=1;

SELECT count(*) AS candidaturas,
       count(*) FILTER (WHERE EXISTS (
           SELECT 1 FROM history h WHERE h.application_id=a.id
           AND EXISTS (SELECT 1 FROM history earlier
                       WHERE earlier.application_id=a.id AND earlier.id<h.id))) AS candidaturas_atualizadas
FROM applications a
WHERE a.created >= $1 AND a.created < $2;
```

`$1`/`$2` delimitam o período em ISO UTC, início inclusivo e fim exclusivo. A definição de perfil completo segue os campos mínimos de candidatura; a posição zero é a formação principal usada pela API. Perfil privado pode estar completo, mas não permite candidatar. “Atualizada” significa ao menos um evento posterior ao registro inicial, inclusive cancelamento ou correção administrativa; não significa contratação.

## Registro pronto para coleta

Copie `docs/piloto-template.csv` para uma pasta privada em `data/piloto`. Preencha somente códigos de participante, papel, consentimento e dados de observação; não registre nomes, e-mails ou documentos nas notas. O template não contém resultados nem participantes fictícios. O proprietário informou em 02/10/2026 que ainda não possui participantes: o piloto permanece pendente por esse motivo.
