# DER da persistência

Fonte executável: `server/migrations/001-postgres.sql`, `002-product.sql` e `003-normalized.sql`. Identificadores centrais são INTEGER com identidade PostgreSQL; entidades de perfil usam UUID armazenado em TEXT. O diagrama separa os dados profissionais dos documentos legados. Banco do produto: PostgreSQL Neon.

```mermaid
erDiagram
 users ||--o| student_details : possui
 users ||--o{ educations : cursa
 users ||--o{ projects : apresenta
 users ||--o{ complementary_courses : conclui
 users ||--o{ profile_languages : informa
 users ||--o{ student_skills : associa
 skills ||--o{ student_skills : identifica
 projects ||--o{ project_skills : associa
 skills ||--o{ project_skills : identifica
 users ||--o{ recruiters : vincula
 companies ||--o{ recruiters : emprega
 recruiters ||--o| recruiter_memberships : qualifica
 companies ||--o| company_verifications : verifica
 companies ||--o{ jobs : publica
 jobs ||--o| job_details : descreve
 jobs ||--o{ job_courses : exige
 jobs ||--o{ job_skills : exige
 skills ||--o{ job_skills : identifica
 users ||--o{ applications : envia
 jobs ||--o{ applications : recebe
 applications ||--o{ history : registra
 history ||--o| history_previous : preserva
 users o|--o{ history : autoria
 users ||--o{ favorites : salva
 jobs ||--o{ favorites : referencia
 users ||--o{ sessions : autentica
 users ||--o{ resets : recupera
 users ||--o{ notifications : recebe
 users o|--o{ reports : denuncia
 jobs ||--o{ reports : alvo
 users o|--o{ audit : autoria
 users ||--o{ external_favorites : salva_externo
 users ||--o| alert_subscriptions : configura
 users ||--o{ alert_deliveries : recebe_alerta
 users ||--o{ privacy_requests : solicita
 users ||--o| profiles : arquivo_legado
```

`external_jobs` é cache independente por (source, source_id), sem empresa artificial. `external_favorites` registra a chave da origem sem FK para permitir expiração do cache. `integrations` guarda a sincronização por fonte; `auth_rate`, `app_events`, `schema_migrations`, `operation_backup_runs` e `operations_monitor_state` são entidades técnicas independentes.

Cada formação, projeto, curso e idioma tem uma linha própria e uma posição única por estudante. Habilidades possuem um catálogo compartilhado com chave normalizada única e relações N:N com estudantes, projetos e vagas. Perfil base tem relação 1:1 com usuário; atributos da vaga têm relação 1:1 com seu identificador. Papel/situação do recrutador dependem do vínculo composto, sem alterar o papel global da conta.

As entidades profissionais removem os grupos repetidos do JSON e explicitam dependências por chave. Os documentos `profiles.data` e `jobs.data` são arquivos de transição para backfill; o runtime lê/escreve o modelo normalizado. Cache de API externa, filtros de alerta e eventos técnicos não constituem o modelo acadêmico de perfil. Esta separação não afirma que todo texto ou documento externo foi transformado em 3FN.

Exclusão de estudante elimina perfil, associações, sessões e candidaturas em cascata; autoria histórica/moderação fica nula quando o usuário é removido. Vagas referenciadas por candidatura e empresas referenciadas por vaga não são removidas arbitrariamente. `history_previous` complementa cada evento com status anterior, sem sobrescrever o histórico original.
