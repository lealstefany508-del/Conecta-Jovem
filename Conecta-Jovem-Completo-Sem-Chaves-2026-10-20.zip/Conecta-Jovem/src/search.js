export const normalized=value=>String(value||'').normalize('NFD').replace(/\p{Diacritic}/gu,'').toLowerCase().trim();
export function matches(job,filters={},query=''){
 const content=normalized([job.title,job.area,job.company,job.city].join(' '));
 if(normalized(query).split(/\s+/).filter(Boolean).some(term=>!content.includes(term)))return false;
 if(filters.city&&!normalized(job.city).includes(normalized(filters.city)))return false;
 if(filters.area&&!normalized([job.title,job.area].join(' ')).includes(normalized(filters.area))&&!(normalized(filters.area)==='tecnologia'&&/^(ti|it)\b/.test(normalized(job.area))))return false;
 const kind=job.kind||(/aprendiz/i.test(normalized(job.title))?'Aprendiz':'Estágio');
 if(filters.kind&&kind!==filters.kind)return false;
 if(filters.source&&filters.source!==(job.source||'Conecta Jovem'))return false;
 if(filters.modality&&job.modality!==filters.modality)return false;
 if(filters.course&&!job.courses?.some(c=>normalized(c).includes(normalized(filters.course))))return false;
 if(filters.salary&&(job.salary==null||job.salary<Number(filters.salary)))return false;
 if(filters.salaryMax&&(job.salary==null||job.salary>Number(filters.salaryMax)))return false;
 if(filters.hours&&(job.hours==null||job.hours>Number(filters.hours)))return false;
 if(filters.beginner&&job.experience!==false)return false;
 return true;
}
