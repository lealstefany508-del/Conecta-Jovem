# Conecta Jovem — pacote para compartilhar

Comece em [docs/GUIA_COMPARTILHAMENTO_E_TESTES.md](docs/GUIA_COMPARTILHAMENTO_E_TESTES.md).

Sem chaves ou acessos do autor. Configure suas proprias integracoes. O codigo e os testes foram preservados; capturas privadas, dados e vinculos de contas foram omitidos. Dependencias e dist sao gerados com npm ci e npm run build.

Os relatorios anteriores descrevem o ambiente original e nao garantem disponibilidade atual de servicos.
