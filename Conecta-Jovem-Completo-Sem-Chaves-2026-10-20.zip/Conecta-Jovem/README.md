# Conecta Jovem

Aplicação web responsiva para conectar estudantes a oportunidades de estágio, implementada a partir das 14 páginas de `Conecta_Jovem_Documentacao.pdf`.

## Executar

Publicado em [conecta-jovem-two.vercel.app](https://conecta-jovem-two.vercel.app). Requisito de hospedagem: Node.js 24. PostgreSQL Neon é o banco ativo; SQLite é usado apenas no modo local sem DATABASE_URL ou em testes isolados.

```powershell
npm install
npm run build
npm run dev
```

Abra http://localhost:3000. Para desenvolvimento com recarga automática, use `npm run develop`.

A aplicação inicia com **zero vagas, zero empresas e zero estudantes fictícios**. Com Adzuna configurada, o catálogo externo é preenchido somente com anúncios reais recebidos pela API. O administrador inicial é criado com `admin@conecta.local` e senha aleatória exibida uma única vez no terminal. Cadastre estudantes e empresas pela tela inicial. Para gerar uma nova senha administrativa local, execute `npm run admin`.

## Operações implementadas

- Cadastro e login de estudante/empresa, e-mail único, senhas com scrypt e salt, sessões no servidor, cookie HttpOnly e encerramento de sessão.
- Perfil profissional com formação, disponibilidade, objetivo, habilidades, idiomas, projetos, cursos e experiência opcional.
- Publicação, edição, pausa e encerramento de vagas pela empresa responsável.
- Busca por título, área e empresa; filtros de cidade, curso, modalidade, bolsa, carga horária e experiência.
- Favoritos persistentes, candidatura única por estudante/vaga, bloqueio por prazo e perfil incompleto.
- Compatibilidade determinística explicada: curso 30, habilidades 30, turno 20 e modalidade/local 20. Critérios ausentes são excluídos do denominador.
- Histórico de candidaturas, estados válidos, cancelamento pelo estudante, análise de candidatos pela empresa e notificações internas.
- Perfil empresarial e criação de contas de recrutadores vinculadas à própria empresa.
- Controle de visibilidade, preferências de notificação, exclusão da conta do estudante.
- Administração de contas, suspensão de vagas, denúncias e trilha de ações com autor/data/motivo.
- Recuperação de acesso com token de uso único, expiração e invalidação de sessões. **A entrega automática está configurada via Gmail SMTP**; no ambiente local, o link fica no terminal do responsável. O conector Resend está implementado: configure `RESEND_API_KEY`, `EMAIL_FROM` (remetente verificado) e `APP_PUBLIC_URL` para ativar a entrega. Consulte https://resend.com/docs/api-reference/emails/send-email. O token nunca é devolvido pela API de solicitação.

## Vagas reais

Não há gerador de vagas, vagas ilustrativas ou catálogo inventado. Cada oportunidade é inserida por um recrutador autenticado, vinculada à sua empresa e confirmada como real na publicação. Isso não constitui verificação automática do CNPJ ou da oferta: a equipe operacional precisa validar empresas e moderar anúncios. A Adzuna foi conectada e validada ao vivo; a primeira sincronização importou 59 anúncios reais de estágio/aprendiz. A disponibilidade final é conferida no anúncio de origem.

O conector Adzuna está implementado e as credenciais fornecidas pelo proprietário foram configuradas no `.env` local, ignorado pelo Git. O painel administrativo mostra configuração, último sucesso, contagem e erros. Para outro ambiente, obtenha suas credenciais em https://developer.adzuna.com/signup e preencha `ADZUNA_APP_ID`/`ADZUNA_APP_KEY` antes de iniciar.

O conector consulta `https://api.adzuna.com/v1/api/jobs/br/search/1` para estágio e aprendiz no Brasil, mantendo apenas títulos que explicitamente indiquem essas oportunidades. Na Vercel, realiza duas consultas no agendamento diário e pode atualizar após seis horas quando o catálogo é acessado; no servidor local, verifica a atualização a cada seis horas; sincronização manual respeita intervalo de uma hora. Cache com mais de 24 horas deixa de aparecer. Em falhas, mantém o último cache ainda válido e informa o erro. A busca inicial limita-se a até 50 anúncios por termo, sem alegar catálogo completo.

Anúncios externos preservam título/empresa/localização/descrição e incluem crédito `Jobs by Adzuna`, logo oficial e link original. A API fornece descrição resumida. Não são criadas empresas locais nem vínculos fictícios para esses anúncios. Salário, formação, carga horária, modalidade e compatibilidade não são inventados. A candidatura é externa, sem envio automático do perfil ou acompanhamento local de um processo que a plataforma não controla. Por esse motivo, filtros de curso/modalidade/bolsa/carga/experiência excluem anúncios externos com esses dados ausentes.

Documentação oficial consultada: [API](https://developer.adzuna.com/overview), [busca](https://developer.adzuna.com/docs/search), [especificação incluindo Brasil](https://developer.adzuna.com/swagger/spec/test2.json), [atribuição e condições](https://developer.adzuna.com/docs/terms_of_service).

## Dados e arquitetura

`src/`: interface React e estilos. `server/index.js`: API/autorização. `server/rules.js`: compatibilidade/transições. `server/db.js`/`server/store.js`: acesso ao banco; `server/migrations/`: migrações versionadas; `server/normalize.js`: persistência normalizada e backfill; `server/adzuna.js`: integração/cache. Persistência PostgreSQL com chaves estrangeiras, unicidade e transações; SQLite somente em testes ou modo local explicitamente selecionado. `data/conecta.sqlite`: banco real, ignorado pelo Git. Perfil e vagas internas possuem entidades normalizadas para formações, habilidades, projetos, cursos, idiomas e critérios; os documentos JSON preexistentes são preservados para transição. Consulte [DER](docs/DER.md) e [dicionário](docs/DICIONARIO_DADOS.md). O PostgreSQL Neon passou a ser o banco ativo. O SQLite anterior foi preservado como cópia de segurança.

`PORT`, `DB_PATH`, `ADMIN_EMAIL` e `ADMIN_PASSWORD` podem ser configurados no ambiente. A senha administrativa inicial só é aplicada na criação do administrador. `NODE_ENV=production` ativa cookies Secure e exige HTTPS por proxy reverso. O servidor local escuta exclusivamente em `127.0.0.1`.

## Validar

```powershell
npm test
npm run build
npm run check-db
npm run backup
```

Os testes usam bancos isolados na pasta temporária do sistema, removidos no encerramento. Nenhuma conta, empresa ou vaga de teste é gravada no banco do produto. O teste de navegador precisa do Chromium instalado pelo Playwright: em outro computador execute `npx playwright install chromium`.

Os testes cobrem jornada real de estudante/empresa no navegador, responsividade em 360/768/1280px, integridade, permissões entre empresas, duplicidade, bloqueios de prazo/status, privacidade, histórico, notificações, favoritos e exclusão.

## Backup e restauração

Com PostgreSQL, `npm run backup` cria um snapshot consistente dos dados em JSON. No modo SQLite, cria uma cópia via `VACUUM INTO` com verificação de integridade. Guarde os backups em local com acesso restrito. Para PostgreSQL: prepare uma branch isolada vazia com as migrações, defina `RESTORE_DATABASE_URL` dessa branch e execute `node scripts/restore-postgres.mjs caminho-do-snapshot.json`. O script bloqueia o endpoint de produção e confere contagens; valide a branch antes de qualquer substituição operacional. Para SQLite local: encerre o servidor, preserve o banco atual, copie o backup para `data/conecta.sqlite` e execute `npm run check-db`. Não reutilize WAL/SHM antigos. Consulte [operação](docs/OPERACOES.md).

## Para operar publicamente

A hospedagem Vercel com HTTPS e o banco persistente Neon estão ativos. A integração Gmail está configurada; autenticação SMTP com TLS e aceitação de envio foram verificadas. Operação contínua inclui moderação das empresas e anúncios, política de dados e backups. Chat, contratos, pagamentos, app nativo e agenda de entrevistas permanecem fora do MVP conforme a documentação.

## Evidências da validação final

- Conexão Adzuna autenticada: 59 anúncios de estágio/aprendiz reais na primeira sincronização.
- Navegador com o cache real em cópia temporária: cards, favoritos persistentes, detalhes, link de candidatura e larguras 360/768/1280 sem overflow.
- Verificação histórica: 100 consultas simultâneas ao catálogo SQLite com 59 registros e uma sessão, máximo 420 ms. O teste representativo de PostgreSQL usa 100 estudantes/cookies distintos, 20 vagas internas, 100 externas e três rodadas por endpoint; execute `node scripts/verify-load.mjs` e consulte [evidência medida](docs/evidencias/carga.json). A execução após a consulta normalizada em lote completou 600 requisições sem erros: maior latência de 774 ms nas vagas internas e 798 ms nas externas, abaixo de 3 s. O resultado não mede navegação de pessoas na Vercel; ambiente local desta medição: Node 26.7.0, PostgreSQL Neon separado.
- Backup restaurado em cópia temporária: integridade SQLite OK e mesma contagem de anúncios.
- Para repetir a verificação do cache real: `node tests/verify-live.mjs`. O script usa cópia temporária e não cria contas no produto.
- Recuperação por e-mail: contrato do conector testado com transporte isolado; envio de confirmação aceito pelo Gmail; o proprietário confirmou o recebimento da recuperação na hospedagem. Após trocar o remetente, confira novamente o recebimento; testes SMTP não comprovam entrega de todas as mensagens.

## Publicação e Gmail

SMTP implementado como alternativa ao Resend sem domínio. Consulte `docs/PUBLICACAO.md`. Gmail/senha de app e URL pública estão configurados na implantação atual. Deploy Vercel e migração PostgreSQL concluídos. Os testes completos de API e navegador passaram em PostgreSQL isolado.

## Melhorias do produto

Busca sem distinção de acentos, filtros por tipo/fonte e ordenação; aprovação administrativa de empresas antes da publicação; alertas opcionais com confirmação do e-mail e limite diário; PWA com ícones e tela offline sem dados pessoais; exportação de dados e solicitações de privacidade; registro de falhas sem conteúdo sensível e painel operacional. `npm run monitor` consulta a saúde pública. A restauração de snapshots foi validada em PostgreSQL isolado.

A verificação automatizada de acessibilidade usa axe em acesso, cadastro, painel e configurações. Testes também cobrem instalação, tela offline, aprovação/suspensão, preferências dos alertas e recuperação de uso único. Veja docs/MELHORIAS.md para decisões e limites operacionais.

## Validação ampliada e piloto

O modelo de dados e as decisões estão em [DER](docs/DER.md), [dicionário](docs/DICIONARIO_DADOS.md) e [decisões](docs/DECISOES.md). O [protocolo piloto](docs/PILOTO.md) define tarefas, indicadores e coleta: participação de pessoas e resultados permanecem pendentes. O público definido é de 16 anos ou mais; menores de 18 dependem de autorização de responsável. Responsável indicada pelo proprietário: Stefany Ferreira dos Santos, publicada na política de privacidade; contato operacional: conectajovememailreserch@gmail.com.


Para repetir carga: `node scripts/verify-load.mjs`. O arquivo privado `.env.neon-test` deve conter a URL de uma branch Neon com endpoint diferente da produção; o script cria schema exclusivo, sem publicar fixtures, e remove-o ao terminar. Resultado em `docs/evidencias/carga.json`. O cenário avalia as APIs de listagem, sem representar login, escritas ou renderização simultânea.

O fechamento das pendências técnicas está em [entrega da documentação](docs/ENTREGA_DOCUMENTACAO.md): modelo normalizado, perfil estruturado/foto, papéis de recrutadores, revisão de publicação, correções auditadas, política etária, backup diário cifrado e monitor local. Testes gerais: 20; jornadas PostgreSQL: 9. `node scripts/pilot-automated.mjs` executa as jornadas com atores simulados. As definições que dependem do proprietário/participantes e as limitações operacionais estão explicitadas nesse relatório.


## Administração e operação local

Acesso ao painel: https://conecta-jovem-two.vercel.app/admin. Use uma conta com papel administrativo; cadastro público não cria administradores. O arquivo privado `data/acesso-administrativo.txt` contém o acesso validado do proprietário e é ignorado pelo Git/Vercel. O painel reúne contas, aprovação de empresas, moderação de vagas, denúncias, correções excepcionais de resultados, operação/privacidade e auditoria. Motivos são obrigatórios e registrados no servidor.

Monitor ao entrar no Windows: `powershell -NoProfile -File scripts/install-monitor-startup.ps1`. Inicia oculto e evita duplicação. Configurado nesta instalação; computador desligado ou sem sessão não executa verificações. Consulte `docs/OPERACOES.md` para reinício, parada, backups e limitações.
