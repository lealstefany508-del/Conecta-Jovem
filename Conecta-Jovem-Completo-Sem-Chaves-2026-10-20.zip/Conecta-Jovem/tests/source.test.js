import {test,after} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import path from 'node:path';
import {tmpdir} from 'node:os';
const dir=mkdtempSync(path.join(tmpdir(),'conecta-source-'));
process.env.DB_PATH=path.join(dir,'source.sqlite');process.env.ADMIN_PASSWORD='Testing2026!safe';
const {normalizeAdzuna,syncAdzuna,externalJobs,integrationStatus}=await import('../server/adzuna.js');
const {db}=await import('../server/db.js');
after(()=>{db.close();rmSync(dir,{recursive:true,force:true});});
const row={id:'123',title:'Estágio em Tecnologia',company:{display_name:'Empresa de teste do conector'},location:{display_name:'São Paulo'},category:{label:'TI'},description:'<p>Descrição recebida na fonte</p>',redirect_url:'https://www.adzuna.com.br/jobs/details/123',salary_min:120000,salary_is_predicted:'1'};
test('Fonte: não inventa remuneração/requisitos e valida anúncio e domínio',()=>{
 const j=normalizeAdzuna(row);assert.equal(j.title,row.title);assert.equal(j.salary,undefined);assert.equal(j.skills,undefined);assert.ok(!j.description.includes('<'));assert.equal(normalizeAdzuna({...row,title:'Engenheiro sênior'}),null);assert.equal(normalizeAdzuna({...row,redirect_url:'javascript:alert(1)'}),null);assert.equal(normalizeAdzuna({...row,redirect_url:'https://attacker.example/adzuna.com.br'}),null);assert.equal(normalizeAdzuna({...row,company:{}}),null);
});
test('Fonte: exige credenciais, deduplica anúncios e mantém cache válido em falhas',async()=>{
 delete process.env.ADZUNA_APP_ID;delete process.env.ADZUNA_APP_KEY;
 await assert.rejects(()=>syncAdzuna(),/Configure/);assert.equal((await integrationStatus()).configured,false);
 process.env.ADZUNA_APP_ID='TEST-ONLY';process.env.ADZUNA_APP_KEY='TEST-ONLY';const now=Date.now();let calls=0;
 const fetcher=async(url)=>{assert.equal(url.hostname,'api.adzuna.com');assert.equal(url.pathname,'/v1/api/jobs/br/search/1');calls++;return {ok:true,json:async()=>({results:[row,{...row,id:'456',title:'Jovem Aprendiz Administrativo'}]})};};
 assert.equal((await syncAdzuna({fetcher,now})).count,2);assert.equal(calls,2);assert.equal((await externalJobs()).length,2);assert.equal((await integrationStatus()).lastSuccess,now);
 await assert.rejects(()=>syncAdzuna({fetcher,now:now+1000}),/uma hora/);
 await assert.rejects(()=>syncAdzuna({fetcher:async()=>({ok:false,status:401}),now:now+3600001}),/recusou as credenciais/);assert.equal((await externalJobs()).length,2);assert.ok((await integrationStatus()).error);
});
