import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,writeFileSync,existsSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {encryptSnapshot} from '../server/operations.js';
import {verifyBackupMail,pruneLocalBackups,retainGmailBackups} from '../server/backup-retention.js';
const now=new Date('2026-10-12T12:00:00Z'),email='project@example.com',key='a1'.repeat(32),env={SMTP_USER:email,OPERATIONS_EMAIL:email,BACKUP_ENCRYPTION_KEY:key};
const snapshot=created=>({version:2,created,data:{users:[]}});
function mail(created){const day=created.slice(0,10);return {subject:`[Conecta backup] ${day}`,from:{value:[{address:email}]},to:{value:[{address:email}]},attachments:[{filename:`conecta-${day}.backup.json`,content:encryptSnapshot(snapshot(created),key)}]};}
test('Retenção valida remetente, destinatário, data e conteúdo cifrado antes de selecionar',()=>{
 const valid=mail('2026-10-01T12:00:00Z');assert.ok(verifyBackupMail(valid,{email,key,now}));
 for(const bad of [{...valid,subject:'Mensagem pessoal'},{...valid,from:{value:[{address:'other@example.com'}]}},{...valid,to:{value:[{address:'other@example.com'}]}},{...valid,attachments:[{...valid.attachments[0],content:Buffer.from(JSON.stringify(snapshot('2026-10-01T12:00:00Z')))}]},mail('2026-10-13T12:00:00Z')])assert.equal(verifyBackupMail(bad,{email,key,now}),null);
 assert.equal(verifyBackupMail(valid,{email,key:'ff'.repeat(32),now}),null);
});
test('Retenção local preserva backup recente, arquivo estranho e conteúdo inválido',()=>{
 const directory=mkdtempSync(join(tmpdir(),'conecta-retention-'));try{const old=join(directory,'postgres-2026-10-01T12-00-00-000Z.backup.json'),recent=join(directory,'postgres-2026-10-12T10-00-00-000Z.backup.json'),invalid=join(directory,'postgres-2026-10-01T11-00-00-000Z.backup.json'),other=join(directory,'meu-arquivo.json');writeFileSync(old,encryptSnapshot(snapshot('2026-10-01T12:00:00Z'),key));writeFileSync(invalid,'invalid');writeFileSync(other,'personal');assert.equal(pruneLocalBackups({directory,key,now}).removed,0);writeFileSync(recent,encryptSnapshot(snapshot('2026-10-12T10:00:00Z'),key));assert.equal(pruneLocalBackups({directory,key,now}).removed,1);assert.equal(existsSync(old),false);for(const file of [recent,invalid,other])assert.ok(existsSync(file));}finally{rmSync(directory,{recursive:true,force:true});}
});
function fixture({fresh=true,uidPlus=true}={}){let folder;const all=new Map([[1,{mail:mail('2026-10-01T12:00:00Z'),received:new Date('2026-10-01T12:00:00Z')}],[3,{mail:{subject:'Mensagem pessoal'},received:new Date('2026-10-01T12:00:00Z')}]]),trash=new Map();if(fresh)all.set(2,{mail:mail('2026-10-12T10:00:00Z'),received:new Date('2026-10-12T10:00:00Z')});const actions=[];return {actions,client:{capabilities:new Set(uidPlus?['UIDPLUS']:[]),connect:async()=>{},logout:async()=>{},list:async()=>[{path:'all',specialUse:'\\All'},{path:'trash',specialUse:'\\Trash'}],getMailboxLock:async path=>{folder=path;return {release(){}};},search:async()=>[...(folder==='all'?all:trash).keys()],fetchOne:async uid=>{const entry=(folder==='all'?all:trash).get(uid);return {size:1000,internalDate:entry.received,source:entry.mail};},messageMove:async(uid,path,options)=>{assert.equal(folder,'all');assert.equal(path,'trash');assert.deepEqual(options,{uid:true});trash.set(uid,all.get(uid));all.delete(uid);actions.push(['move',uid]);return true;},messageDelete:async(uid,options)=>{assert.equal(folder,'trash');assert.deepEqual(options,{uid:true});trash.delete(uid);actions.push(['delete',uid]);return true;}}};}
test('Retenção Gmail exclui seletivamente somente o backup vencido; simulação não altera caixa',async()=>{
 let f=fixture();const dry=await retainGmailBackups({env,now,dryRun:true,client:f.client,parser:async v=>v});assert.equal(dry.expired,1);assert.deepEqual(f.actions,[]);
 f=fixture();const result=await retainGmailBackups({env,now,client:f.client,parser:async v=>v});assert.equal(result.deleted,1);assert.deepEqual(f.actions,[['move',1],['delete',1]]);
 f=fixture({fresh:false});assert.equal((await retainGmailBackups({env,now,client:f.client,parser:async v=>v})).skipped,'no-recent-verified-backup');assert.deepEqual(f.actions,[]);
 f=fixture({uidPlus:false});await assert.rejects(()=>retainGmailBackups({env,now,client:f.client}),/UID/);assert.deepEqual(f.actions,[]);
});
