import {test} from 'node:test';
import assert from 'node:assert/strict';
import {sendRecovery} from '../server/mail.js';
test('Recuperação: envio autenticado, confirmação e falha explícita',async()=>{
 delete process.env.SMTP_HOST;delete process.env.SMTP_USER;delete process.env.SMTP_PASSWORD;
 process.env.RESEND_API_KEY='TEST-ONLY';process.env.EMAIL_FROM='Conecta <test@example.com>';process.env.APP_PUBLIC_URL='https://app.example.com';
 let payload;const sent=await sendRecovery('student@example.com','isolated-token',{fetcher:async(url,options)=>{assert.equal(url,'https://api.resend.com/emails');assert.equal(options.method,'POST');payload=JSON.parse(options.body);return {ok:true,json:async()=>({id:'test-email-id'})};}});
 assert.equal(sent,true);assert.equal(payload.to[0],'student@example.com');assert.ok(payload.text.includes('https://app.example.com/?reset=isolated-token'));
 await assert.rejects(()=>sendRecovery('student@example.com','isolated-token',{fetcher:async()=>({ok:false,status:403})}),/recusou o envio/);
 await assert.rejects(()=>sendRecovery('student@example.com','isolated-token',{fetcher:async()=>({ok:true,json:async()=>({})})}),/não confirmou/);
});
test('SMTP: TLS, senha de app e confirmação do destinatário',async()=>{
 process.env.SMTP_HOST='smtp.gmail.com';process.env.SMTP_PORT='465';process.env.SMTP_USER='sender@example.com';process.env.SMTP_PASSWORD='TEST-ONLY';process.env.APP_PUBLIC_URL='https://app.example.com';delete process.env.EMAIL_FROM;
 let closed=false;const transportFactory=options=>{assert.equal(options.secure,true);assert.equal(options.auth.user,'sender@example.com');return {sendMail:async message=>{assert.equal(message.from,'sender@example.com');assert.ok(message.text.includes('reset=isolated-token'));return {accepted:['student@example.com'],rejected:[]};},close:()=>{closed=true;}};};
 assert.equal(await sendRecovery('student@example.com','isolated-token',{transportFactory}),true);assert.equal(closed,true);
 await assert.rejects(()=>sendRecovery('student@example.com','isolated-token',{transportFactory:()=>({sendMail:async()=>({accepted:[],rejected:['student@example.com']})})}),/não confirmou/);
});
