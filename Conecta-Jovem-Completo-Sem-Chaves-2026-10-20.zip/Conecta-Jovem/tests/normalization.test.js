import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
const dir=mkdtempSync(path.join(tmpdir(),'conecta-normalized-'));process.env.DB_PATH=path.join(dir,'migration.sqlite');process.env.ADMIN_PASSWORD='Testing2026!safe';
const {run,close}=await import('../server/db.js');const {migrateNormalized,readProfile,saveProfile}=await import('../server/normalize.js');
test('Backfill preserva texto legado e não sobrescreve o modelo normalizado restaurado',async()=>{
 try{
  const id=Number((await run("INSERT INTO users(name,email,password,role) VALUES('Migrado','migration@example.invalid','disabled','student')")).lastInsertRowid);
  await run('INSERT INTO profiles VALUES(?,?)',id,JSON.stringify({course:'Curso antigo',institution:'Instituição',city:'São Paulo',availability:'Tarde',modality:'Todas',skills:['JavaScript'],projects:'Projeto anterior em texto',courses:'Curso adicional anterior',languages:'Inglês'}));
  await migrateNormalized();const p=await readProfile(id);assert.equal(p.projectEntries[0].description,'Projeto anterior em texto');assert.equal(p.courseEntries[0].title,'Curso adicional anterior');
  await saveProfile(id,{...p,educations:[{course:'Curso novo',institution:'Outra instituição',semester:'3',period:'2026'}]});
  await run("DELETE FROM schema_migrations WHERE name='003-backfill'");await migrateNormalized();const restored=await readProfile(id);assert.equal(restored.educations[0].course,'Curso novo','Arquivo legado não pode substituir dados atuais restaurados');assert.equal(restored.projectEntries[0].description,'Projeto anterior em texto');
 }finally{await close();rmSync(dir,{recursive:true,force:true});}
});
