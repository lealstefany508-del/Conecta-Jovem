import {test} from 'node:test';
import assert from 'node:assert/strict';
import {chromium} from '@playwright/test';
import {AxeBuilder} from '@axe-core/playwright';
import {spawn} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';

test('Admin: acesso restrito, moderação, justificativa e auditoria no navegador',{timeout:120000},async()=>{
 const dir=mkdtempSync(path.join(tmpdir(),'conecta-admin-')),base='http://127.0.0.1:3108',cookies={};
 const server=spawn(process.execPath,['server/index.js'],{env:{...process.env,DB_PATH:process.env.TEST_DATABASE_URL?'':path.join(dir,'admin.sqlite'),DATABASE_URL:process.env.TEST_DATABASE_URL||'',PORT:'3108',ADMIN_EMAIL:'admin@test.local',ADMIN_PASSWORD:'Testing2026!safe',SMTP_USER:'',SMTP_PASSWORD:'',RESEND_API_KEY:'',ADZUNA_APP_ID:'',ADZUNA_APP_KEY:''},stdio:'ignore'});let browser;
 async function req(who,url,method='GET',body){const r=await fetch(base+'/api'+url,{method,headers:{'Content-Type':'application/json',Cookie:cookies[who]||''},body:body?JSON.stringify(body):undefined});if(r.headers.get('set-cookie'))cookies[who]=r.headers.get('set-cookie').split(';')[0];return {status:r.status,data:await r.json()};}
 try{
  let ready=false;for(let i=0;i<100;i++){try{await fetch(base);ready=true;break;}catch{await new Promise(r=>setTimeout(r,100));}}assert.ok(ready);
  const student={name:'Estudante isolado',email:'admin-student@example.invalid',password:'Testing2026!safe',role:'student',birthDate:'2000-01-01'};
  assert.equal((await req('s','/auth/register','POST',student)).status,201);
  const studentId=(await req('s','/me')).data.user.id;
  assert.equal((await req('s','/admin')).status,403);assert.equal((await req('s','/admin/operations')).status,403);
  assert.equal((await req('s','/admin/action','POST',{type:'user',id:studentId,active:false,reason:'Sem autorização administrativa'})).status,403);
  assert.equal((await req('c','/auth/register','POST',{...student,role:'company',email:'admin-company@example.invalid',companyName:'Empresa isolada admin',identifier:'TEST-ADMIN'})).status,201);
  await req('admin','/auth/login','POST',{email:'admin@test.local',password:'Testing2026!safe'});
  assert.equal((await req('admin','/admin/action','POST',{type:'user',id:studentId,active:false,reason:123})).status,400);
  assert.equal((await req('admin','/admin/action','POST',{type:'user',id:studentId,active:'false',reason:'Valor de situação inválido'})).status,400);
  browser=await chromium.launch({headless:true,executablePath:chromium.executablePath()});const context=await browser.newContext();const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(base+'/admin');await page.getByLabel('E-mail',{exact:true}).fill('admin@test.local');await page.getByLabel('Senha',{exact:true}).fill('Testing2026!safe');await page.getByRole('button',{name:'Entrar na minha conta',exact:true}).click();await page.getByRole('heading',{name:'Administração',exact:true}).waitFor();assert.equal(new URL(page.url()).pathname,'/admin');
  async function section(label){await page.getByRole('navigation',{name:'Seções administrativas'}).getByRole('button',{name:label,exact:true}).click();}
  async function confirm(){await page.getByLabel('Motivo obrigatório').fill('Ação isolada de validação administrativa');await page.getByRole('button',{name:'Confirmar ação',exact:true}).click();await page.getByRole('dialog').waitFor({state:'hidden'});}
  await page.getByLabel('Buscar em contas').fill('Estudante isolado');await page.locator('.admin-row').filter({hasText:'admin-student@example.invalid'}).getByRole('button',{name:'Suspender',exact:true}).click();await confirm();assert.equal((await req('s','/me')).status,401);await page.getByRole('button',{name:'Reativar',exact:true}).click();await confirm();await req('s','/auth/login','POST',{email:student.email,password:student.password});
  await section('Empresas');await page.getByRole('button',{name:'Aprovar',exact:true}).click();await confirm();assert.equal((await req('c','/me')).data.company.verification,'Aprovada');
  const job={title:'Oportunidade isolada admin',description:'Somente no banco temporário de testes',area:'Tecnologia',city:'São Paulo',modality:'Remoto',deadline:'2027-12-31',activities:'Aprender',benefits:'Mentoria',shift:'Tarde',salary:1800,hours:6,courses:['Tecnologia'],skills:['JavaScript'],experience:false};const created=await req('c','/company/jobs','POST',job);assert.equal(created.status,201);const jid=created.data.id;
  await req('s','/profile','PUT',{city:'São Paulo',course:'Tecnologia',institution:'Instituto',availability:'Tarde',modality:'Todas',skills:['JavaScript'],visibility:'Candidaturas'});assert.equal((await req('s',`/jobs/${jid}/apply`,'POST')).status,201);const aid=(await req('s','/applications')).data[0].id;
  await req('s','/reports','POST',{jobId:jid,reason:'Denúncia isolada para validar moderação'});await req('s','/privacy/request','POST',{reason:'Pedido isolado de acesso aos meus dados'});
  for(const status of ['Em análise','Pré-selecionada','Entrevista','Aprovada'])assert.equal((await req('c',`/applications/${aid}`,'PATCH',{status,reason:'Etapa no teste isolado'})).status,200);
  await page.reload();await page.getByRole('heading',{name:'Administração',exact:true}).waitFor();await section('Vagas');await page.getByRole('button',{name:'Suspender',exact:true}).click();await confirm();assert.equal((await req('s','/jobs')).data.length,0);await page.getByRole('button',{name:'Liberar',exact:true}).click();await confirm();assert.equal((await req('s','/jobs')).data.length,1);
  await section('Denúncias');await page.getByRole('button',{name:'Registrar análise',exact:true}).click();await confirm();await page.getByText('Analisada',{exact:true}).waitFor();
  await section('Candidaturas');await page.getByRole('button',{name:'Corrigir etapa',exact:true}).click();await page.getByLabel('Etapa corrigida').selectOption('Entrevista');await page.getByLabel('Justificativa da correção').fill('Correção isolada de resultado lançado incorretamente');await page.getByRole('button',{name:'Registrar correção',exact:true}).click();await page.getByRole('dialog').waitFor({state:'hidden'});assert.equal((await req('s','/applications')).data[0].history.at(-1).previous_status,'Aprovada');await page.getByText('Em andamento na empresa',{exact:true}).waitFor();assert.equal(await page.getByRole('button',{name:'Corrigir etapa',exact:true}).count(),0);
  await section('Operação');await page.getByRole('button',{name:'Registrar resposta',exact:true}).click();await confirm();await page.getByText('Estudante isolado · Respondida',{exact:true}).waitFor();await page.getByText('Nenhuma execução de backup registrada.',{exact:true}).waitFor();
  await section('Auditoria');await page.getByText('Correção isolada de resultado lançado incorretamente',{exact:true}).waitFor();assert.ok((await req('admin','/admin')).data.audit.length>=7);
  for(const width of [360,768,1280]){await page.setViewportSize({width,height:900});for(const label of ['Contas','Empresas','Vagas','Denúncias','Candidaturas','Operação','Auditoria']){await section(label);assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),label+' em '+width);}}
  const axe=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21aa']).analyze();assert.deepEqual(axe.violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary}))})),[]);assert.deepEqual(errors,[]);
 }finally{await browser?.close();server.kill();await new Promise(r=>server.once('exit',r));rmSync(dir,{recursive:true,force:true});}
});
