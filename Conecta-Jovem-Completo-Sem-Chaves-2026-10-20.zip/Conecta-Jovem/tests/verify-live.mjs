// Verificação manual da interface com o cache real, em cópia temporária do banco.
import '../server/env.js';
import {DatabaseSync} from 'node:sqlite';
import {mkdtempSync,rmSync} from 'node:fs';
import path from 'node:path';
import {tmpdir} from 'node:os';
import {spawn} from 'node:child_process';
import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
const dir=mkdtempSync(path.join(tmpdir(),'conecta-live-copy-')),copy=path.join(dir,'copy.sqlite');
const db=new DatabaseSync(process.env.DB_PATH||'data/conecta.sqlite');
const count=db.prepare('SELECT count(*) n FROM external_jobs').get().n;assert.ok(count>0,'Cache real deve existir');db.prepare('VACUUM INTO ?').run(copy);db.close();
const check=new DatabaseSync(copy);assert.equal(check.prepare('PRAGMA integrity_check').get().integrity_check,'ok');assert.equal(check.prepare('SELECT count(*) n FROM external_jobs').get().n,count);check.close();
const server=spawn(process.execPath,['server/index.js'],{env:{...process.env,PORT:'3103',DB_PATH:copy},stdio:'ignore'});let browser;
try{
 for(let i=0;i<100;i++){try{await fetch('http://127.0.0.1:3103');break;}catch{await new Promise(r=>setTimeout(r,100));}}
 browser=await chromium.launch({headless:true,executablePath:chromium.executablePath()});const context=await browser.newContext({viewport:{width:1280,height:900}});const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:3103');
 await page.getByRole('button',{name:'Comece aqui'}).click();await page.getByLabel('Seu nome',{exact:true}).fill('Verificação isolada');await page.getByLabel('E-mail',{exact:true}).fill('live-copy@test.local');await page.getByLabel('Senha',{exact:true}).fill('Testing2026!safe');await page.getByLabel('Data de nascimento *',{exact:true}).fill('2000-01-01');await page.locator('input[type=checkbox]').check();await page.getByRole('button',{name:'Criar minha conta'}).click();await page.getByRole('heading',{name:'Olá, Verificação'}).waitFor();await page.getByRole('button',{name:'Conhecer vaga'}).first().waitFor();await page.locator('.source-credit img').first().evaluate(img=>new Promise(resolve=>{if(img.complete)resolve();else{img.addEventListener('load',resolve,{once:true});img.addEventListener('error',resolve,{once:true});setTimeout(resolve,5000);}}));await page.screenshot({path:'docs/screenshots/vagas-reais-desktop.png',fullPage:true});
 for(const width of [360,768,1280]){await page.setViewportSize({width,height:900});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),`Sem overflow com dados reais em ${width}px`);if(width===360)await page.screenshot({path:'docs/screenshots/vagas-reais-mobile.png',fullPage:true});}
 await page.getByRole('button',{name:'Salvar oportunidade',exact:true}).first().click();await page.getByRole('status').filter({hasText:'Oportunidade salva.'}).waitFor();await page.getByRole('button',{name:'Vagas salvas',exact:true}).click();await page.getByRole('button',{name:'Conhecer vaga',exact:true}).waitFor();assert.equal(await page.getByRole('button',{name:'Conhecer vaga',exact:true}).count(),1,'Favorito externo persistido');await page.getByRole('button',{name:'Explorar vagas',exact:true}).click();await page.getByRole('button',{name:'Conhecer vaga'}).first().click();const link=page.getByRole('link',{name:'Candidatar-me na fonte'});await link.waitFor();const href=await link.getAttribute('href');assert.equal(new URL(href).hostname,'www.adzuna.com.br');await page.screenshot({path:'docs/screenshots/vaga-real-detalhes.png',fullPage:true});
 const cookie=(await context.cookies()).map(c=>c.name+'='+c.value).join(';');const durations=await Promise.all(Array.from({length:100},async()=>{const start=performance.now();const r=await fetch('http://127.0.0.1:3103/api/external/jobs',{headers:{Cookie:cookie}});assert.equal(r.status,200);const data=await r.json();assert.equal(data.jobs.length,count);return performance.now()-start;}));
 assert.ok(Math.max(...durations)<3000,'Consultas simultâneas em menos de 3s');assert.deepEqual(errors,[]);console.log(JSON.stringify({realJobs:count,interface:'OK',breakpoints:[360,768,1280],originalApplicationLink:'OK',restoredBackup:'OK',load:{concurrentRequests:100,maxMs:Math.round(Math.max(...durations))},javascriptErrors:errors.length},null,2));
}finally{await browser?.close();server.kill();await new Promise(r=>server.once('exit',r));rmSync(dir,{recursive:true,force:true});}
