import {test} from 'node:test';
import assert from 'node:assert/strict';
import {chromium} from '@playwright/test';
import {AxeBuilder} from '@axe-core/playwright';
import {spawn} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {DatabaseSync} from 'node:sqlite';
test('Acessibilidade, manifest e offline sem cache de dados pessoais',{timeout:120000},async()=>{
 const dir=mkdtempSync(path.join(tmpdir(),'conecta-access-'));const base='http://127.0.0.1:3103';
 const fixture=new DatabaseSync(path.join(dir,'access.sqlite'));fixture.exec('CREATE TABLE external_jobs(source TEXT,source_id TEXT,data TEXT,updated INTEGER,PRIMARY KEY(source,source_id));CREATE TABLE integrations(source TEXT PRIMARY KEY,last_success INTEGER,last_attempt INTEGER,error TEXT);');fixture.prepare('INSERT INTO external_jobs VALUES(?,?,?,?)').run('Adzuna','access-fixture',JSON.stringify({id:'access-fixture',title:'Estágio em Tecnologia',company:'Empresa isolada de validação',city:'São Paulo',area:'TI',description:'Somente no banco de testes de acessibilidade.',url:'https://www.adzuna.com.br/jobs/details/access-fixture',source:'Adzuna',updated:Date.now()}),Date.now());fixture.prepare('INSERT INTO integrations(source,last_success,last_attempt) VALUES(?,?,?)').run('Adzuna',Date.now(),Date.now());fixture.close();
 const server=spawn(process.execPath,['server/index.js'],{env:{...process.env,DB_PATH:path.join(dir,'access.sqlite'),PORT:'3103',ADZUNA_APP_ID:'TEST-ONLY',ADZUNA_APP_KEY:'TEST-ONLY',SMTP_USER:'',SMTP_PASSWORD:'',RESEND_API_KEY:'',ADMIN_PASSWORD:'Testing2026!safe'},stdio:'ignore'});let browser;
 try{for(let i=0;i<100;i++){try{await fetch(base);break;}catch{await new Promise(r=>setTimeout(r,100));}}
 const manifest=await (await fetch(base+'/manifest.webmanifest')).json();assert.equal(manifest.display,'standalone');for(const icon of manifest.icons)assert.equal((await fetch(base+icon.src)).status,200);
 browser=await chromium.launch({headless:true,executablePath:chromium.executablePath()});const context=await browser.newContext();const page=await context.newPage();
 const audit=async()=>{const result=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21aa']).analyze();assert.deepEqual(result.violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary}))})),[]);};
 await page.goto(base+'/?guardian=isolated-access-token');await page.getByRole('heading',{name:'Autorizar participação no Conecta Jovem'}).waitFor();await audit();await page.goto(base);await page.getByRole('heading',{name:'Que bom ter você aqui.'}).waitFor();await audit();await page.getByRole('button',{name:'Comece aqui'}).click();await audit();
 await page.getByLabel('Seu nome',{exact:true}).fill('Teste acessibilidade');await page.getByLabel('E-mail',{exact:true}).fill('access@example.invalid');await page.getByLabel('Senha',{exact:true}).fill('Testing2026!safe');await page.getByLabel('Data de nascimento *',{exact:true}).fill('2000-01-01');await page.locator('input[type=checkbox]').check();await page.getByRole('button',{name:'Criar minha conta'}).click();await page.getByRole('heading',{name:'Olá, Teste'}).waitFor();await page.getByRole('heading',{name:'Estágio em Tecnologia',exact:true}).waitFor();await audit();
 await page.getByRole('button',{name:'Meu perfil',exact:true}).click();await page.getByRole('heading',{name:'Meu perfil profissional'}).waitFor();await audit();
 await page.getByRole('button',{name:'Configurações',exact:true}).click();await page.getByRole('heading',{name:'Você no controle.'}).waitFor();await audit();
 await page.evaluate(()=>navigator.serviceWorker.ready);await page.reload();await page.waitForFunction(()=>Boolean(navigator.serviceWorker.controller));
 const keys=await page.evaluate(async()=>{const urls=[];for(const k of await caches.keys())for(const r of await (await caches.open(k)).keys())urls.push(r.url);return urls;});assert.ok(keys.every(url=>!url.includes('/api/')&&!url.includes('reset=')&&!url.includes('confirmAlerts=')));
 await context.setOffline(true);await page.goto(base+'/offline-validation');await page.getByRole('heading',{name:'Vamos nos conectar de novo.'}).waitFor();
 }finally{await browser?.close();server.kill();await new Promise(r=>server.once('exit',r));rmSync(dir,{recursive:true,force:true});}
});
