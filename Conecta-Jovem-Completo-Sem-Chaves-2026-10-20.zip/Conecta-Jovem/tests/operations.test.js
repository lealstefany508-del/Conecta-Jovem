import {test} from 'node:test';
import assert from 'node:assert/strict';
import {encryptSnapshot,decryptSnapshot,createSnapshot,dailyBackup,operationalEmail} from '../server/operations.js';
import {monitorCycle} from '../scripts/monitor.mjs';
const key='a1'.repeat(32),env={BACKUP_ENCRYPTION_KEY:key,OPERATIONS_EMAIL:'project@example.com',SMTP_USER:'project@example.com',APP_PUBLIC_URL:'https://project.example.com'};
const snapshot={version:2,created:'2026-10-01T00:00:00.000Z',data:{users:[{id:1,name:'Student'}],educations:[{id:'uuid',user_id:1,course:'Computing'}]}};
test('encrypted snapshots authenticate contents, reject tampering and accept legacy JSON',()=>{
 const encrypted=encryptSnapshot(snapshot,key);assert.deepEqual(decryptSnapshot(encrypted,key),snapshot);assert.equal(encrypted.includes(Buffer.from('Computing')),false);
 const changed=JSON.parse(encrypted);changed.content=Buffer.from('tampered').toString('base64');assert.throws(()=>decryptSnapshot(Buffer.from(JSON.stringify(changed)),key));assert.throws(()=>decryptSnapshot(encrypted,'b2'.repeat(32)));
 assert.deepEqual(decryptSnapshot(Buffer.from(JSON.stringify({...snapshot,version:1}))),{...snapshot,version:1});assert.throws(()=>encryptSnapshot(snapshot,'short'));assert.throws(()=>encryptSnapshot({version:2,data:{injected:[]}},key));
});
test('snapshot uses consistent read-only transaction and rolls back failures',async()=>{
 const statements=[];const client={query:async sql=>{statements.push(sql);if(sql.startsWith('SELECT tablename'))return {rows:[{tablename:'users'},{tablename:'educations'}]};if(sql==='SELECT * FROM "users"')return {rows:snapshot.data.users};if(sql==='SELECT * FROM "educations"')return {rows:snapshot.data.educations};return {rows:[]};}};
 assert.deepEqual((await createSnapshot(client)).data,snapshot.data);assert.equal(statements[0],'BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');assert.equal(statements.at(-1),'COMMIT');
 await assert.rejects(()=>createSnapshot({query:async sql=>{if(sql==='ROLLBACK'){statements.push(sql);return;}if(sql.startsWith('SELECT'))throw Error('offline');}}));assert.equal(statements.at(-1),'ROLLBACK');
});
test('backup sends encrypted attachment only to operational sender and deduplicates each day',async()=>{
 let sent=false,mailCount=0,released=false;const client={release:()=>{released=true;},query:async(sql,args)=>{
 if(sql.includes('pg_try_advisory_xact_lock'))return {rows:[{locked:true}]};if(sql.startsWith('SELECT status'))return {rows:sent?[{status:'sent'}]:[]};if(sql.startsWith('SELECT tablename'))return {rows:[{tablename:'users'}]};if(sql==='SELECT * FROM "users"')return {rows:snapshot.data.users};if(sql.includes("SET status='sent'"))sent=true;return {rows:[]};}};
 const options={pool:{connect:async()=>client},env,mailer:async(to,subject,text,{attachments})=>{mailCount++;assert.equal(to,env.SMTP_USER);assert.deepEqual(decryptSnapshot(attachments[0].content,key).data.users,snapshot.data.users);}};
 assert.equal((await dailyBackup(options)).sent,true);assert.equal((await dailyBackup(options)).reason,'sent');assert.equal(mailCount,1);assert.equal(released,true);
 assert.throws(()=>operationalEmail({...env,OPERATIONS_EMAIL:'personal@example.com'}));
});
test('local monitor alerts after consecutive failures and once on recovery, without database availability',async()=>{
 let state={status:'ok',failures:0},healthy=false,alerts=0;const options={env,loadState:()=>state,storeState:s=>{state=s;},fetcher:async()=>({ok:healthy,status:healthy?200:503,json:async()=>({status:healthy?'ok':'unavailable'})}),mailer:async()=>{alerts++;}};
 assert.equal((await monitorCycle(options)).notified,false);assert.equal((await monitorCycle(options)).notified,true);assert.equal((await monitorCycle(options)).notified,false);assert.equal(alerts,1);
 healthy=true;assert.equal((await monitorCycle(options)).notified,true);assert.equal((await monitorCycle(options)).notified,false);assert.equal(alerts,2);
});
test('failed notification is retried because monitor does not record it as sent',async()=>{
 let writes=0;const options={env,loadState:()=>({status:'ok',failures:1}),storeState:()=>{writes++;},fetcher:async()=>{throw Error('unreachable');},mailer:async()=>{throw Error('SMTP offline');}};
 await assert.rejects(()=>monitorCycle(options),/SMTP offline/);assert.equal(writes,0);
});

