import '../server/env.js';
import {retainGmailBackups,pruneLocalBackups} from '../server/backup-retention.js';
try{const dryRun=process.argv.includes('--dry-run');const remote=await retainGmailBackups({dryRun});const local=dryRun?{skipped:'dry-run'}:pruneLocalBackups();console.log(JSON.stringify({remote,local}));}catch{console.error('Não foi possível verificar a retenção. Nenhuma limpeza ampla é realizada. Confira conexão IMAP e chave privada.');process.exitCode=1;}
