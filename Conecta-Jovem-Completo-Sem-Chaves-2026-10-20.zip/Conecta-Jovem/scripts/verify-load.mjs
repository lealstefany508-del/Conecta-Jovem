import '../server/env.js';
import pg from 'pg';
import {readFileSync,readdirSync,mkdirSync,writeFileSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {randomBytes} from 'node:crypto';
import {performance} from 'node:perf_hooks';

// Never target the public app: all fixtures belong to a disposable test schema.
const testUrl=new URL(readFileSync('.env.neon-test','utf8').trim());
testUrl.hostname=testUrl.hostname.replace('-pooler','');
testUrl.searchParams.set('sslmode','verify-full');
if(!process.env.DATABASE_URL)throw new Error('DATABASE_URL deve identificar o endpoint de produção para conferir isolamento.');
if(testUrl.hostname===new URL(process.env.DATABASE_URL).hostname.replace('-pooler',''))throw new Error('A branch de carga deve usar endpoint diferente da produção.');
const schema=`load_${Date.now()}_${randomBytes(4).toString('hex')}`;
const client=new pg.Client({connectionString:testUrl.href,enableChannelBinding:true,connectionTimeoutMillis:15000});
const runtime=new URL(testUrl);runtime.searchParams.set('options',`-c search_path=${schema}`);
const port=Number(process.env.LOAD_TEST_PORT||3115),base=`http://127.0.0.1:${port}`;
const childEnv={...process.env,DATABASE_URL:runtime.href,DB_PATH:'',PORT:String(port),NODE_ENV:'production',VERCEL:'',ADZUNA_APP_ID:'ISOLATED-FIXTURE',ADZUNA_APP_KEY:'ISOLATED-FIXTURE',SMTP_HOST:'',SMTP_USER:'',SMTP_PASSWORD:'',RESEND_API_KEY:''};
let child,created=false;await client.connect();
const quantile=(values,q)=>values[Math.max(0,Math.ceil(values.length*q)-1)];
try{
 await client.query(`CREATE SCHEMA ${schema}`);created=true;
 await client.query(`SET search_path TO ${schema}`);
 for(const file of readdirSync('server/migrations').filter(f=>f.endsWith('.sql')).sort())await client.query(readFileSync(`server/migrations/${file}`,'utf8'));
 const now=Date.now(),sessions=[];
 const company=(await client.query("INSERT INTO companies(name,city,description,identifier) VALUES('Empresa fictícia de carga','São Paulo','Fixture isolada','TEST-LOAD') RETURNING id")).rows[0].id;
 await client.query("INSERT INTO company_verifications(company_id,status,updated) VALUES($1,'Aprovada',$2)",[company,now]);
 for(let i=0;i<100;i++){
  const id=(await client.query("INSERT INTO users(name,email,password,role) VALUES($1,$2,'disabled-fixture','student') RETURNING id",[`Sessão de carga ${i}`,`load-${i}@example.invalid`])).rows[0].id;
  await client.query('INSERT INTO profiles(user_id,data) VALUES($1,$2)',[id,JSON.stringify({city:'São Paulo',course:'Tecnologia',institution:'Instituição de teste',semester:'1',availability:'Manhã',modality:'Presencial',skills:['JavaScript'],notifications:false})]);
  const token=randomBytes(32).toString('hex');sessions.push(token);
  await client.query('INSERT INTO sessions(token,user_id,expires) VALUES($1,$2,$3)',[token,id,now+3600000]);
 }
 for(let i=0;i<20;i++)await client.query('INSERT INTO jobs(company_id,data,status) VALUES($1,$2,$3)',[company,JSON.stringify({title:`Estágio de carga ${i}`,area:'Tecnologia',city:'São Paulo',course:'Tecnologia',courses:['Tecnologia'],skills:['JavaScript'],salary:1000,hours:6,modality:'Presencial',shift:'Manhã',deadline:'2099-12-31',description:'Fixture isolada',activities:'Atividades de teste',benefits:'Benefícios de teste',experience:false,kind:'Estágio'}),'Aberta']);
 for(let i=0;i<100;i++)await client.query('INSERT INTO external_jobs(source,source_id,data,updated) VALUES($1,$2,$3,$4)',['Adzuna',`fixture-${i}`,JSON.stringify({id:`fixture-${i}`,title:`Estágio externo de carga ${i}`,company:'Empresa fictícia de carga',city:'São Paulo',description:'Fixture isolada, nunca publicada',url:'https://example.invalid',source:'Adzuna'}),now]);
 await client.query("INSERT INTO integrations(source,last_success,last_attempt) VALUES('Adzuna',$1,$1)",[now]);
 // Import only the persistence migration, without starting another HTTP listener.
 const migrated=await new Promise((resolve,reject)=>{const p=spawn(process.execPath,['--input-type=module','-e',"const {migrateNormalized}=await import('./server/normalize.js');await migrateNormalized();const {close}=await import('./server/db.js');await close();"],{env:childEnv,stdio:['ignore','pipe','pipe']});let err='';p.stderr.on('data',d=>{err=(err+d).slice(-2000)});p.on('error',reject);p.on('exit',code=>code===0?resolve():reject(new Error('Backfill isolado falhou (código '+code+'). Confira a migração no ambiente de teste.')));});
 child=spawn(process.execPath,['server/index.js'],{env:childEnv,stdio:['ignore','pipe','pipe']});let logs='';child.stdout.on('data',d=>{logs=(logs+d).slice(-2000)});child.stderr.on('data',d=>{logs=(logs+d).slice(-2000)});
 let ready=false;
 for(let i=0;i<100;i++){if(child.exitCode!==null)throw new Error('Servidor de carga encerrou (código '+child.exitCode+'). Confira configuração e migrações isoladas.');try{const r=await fetch(`${base}/api/health`,{signal:AbortSignal.timeout(500)});if(r.ok){ready=true;break;}}catch{}await new Promise(resolve=>setTimeout(resolve,100));}
 if(!ready)throw new Error('Servidor de carga não iniciou em 10 segundos. Confira a porta isolada e configuração de teste.');
 const rounds=[];
 for(const route of ['/api/jobs','/api/external/jobs'])for(let round=1;round<=3;round++){
  const batchStarted=performance.now();
  const results=await Promise.all(sessions.map(async token=>{const start=performance.now();try{const response=await fetch(base+route,{headers:{Cookie:`cj_session=${token}`},signal:AbortSignal.timeout(15000)});const body=await response.json();const rows=Array.isArray(body)?body:body.jobs;return {ms:performance.now()-start,status:response.status,valid:response.ok&&Array.isArray(rows)&&rows.length===(route==='/api/jobs'?20:100)};}catch{return {ms:performance.now()-start,status:0,valid:false};}}));
  const sorted=results.map(r=>r.ms).sort((a,b)=>a-b),roundResult={route,round,requests:100,distinctSessions:100,errors:results.filter(r=>!r.valid).length,statuses:[...new Set(results.map(r=>r.status))],durationMs:performance.now()-batchStarted,minMs:sorted[0],medianMs:quantile(sorted,.5),p95Ms:quantile(sorted,.95),p99Ms:quantile(sorted,.99),maxMs:sorted.at(-1)};
  rounds.push(roundResult);console.log(JSON.stringify(roundResult));
 }
 const persisted=(await client.query('SELECT (SELECT count(*) FROM users) students,(SELECT count(*) FROM sessions) sessions,(SELECT count(*) FROM job_details) native_jobs,(SELECT count(*) FROM external_jobs) external_jobs')).rows[0];
 const evidence={runtime:{node:process.version,platform:process.platform,apiHost:'127.0.0.1',database:'PostgreSQL Neon isolated branch'},persisted,executedAt:new Date().toISOString(),scenario:'API Node local + PostgreSQL Neon branch isolada; 100 estudantes/sessões distintas; 3 rodadas simultâneas por endpoint',fixtures:{students:100,sessions:100,nativeJobs:20,externalJobs:100},targetMaxMs:3000,passes:rounds.every(r=>r.errors===0&&r.maxMs<3000),limits:['Não mede Vercel pública, renderização, login, escrita, candidatos simultâneos nem pessoas reais.','Latência inclui o trajeto desta máquina à branch Neon; fixtures nunca entram na produção.'],rounds};
 mkdirSync('docs/evidencias',{recursive:true});writeFileSync('docs/evidencias/carga.json',JSON.stringify(evidence,null,2)+'\n');
 if(!evidence.passes)throw new Error('Carga excedeu a meta de 3 segundos ou retornou conteúdo/status inválido. Consulte docs/evidencias/carga.json.');
}finally{
 if(child&&child.exitCode===null){const exited=new Promise(resolve=>child.once('exit',resolve));child.kill();await exited;}
 try{if(created){await client.query('SET search_path TO public');await client.query(`DROP SCHEMA ${schema} CASCADE`);}}finally{await client.end();}
}



