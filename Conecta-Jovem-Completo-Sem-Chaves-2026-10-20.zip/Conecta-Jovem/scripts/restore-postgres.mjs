import '../server/env.js';
import pg from 'pg';
import {readFileSync} from 'node:fs';
import {decryptSnapshot,snapshotTables} from '../server/operations.js';
const quote=name=>'"'+name.replaceAll('"','""')+'"';
export async function restoreSnapshot(file,connectionString,{clientFactory=options=>new pg.Client(options),productionUrl=process.env.DATABASE_URL,key=process.env.BACKUP_ENCRYPTION_KEY}={}){
 if(!connectionString)throw new Error('Defina RESTORE_DATABASE_URL para um banco vazio isolado.');
 const url=new URL(connectionString);if(productionUrl){const production=new URL(productionUrl);if(url.hostname.replace('-pooler','')===production.hostname.replace('-pooler',''))throw new Error('Restauração direta em produção não é permitida. Valide em uma branch isolada.');}
 url.hostname=url.hostname.replace('-pooler','');url.searchParams.set('sslmode','verify-full');
 const snapshot=decryptSnapshot(readFileSync(file),key),client=clientFactory({connectionString:url.href});await client.connect();
 const tables=snapshotTables.filter(t=>t!=='schema_migrations'&&Object.hasOwn(snapshot.data,t));
 try{
  await client.query('BEGIN');
  for(const table of tables)if(Number((await client.query(`SELECT count(*) FROM ${quote(table)}`)).rows[0].count)>0)throw new Error('Destino não vazio: '+table);
  for(const table of tables){
   for(const row of snapshot.data[table]){const columns=Object.keys(row);await client.query(`INSERT INTO ${quote(table)}(${columns.map(quote).join(',')}) VALUES(${columns.map((_,i)=>'$'+(i+1)).join(',')})`,Object.values(row));}
   if(Number((await client.query(`SELECT count(*) FROM ${quote(table)}`)).rows[0].count)!==snapshot.data[table].length)throw Error('Contagem divergiu: '+table);
   const columns=(await client.query('SELECT column_name FROM information_schema.columns WHERE table_schema=current_schema() AND table_name=$1',[table])).rows;
   if(columns.some(c=>c.column_name==='id')){const sequence=(await client.query('SELECT pg_get_serial_sequence($1,$2) sequence',[table,'id'])).rows[0]?.sequence;if(sequence)await client.query(`SELECT setval($1::regclass,COALESCE((SELECT max(id) FROM ${quote(table)}),1),(SELECT count(*)>0 FROM ${quote(table)}))`,[sequence]);}
  }
  await client.query('COMMIT');return {restored:true,tables:tables.length,rows:tables.reduce((n,t)=>n+snapshot.data[t].length,0)};
 }catch(error){await client.query('ROLLBACK');throw error;}finally{await client.end();}
}
if(process.argv[1]?.endsWith('restore-postgres.mjs'))console.log(await restoreSnapshot(process.argv[2],process.env.RESTORE_DATABASE_URL));
