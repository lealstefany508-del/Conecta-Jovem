import '../server/env.js';
import {execFileSync} from 'node:child_process';
import {readFileSync,appendFileSync} from 'node:fs';
import {randomBytes} from 'node:crypto';
import path from 'node:path';
const cli=path.join(process.env.APPDATA,'npm/node_modules/vercel/dist/vc.js');
if(!process.env.CRON_SECRET){process.env.CRON_SECRET=randomBytes(32).toString('hex');appendFileSync('.env','\nCRON_SECRET='+process.env.CRON_SECRET+'\n');}
for(const key of ['DATABASE_URL','ADZUNA_APP_ID','ADZUNA_APP_KEY','CRON_SECRET','ADZUNA_LOCATION','APP_PUBLIC_URL','SMTP_HOST','SMTP_PORT','SMTP_USER','SMTP_PASSWORD','EMAIL_FROM','OPERATIONS_EMAIL','BACKUP_ENCRYPTION_KEY','BACKUP_RETENTION_ENABLED']){
 if(!process.env[key])continue;
 try{execFileSync(process.execPath,[cli,'env','add',key,'production','--force','--yes',...(['DATABASE_URL','ADZUNA_APP_KEY','CRON_SECRET','SMTP_PASSWORD','BACKUP_ENCRYPTION_KEY'].includes(key)?['--sensitive']:['--no-sensitive'])],{input:process.env[key],stdio:['pipe','pipe','pipe']});console.log(key+': configurado');}catch{throw new Error('Não foi possível configurar '+key+' na Vercel.');}
}
