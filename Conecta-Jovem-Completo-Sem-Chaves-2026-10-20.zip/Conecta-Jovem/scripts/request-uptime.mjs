import '../server/env.js';
import {createHash} from 'node:crypto';
import {writeFileSync,mkdirSync,existsSync} from 'node:fs';
const record='data/monitor/uptimerobot-request.json';
if(existsSync(record)&&!process.argv.includes('--retry'))throw new Error('Solicitação já registrada. Confirme o e-mail antes de repetir.');
const email=process.env.OPERATIONS_EMAIL,url=new URL('/api/health',process.env.APP_PUBLIC_URL).href;
if(email!==process.env.SMTP_USER||!email)throw new Error('Use a conta operacional do projeto.');
const endpoint='https://api.uptimerobot.com/agentic/agent-monitor';
const request=new URL(endpoint+'/challenge');request.searchParams.set('email',email);request.searchParams.set('url',url);
const response=await fetch(request,{signal:AbortSignal.timeout(20000)});if(!response.ok)throw new Error('Não foi possível solicitar configuração gratuita.');
const challenge=await response.json();if(typeof challenge.nonce!=='string'||!Number.isInteger(challenge.difficulty)||challenge.difficulty<0||challenge.difficulty>26)throw new Error('Desafio inesperado.');
let counter=0;const start=Date.now();for(;;counter++){const hash=createHash('sha256').update(`${challenge.nonce}|${counter}`).digest();let zeros=0;for(const byte of hash){if(byte===0)zeros+=8;else{zeros+=Math.clz32(byte)-24;break;}}if(zeros>=challenge.difficulty)break;if(Date.now()-start>45000)throw new Error('Desafio excedeu o tempo previsto.');}
const submitted=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,url,...challenge,counter}),signal:AbortSignal.timeout(20000)});
if(!submitted.ok)throw new Error('Solicitação recusada pelo serviço.');
mkdirSync('data/monitor',{recursive:true});writeFileSync(record,JSON.stringify({provider:'UptimeRobot',url,email,requestedAt:new Date().toISOString(),status:'awaiting-owner-confirmation',intervalSeconds:300},null,2));
console.log('Solicitação enviada ao UptimeRobot. HTTP 200 não comprova criação: confirme o e-mail e verifique o monitor no painel.');
