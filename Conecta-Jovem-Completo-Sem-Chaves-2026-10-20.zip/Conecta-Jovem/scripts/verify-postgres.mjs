import '../server/env.js';
import pg from 'pg';
import {readFileSync,readdirSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {scryptSync} from 'node:crypto';
const url=new URL(readFileSync('.env.neon-test','utf8').trim());url.hostname=url.hostname.replace('-pooler','');url.searchParams.set('sslmode','verify-full');
if(url.hostname===new URL(process.env.DATABASE_URL).hostname.replace('-pooler',''))throw new Error('Testes não podem usar o endpoint de produção.');
const client=new pg.Client({connectionString:url.href});await client.connect();
try{for(const [file,schema] of [['system','system_verification'],['product','product_verification'],['compliance','compliance_verification'],['browser','browser_verification'],['admin','admin_verification']]){
 await client.query(`DROP SCHEMA IF EXISTS ${schema} CASCADE`);
 await client.query(`CREATE SCHEMA ${schema}`);
 await client.query(`SET search_path TO ${schema}`);
 for(const file of readdirSync('server/migrations').filter(f=>f.endsWith('.sql')).sort())await client.query(readFileSync('server/migrations/'+file,'utf8')); 
 const salt='postgres-isolated-test';const password=salt+':'+scryptSync('Testing2026!safe',salt,64).toString('hex');
 await client.query("INSERT INTO users(name,email,password,role) VALUES('Administrador de teste','admin@test.local',$1,'admin')",[password]);
 const runtime=new URL(url);runtime.searchParams.set('options',`-c search_path=${schema}`);
 const code=await new Promise(resolve=>{const child=spawn(process.execPath,['--test',`tests/${file}.test.js`],{env:{...process.env,TEST_DATABASE_URL:runtime.href},stdio:'inherit'});child.on('exit',resolve);});
 if(code)throw new Error('Verificação PostgreSQL falhou: '+file);
 await client.query('SET search_path TO public');await client.query(`DROP SCHEMA ${schema} CASCADE`);
}console.log('Jornadas API e navegador validadas em PostgreSQL isolado.');}finally{await client.end();}
