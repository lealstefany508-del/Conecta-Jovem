import '../server/env.js';
import pg from 'pg';
import {readFileSync,readdirSync,mkdtempSync,writeFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {randomBytes} from 'node:crypto';
import assert from 'node:assert/strict';
import {createSnapshot,encryptSnapshot,snapshotTables,dailyBackup,decryptSnapshot} from '../server/operations.js';
import {restoreSnapshot} from './restore-postgres.mjs';
const testConnection=process.env.RESTORE_TEST_DATABASE_URL||readFileSync('.env.neon-test','utf8').trim(),url=new URL(testConnection);
url.hostname=url.hostname.replace('-pooler','');url.searchParams.set('sslmode','verify-full');
if(process.env.DATABASE_URL&&url.hostname===new URL(process.env.DATABASE_URL).hostname.replace('-pooler',''))throw Error('Verificação exige branch isolada do banco de produção.');
const suffix=randomBytes(5).toString('hex'),source='restore_source_'+suffix,target='restore_target_'+suffix,temp=mkdtempSync(join(tmpdir(),'conecta-restore-')),file=join(temp,'snapshot.backup.json'),key=randomBytes(32).toString('hex');
const client=new pg.Client({connectionString:url.href});await client.connect();
try{
 for(const schema of [source,target]){await client.query(`CREATE SCHEMA ${schema}`);await client.query(`SET search_path TO ${schema}`);for(const migration of readdirSync('server/migrations').filter(f=>f.endsWith('.sql')).sort())await client.query(readFileSync('server/migrations/'+migration,'utf8'));}
 await client.query(`SET search_path TO ${source}`);
 await client.query("INSERT INTO users(id,name,email,password,role) VALUES(27,'Restore student','student@restore.invalid','test-hash','student'),(28,'Restore recruiter','recruiter@restore.invalid','test-hash','recruiter')");
 await client.query("INSERT INTO profiles(user_id,data) VALUES(27,'{}')");
 await client.query("INSERT INTO companies(id,name) VALUES(13,'Restore company')");
 await client.query('INSERT INTO recruiters(user_id,company_id) VALUES(28,13)');
 await client.query("INSERT INTO jobs(id,company_id,data) VALUES(19,13,'{}')");
 await client.query('INSERT INTO applications(id,user_id,job_id) VALUES(21,27,19)');
 await client.query("INSERT INTO history(id,application_id,author_id,status) VALUES(23,21,28,'Em análise')");
 await client.query("INSERT INTO history_previous(history_id,previous_status) VALUES(23,'Enviada')");
 await client.query('INSERT INTO student_details(user_id) VALUES(27)');
 await client.query("INSERT INTO educations(id,user_id,course,institution,position) VALUES('edu-uuid',27,'Computing','Test institution',0)");
 await client.query("INSERT INTO skills(id,name,normalized_name) VALUES('skill-uuid','SQL','sql')");
 await client.query("INSERT INTO student_skills(user_id,skill_id) VALUES(27,'skill-uuid')");
 await client.query("INSERT INTO projects(id,user_id,title,position) VALUES('project-uuid',27,'Restore project',0)");
 await client.query("INSERT INTO project_skills(project_id,skill_id) VALUES('project-uuid','skill-uuid')");
 await client.query("INSERT INTO complementary_courses(id,user_id,title,position) VALUES('course-uuid',27,'Database course',0)");
 await client.query("INSERT INTO profile_languages(id,user_id,name,position) VALUES('language-uuid',27,'Português',0)");
 await client.query("INSERT INTO job_details(job_id,title,description,area,city,modality,deadline,activities,benefits,shift,salary,hours) VALUES(19,'Test job','Description','TI','Recife','Remoto','2027-01-01','Activities','Benefits','Manhã',1500,6)");
 await client.query("INSERT INTO job_courses(job_id,course) VALUES(19,'Computing')");
 await client.query("INSERT INTO job_skills(job_id,skill_id) VALUES(19,'skill-uuid')");
 await client.query("INSERT INTO recruiter_memberships(user_id,company_id,membership_role) VALUES(28,13,'owner')");
 const snapshot=await createSnapshot(client);writeFileSync(file,encryptSnapshot(snapshot,key),{mode:0o600});
 const sourceConnection=new URL(url);sourceConnection.searchParams.set('options',`-c search_path=${source}`);
 const backupPool=new pg.Pool({connectionString:sourceConnection.href,max:4});let deliveries=0;
 try{
  const backupOptions={pool:backupPool,env:{BACKUP_ENCRYPTION_KEY:key,OPERATIONS_EMAIL:'operations@restore.invalid',SMTP_USER:'operations@restore.invalid'},mailer:async(to,subject,text,{attachments})=>{assert.equal(to,'operations@restore.invalid');assert.deepEqual(decryptSnapshot(attachments[0].content,key).data.educations,snapshot.data.educations);deliveries++;}};
  const results=await Promise.all([dailyBackup(backupOptions),dailyBackup(backupOptions)]);assert.equal(results.filter(r=>r.sent).length,1);assert.equal(deliveries,1);assert.equal((await dailyBackup(backupOptions)).reason,'sent');
 }finally{await backupPool.end();}
 const destination=new URL(url);destination.searchParams.set('options',`-c search_path=${target}`);
 const result=await restoreSnapshot(file,destination.href,{key});
 await client.query(`SET search_path TO ${target}`);
 for(const table of snapshotTables.filter(t=>t!=='schema_migrations'&&snapshot.data[t]))assert.deepEqual((await client.query(`SELECT * FROM ${table}`)).rows,snapshot.data[table]);
 assert.equal(Number((await client.query("INSERT INTO users(name,email,password,role) VALUES('After restore','next@restore.invalid','test-hash','student') RETURNING id")).rows[0].id),29);
 await assert.rejects(()=>restoreSnapshot(file,destination.href,{key}),/Destino não vazio/);
 console.log(JSON.stringify({verified:true,...result,normalizedTables:true,identitySequence:true,nonEmptyRefused:true,backupConcurrentDedup:true}));
}finally{
 await client.query('SET search_path TO public');for(const schema of [source,target])await client.query(`DROP SCHEMA IF EXISTS ${schema} CASCADE`);await client.end();rmSync(temp,{recursive:true,force:true});
}
