$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
$stateDirectory = Join-Path $taskRoot 'data\monitor'
New-Item -ItemType Directory -Path $stateDirectory -Force | Out-Null
$pidFile = Join-Path $stateDirectory 'watch.pid'
$monitorScript = Join-Path $PSScriptRoot 'monitor.mjs'
if (Test-Path -LiteralPath $pidFile) {
    $monitorId = [int](Get-Content -LiteralPath $pidFile -Raw)
    $existing = Get-CimInstance Win32_Process -Filter "ProcessId=$monitorId" -ErrorAction SilentlyContinue
    if ($existing -and $existing.CommandLine.Contains($monitorScript) -and $existing.CommandLine.Contains('--watch')) {
        Write-Output "Monitor já ativo: processo $monitorId"
        exit 0
    }
}
$nodeExecutable = (Get-Command node).Source
$monitorProcess = Start-Process -FilePath $nodeExecutable -ArgumentList @(('"' + $monitorScript + '"'), '--watch') -WorkingDirectory $taskRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $stateDirectory 'watch.log') -RedirectStandardError (Join-Path $stateDirectory 'watch-error.log')
Set-Content -LiteralPath $pidFile -Value $monitorProcess.Id -NoNewline
Write-Output "Monitor iniciado: processo $($monitorProcess.Id)"
