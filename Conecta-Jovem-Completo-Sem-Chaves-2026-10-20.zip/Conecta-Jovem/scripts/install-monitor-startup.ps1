$ErrorActionPreference = 'Stop'
$startScript = Join-Path $PSScriptRoot 'start-monitor.ps1'
if (-not (Test-Path -LiteralPath $startScript)) { throw 'Script do monitor não encontrado.' }
$runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$shellExecutable = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$startCommand = '"' + $shellExecutable + '" -NoProfile -WindowStyle Hidden -File "' + $startScript + '"'
New-Item -Path $runKey -Force | Out-Null
New-ItemProperty -Path $runKey -Name 'ConectaJovemMonitor' -Value $startCommand -PropertyType String -Force | Out-Null
Write-Output 'Monitor configurado para iniciar ao entrar nesta conta do Windows.'
& $startScript
