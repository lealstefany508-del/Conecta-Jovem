import {spawn} from 'node:child_process';
import {mkdirSync,writeFileSync} from 'node:fs';
const started=Date.now();let output='';
const code=await new Promise(resolve=>{const p=spawn(process.execPath,['--test','--test-reporter=tap','tests/browser.test.js','tests/compliance.test.js','tests/system.test.js'],{stdio:['ignore','pipe','pipe']});p.stdout.on('data',b=>{output+=b;});p.stderr.on('data',()=>{});p.on('exit',resolve);});
const cases=[...output.matchAll(/(ok|not ok) \d+ - ([^\n]+)\n\s*---\n\s*duration_ms: ([\d.]+)/g)].map(x=>({scenario:x[2],passed:x[1]==='ok',durationMs:Number(x[3])}));
const report={kind:'piloto automatizado com atores simulados',humanParticipants:0,created:new Date().toISOString(),durationMs:Date.now()-started,passed:code===0,scenarios:cases,scope:['Currículo estruturado e foto','Publicação revisada e candidatura','Recrutador com permissões e revogação','Histórico, correção e notificações','Autorização do responsável','Responsividade'],limitation:'Duração de cenários automatizados; não mede facilidade, satisfação nem comportamento de participantes humanos.'};
mkdirSync('docs/evidencias',{recursive:true});writeFileSync('docs/evidencias/piloto-automatizado.json',JSON.stringify(report,null,2));console.log(JSON.stringify({passed:report.passed,scenarios:cases.length,durationMs:report.durationMs,humanParticipants:0}));if(code)process.exitCode=code;
