import '../server/env.js';
import {probeHealth,operationalEmail,dailyBackup} from '../server/operations.js';
import {sendMessage} from '../server/mail.js';
import {mkdirSync,readFileSync,writeFileSync,renameSync,existsSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import {setTimeout as pause} from 'node:timers/promises';
import {pathToFileURL} from 'node:url';
const stateFile=resolve(process.env.MONITOR_STATE_PATH||'data/monitor/state.json');
const readState=()=>existsSync(stateFile)?JSON.parse(readFileSync(stateFile,'utf8')):{status:'ok',failures:0};
function saveState(state){mkdirSync(dirname(stateFile),{recursive:true});writeFileSync(stateFile+'.tmp',JSON.stringify(state),{mode:0o600});renameSync(stateFile+'.tmp',stateFile);}
export async function monitorCycle({backup=false,env=process.env,fetcher=fetch,mailer=sendMessage,loadState=readState,storeState=saveState,pool}={}){
 const recipient=operationalEmail(env),health=await probeHealth({fetcher,env}),previous=loadState();
 const failures=health.healthy?0:Number(previous.failures||0)+1,oldStatus=previous.status||'ok';
 const status=health.healthy?'ok':failures>=2?'unavailable':oldStatus;
 if(status!==oldStatus)await mailer(recipient,`[Conecta monitor] ${status==='ok'?'Serviço recuperado':'Falha confirmada'}`,status==='ok'?'Hospedagem e acesso ao banco voltaram a responder.':`Duas verificações consecutivas da saúde pública falharam. HTTP: ${health.httpStatus??'sem resposta'}. Verifique hospedagem e banco.`);
 const state={status,failures,updated:new Date().toISOString()};storeState(state);
 const result={...state,...health,notified:status!==oldStatus};
 if(backup)try{result.backup=await dailyBackup({pool,env,mailer});}catch{result.backup={failed:true};}
 return result;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
 const watch=process.argv.includes('--watch'),backup=process.argv.includes('--backup'),interval=Math.max(30,Number(process.env.MONITOR_INTERVAL_SECONDS)||60)*1000;
 let stopped=false;for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{stopped=true;});
 try{do{try{const result=await monitorCycle({backup});console.log(JSON.stringify(result));if(!watch&&(!result.healthy||result.backup?.failed))process.exitCode=1;}catch{console.error(JSON.stringify({checkedAt:new Date().toISOString(),monitorError:true}));if(!watch)process.exitCode=1;}
 if(watch&&!stopped)await pause(interval);else break;}while(!stopped);}finally{if(backup){const {close}=await import('../server/db.js');await close();}}
}
