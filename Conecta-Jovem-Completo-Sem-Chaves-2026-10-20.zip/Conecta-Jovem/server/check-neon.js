import './env.js';
import pg from 'pg';
if(!process.env.DATABASE_URL)throw new Error('Configure DATABASE_URL no .env.');
const url=new URL(process.env.DATABASE_URL);
url.searchParams.set('sslmode','verify-full');
const client=new pg.Client({connectionString:url.href,enableChannelBinding:true,connectionTimeoutMillis:15000});
try{
 await client.connect();
 const result=await client.query("SELECT current_database() AS database, to_regclass('public.users') IS NOT NULL AS application_schema_present");
 console.log(JSON.stringify({connection:'OK',...result.rows[0],tls:client.connection.stream.encrypted===true,protocol:client.connection.stream.getProtocol?.()},null,2));
}catch(e){console.error('Não foi possível validar o Neon:',e.code||e.name);process.exitCode=1;}finally{await client.end();}
