import './env.js';
import pg from 'pg';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
const url=new URL(process.env.MIGRATION_DATABASE_URL||process.env.DATABASE_URL_UNPOOLED||process.env.DATABASE_URL);
url.hostname=url.hostname.replace('-pooler','');url.searchParams.set('sslmode','verify-full');
const client=new pg.Client({connectionString:url.href,enableChannelBinding:true,connectionTimeoutMillis:15000});
const tables=['users','profiles','companies','recruiters','jobs','applications','history','notifications','favorites','reports','audit','external_jobs','integrations','external_favorites'];
await client.connect();
try{
 await client.query('BEGIN');
 await client.query('SELECT pg_advisory_xact_lock(20261001)');
 for(const file of readdirSync(new URL('./migrations/',import.meta.url)).filter(f=>f.endsWith('.sql')).sort())await client.query(readFileSync(new URL('./migrations/'+file,import.meta.url),'utf8'));
 if(process.argv.includes('--import-sqlite')){
  if(Number((await client.query('SELECT count(*) FROM users')).rows[0].count)>0)throw new Error('Banco de destino já possui contas. Importação interrompida para preservar dados.');
  const source=new DatabaseSync(process.env.SQLITE_IMPORT_PATH||'data/conecta.sqlite',{readOnly:true});
  try{for(const table of tables){const rows=source.prepare(`SELECT * FROM ${table}`).all();for(const row of rows){const columns=Object.keys(row);await client.query(`INSERT INTO ${table}(${columns.join(',')}) VALUES(${columns.map((_,i)=>'$'+(i+1)).join(',')})`,Object.values(row));}console.log(table+': '+rows.length);}}
  finally{source.close();}
  for(const table of ['users','companies','jobs','applications','history','notifications','reports','audit'])await client.query(`SELECT setval(pg_get_serial_sequence('${table}','id'),COALESCE((SELECT max(id) FROM ${table}),1),(SELECT count(*)>0 FROM ${table}))`);
 }
 await client.query('COMMIT');
 process.env.DATABASE_URL=url.href;delete process.env.DB_PATH;
 const {migrateNormalized}=await import('./normalize.js');await migrateNormalized();
 const {close}=await import('./store.js');await close();
 console.log('Migração PostgreSQL e normalização concluídas.');
}catch(e){await client.query('ROLLBACK');console.error(e.message);process.exitCode=1;}finally{await client.end();}
