import {createCipheriv,createDecipheriv,randomBytes} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
import {sendMessage} from './mail.js';

// Parents precede children, allowing restoration with foreign keys enabled.
export const snapshotTables=['users','profiles','companies','recruiters','jobs','applications','history','notifications','favorites','sessions','resets','reports','audit','external_jobs','integrations','external_favorites','company_verifications','alert_subscriptions','alert_deliveries','app_events','privacy_requests','student_details','educations','skills','student_skills','job_details','job_courses','job_skills','projects','project_skills','complementary_courses','profile_languages','recruiter_memberships','history_previous','schema_migrations'];
const quote=name=>'"'+name.replaceAll('"','""')+'"';
function keyBuffer(key){if(!/^[a-f0-9]{64}$/i.test(key||''))throw new Error('BACKUP_ENCRYPTION_KEY deve conter 64 caracteres hexadecimais.');return Buffer.from(key,'hex');}
export function validateSnapshot(snapshot){
 if(![1,2].includes(snapshot?.version)||!snapshot.data||typeof snapshot.data!=='object'||Array.isArray(snapshot.data))throw new Error('Snapshot inválido.');
 const tables=Object.keys(snapshot.data);if(!tables.length||tables.some(t=>!snapshotTables.includes(t)||!Array.isArray(snapshot.data[t])))throw new Error('Tabelas inválidas no snapshot.');
 for(const table of tables)for(const row of snapshot.data[table])if(!row||typeof row!=='object'||Array.isArray(row)||!Object.keys(row).length||Object.keys(row).some(c=>! /^[a-z_][a-z0-9_]*$/.test(c)))throw new Error('Linha inválida no snapshot.');
 return snapshot;
}
export function encryptSnapshot(snapshot,key=process.env.BACKUP_ENCRYPTION_KEY){
 validateSnapshot(snapshot);const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',keyBuffer(key),iv);cipher.setAAD(Buffer.from('Conecta Jovem backup v2'));
 const ciphertext=Buffer.concat([cipher.update(gzipSync(Buffer.from(JSON.stringify(snapshot)))),cipher.final()]);
 return Buffer.from(JSON.stringify({format:'conecta-backup',version:2,cipher:'aes-256-gcm',iv:iv.toString('base64'),tag:cipher.getAuthTag().toString('base64'),content:ciphertext.toString('base64')}));
}
export function decryptSnapshot(bytes,key=process.env.BACKUP_ENCRYPTION_KEY){
 const envelope=JSON.parse(Buffer.from(bytes).toString('utf8'));if(envelope.format!=='conecta-backup')return validateSnapshot(envelope);
 if(envelope.version!==2||envelope.cipher!=='aes-256-gcm')throw new Error('Envelope de backup inválido.');
 const decipher=createDecipheriv('aes-256-gcm',keyBuffer(key),Buffer.from(envelope.iv,'base64'));decipher.setAAD(Buffer.from('Conecta Jovem backup v2'));decipher.setAuthTag(Buffer.from(envelope.tag,'base64'));
 const compressed=Buffer.concat([decipher.update(Buffer.from(envelope.content,'base64')),decipher.final()]);return validateSnapshot(JSON.parse(gunzipSync(compressed,{maxOutputLength:256*1024*1024}).toString('utf8')));
}
export async function createSnapshot(client){
 await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');
 try{const present=new Set((await client.query("SELECT tablename FROM pg_tables WHERE schemaname=current_schema()")).rows.map(r=>r.tablename));const data={};for(const table of snapshotTables)if(present.has(table))data[table]=(await client.query(`SELECT * FROM ${quote(table)}`)).rows;
 const snapshot=validateSnapshot({version:2,created:new Date().toISOString(),data});await client.query('COMMIT');return snapshot;}catch(error){await client.query('ROLLBACK');throw error;}
}
export function operationalEmail(env=process.env){
 const email=env.OPERATIONS_EMAIL;if(!email||email!==env.SMTP_USER||! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw new Error('OPERATIONS_EMAIL deve ser a própria conta SMTP do projeto.');return email;
}
export async function dailyBackup({pool,mailer=sendMessage,now=new Date(),env=process.env}={}){
 const recipient=operationalEmail(env);keyBuffer(env.BACKUP_ENCRYPTION_KEY);if(!pool)pool=(await import('./db.js')).pool;if(!pool)throw new Error('Backup remoto requer PostgreSQL.');
 const client=await pool.connect(),day=now.toISOString().slice(0,10);let active=false;
 try{
  await client.query('BEGIN');active=true;
  const locked=Boolean((await client.query('SELECT pg_try_advisory_xact_lock(824715203) locked')).rows[0]?.locked);if(!locked){await client.query('ROLLBACK');active=false;return {skipped:true,reason:'running'};}
  if((await client.query('SELECT status FROM operation_backup_runs WHERE day=$1',[day])).rows[0]?.status==='sent'){await client.query('COMMIT');active=false;return {skipped:true,reason:'sent'};}
  await client.query("INSERT INTO operation_backup_runs(day,status,created) VALUES($1,'running',$2) ON CONFLICT(day) DO UPDATE SET status='running',error=NULL",[day,now.toISOString()]);
  try{
   const reader=await pool.connect();let snapshot;try{snapshot=await createSnapshot(reader);}finally{reader.release();}
   const content=encryptSnapshot(snapshot,env.BACKUP_ENCRYPTION_KEY);if(content.length>18*1024*1024)throw new Error('Backup excede o limite seguro do anexo de e-mail.');
   decryptSnapshot(content,env.BACKUP_ENCRYPTION_KEY);
   await mailer(recipient,`[Conecta backup] ${day}`,`Snapshot privado criptografado de ${snapshot.created}. Guarde a chave separadamente. Retenção operacional: sete dias; remova cópias antigas também da lixeira.`,{attachments:[{filename:`conecta-${day}.backup.json`,content,contentType:'application/json'}]});
   await client.query("UPDATE operation_backup_runs SET status='sent',sent_at=$2,bytes=$3,error=NULL WHERE day=$1",[day,new Date().toISOString(),content.length]);await client.query('COMMIT');active=false;return {sent:true,day,bytes:content.length,tables:Object.keys(snapshot.data).length};
  }catch(error){await client.query("UPDATE operation_backup_runs SET status='failed',error=$2 WHERE day=$1",[day,'Falha no snapshot, criptografia ou confirmação de envio.']);await client.query('COMMIT');active=false;throw error;}
 }finally{try{if(active)await client.query('ROLLBACK');}finally{client.release();}}
}
export async function probeHealth({fetcher=fetch,env=process.env}={}){
 const url=new URL('/api/health',env.APP_PUBLIC_URL);if(url.protocol!=='https:')throw new Error('Monitor requer APP_PUBLIC_URL com HTTPS.');
 try{const response=await fetcher(url,{redirect:'error',signal:AbortSignal.timeout(15000)});const body=await response.json();return {healthy:response.ok&&body.status==='ok',httpStatus:response.status};}catch{return {healthy:false,httpStatus:null};}
}
// A confirmed transition is recorded only after its notification succeeds.
export async function healthMonitor({pool,fetcher=fetch,mailer=sendMessage,env=process.env}={}){
 const recipient=operationalEmail(env),health=await probeHealth({fetcher,env});if(!pool)pool=(await import('./db.js')).pool;if(!pool)throw new Error('Monitor persistente requer PostgreSQL.');
 const client=await pool.connect();let active=false;
 try{
  await client.query('BEGIN');active=true;
  const locked=Boolean((await client.query('SELECT pg_try_advisory_xact_lock(824715204) locked')).rows[0]?.locked);if(!locked){await client.query('ROLLBACK');active=false;return {...health,skipped:true};}
  const previous=(await client.query("SELECT status,failures FROM operations_monitor_state WHERE key='public-health'")).rows[0];
  const failures=health.healthy?0:Number(previous?.failures||0)+1;
  const oldStatus=previous?.status||'ok',status=health.healthy?'ok':failures>=2?'unavailable':oldStatus;
  if(status!==oldStatus)await mailer(recipient,`[Conecta monitor] ${status==='ok'?'Serviço recuperado':'Falha confirmada'}`,status==='ok'?'A verificação pública voltou a responder e confirmou acesso ao banco.':`Duas verificações consecutivas falharam. HTTP: ${health.httpStatus??'sem resposta'}. Verifique a hospedagem e o banco no painel operacional.`);
  await client.query("INSERT INTO operations_monitor_state(key,status,failures,updated) VALUES('public-health',$1,$2,$3) ON CONFLICT(key) DO UPDATE SET status=excluded.status,failures=excluded.failures,updated=excluded.updated",[status,failures,new Date().toISOString()]);
  await client.query('COMMIT');active=false;
  return {...health,status,failures,notified:status!==oldStatus};
 }finally{try{if(active)await client.query('ROLLBACK');}finally{client.release();}}
}
