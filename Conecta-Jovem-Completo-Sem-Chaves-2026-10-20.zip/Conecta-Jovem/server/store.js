import './env.js';
import pg from 'pg';
import {AsyncLocalStorage} from 'node:async_hooks';
import {attachDatabasePool} from '@vercel/functions';
export const postgres=Boolean(process.env.DATABASE_URL&&!process.env.DB_PATH);
const context=new AsyncLocalStorage();
export const sqlite=postgres?null:(await import('./sqlite.js')).db;
const url=postgres?new URL(process.env.DATABASE_URL):null;
if(url)url.searchParams.set('sslmode','verify-full');
export const pool=postgres?new pg.Pool({connectionString:url.href,enableChannelBinding:true,max:5,idleTimeoutMillis:5000,connectionTimeoutMillis:15000}):null;
if(pool&&process.env.VERCEL)attachDatabasePool(pool);
const identityTables=new Set(['users','companies','jobs','applications','history','notifications','reports','audit']);
function translate(sql){let n=0;return sql.replace(/\?/g,()=>`$${++n}`);}
export async function all(sql,...args){return postgres?(await (context.getStore()||pool).query(translate(sql),args)).rows:sqlite.prepare(sql).all(...args);}
export async function one(sql,...args){return (await all(sql,...args))[0];}
export async function run(sql,...args){
 if(!postgres)return sqlite.prepare(sql).run(...args);
 const table=/^INSERT\s+INTO\s+(\w+)/i.exec(sql)?.[1];
 const returning=identityTables.has(table)&&! /\bRETURNING\b/i.test(sql);
 const result=await (context.getStore()||pool).query(translate(sql)+(returning?' RETURNING id':''),args);
 return {changes:result.rowCount,lastInsertRowid:result.rows[0]?.id};
}
export async function transaction(fn){
 if(context.getStore())return fn();
 if(!postgres){sqlite.exec('BEGIN');try{const value=await context.run({sqlite:true},fn);sqlite.exec('COMMIT');return value;}catch(e){sqlite.exec('ROLLBACK');throw e;}}
 const client=await pool.connect();
 try{await client.query('BEGIN');const value=await context.run(client,fn);await client.query('COMMIT');return value;}catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
}
export async function close(){if(pool)await pool.end();else sqlite.close();}
