import './env.js';
import express from 'express';
import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { run, one, all, transaction, hash, emptyProfile, postgres } from './db.js';
import {waitUntil} from '@vercel/functions';
import { compatibility, transitions } from './rules.js';
import { configured, integrationStatus, externalJobs, syncAdzuna } from './adzuna.js';
import { sendRecovery, mailConfigured } from './mail.js';
import {mountProduct,sendAlerts,recordEvent} from './product.js';
import {migrateNormalized,readProfile,saveProfile,readJobs,saveJob} from './normalize.js';
import {validateAge,setAgePolicy,confirmGuardian,requestGuardian,eligible} from './age-policy.js';
import {validateProfile,validationError} from './validation.js';
import {dailyBackup} from './operations.js';
await migrateNormalized();
const app = express();
if(process.env.VERCEL)app.set('trust proxy',1);
app.disable('x-powered-by');
app.use(express.json({
  limit: '512kb'
}));
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'X-Frame-Options': 'DENY'
  });
  if (req.path.startsWith('/api')) res.set('Cache-Control', 'no-store');
  if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method) && req.headers.origin && req.headers.origin !== `${req.protocol}://${req.get('host')}`) return res.status(403).json({
    error: 'Origem não permitida.'
  });
  next();
});
const fail = (message, status = 400) => {
  const e = new Error(message);
  e.status = status;
  throw e;
};
const rate = new Map();
app.use('/api/auth', async (req, res, next) => {
  const key = req.ip;
  const now = Date.now();
  if(postgres){const r=await one('INSERT INTO auth_rate(key,started,count) VALUES(?,?,1) ON CONFLICT(key) DO UPDATE SET started=CASE WHEN auth_rate.started<? THEN excluded.started ELSE auth_rate.started END,count=CASE WHEN auth_rate.started<? THEN 1 ELSE auth_rate.count+1 END RETURNING count',key,now,now-600000,now-600000);if(r.count>60)return res.status(429).json({error:'Muitas tentativas. Aguarde alguns minutos.'});return next();}
  let entry = rate.get(key);
  if (!entry || entry.time < now - 600000) {
    entry = {
      time: now,
      count: 0
    };
    rate.set(key, entry);
  }
  if (++entry.count > 60) return res.status(429).json({
    error: 'Muitas tentativas. Aguarde alguns minutos.'
  });
  next();
});
const safe = u => ({
  id: u.id,
  name: u.name,
  email: u.email,
  role: u.role
});
async function session(res, u) {
  const token = randomBytes(32).toString('hex');
  await run('INSERT INTO sessions VALUES(?,?,?)', token, u.id, Date.now() + 86400000);
  res.cookie('cj_session', token, {
    httpOnly: true,
    sameSite: 'strict',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 86400000
  });
  return safe(u);
}
const validAccount = b => {
  if(!b.name?.trim())validationError({name:'Informe seu nome.'});
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(b.email||''))validationError({email:'Informe um e-mail válido.'});
  if(typeof b.password!=='string'||b.password.length<10||b.password.length>128)validationError({password:'A senha deve ter entre 10 e 128 caracteres.'});
};
app.post('/api/auth/register', async (req, res) => {
  const b = req.body;
  validAccount(b);
  if(b.role==='student')validateAge(b);
  if (!['student', 'company'].includes(b.role)) fail('Selecione um tipo de conta válido.');
  if (b.role === 'company' && (!b.companyName?.trim() || !b.identifier?.trim())) fail('Informe o nome e a identificação da empresa.');
  if(await one('SELECT id FROM users WHERE email=?',b.email.trim().toLowerCase())){const e=new Error('Este e-mail já está cadastrado.');e.status=409;e.fields={email:e.message};throw e;}
  const u = await transaction(async () => {
    const id = Number((await run('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)', b.name.trim(), b.email.trim().toLowerCase(), hash(b.password), b.role)).lastInsertRowid);
    if (b.role === 'student') await saveProfile(id,emptyProfile);else {
      const c = Number((await run('INSERT INTO companies(name,city,description,identifier) VALUES(?,?,?,?)', b.companyName.trim(), b.city || '', '', b.identifier)).lastInsertRowid);
      await run('INSERT INTO recruiters VALUES(?,?)', id, c);
      await run('INSERT INTO recruiter_memberships VALUES(?,?,?,?)',id,c,'owner','active');
    }
    return await one('SELECT * FROM users WHERE id=?', id);
  });
  if(b.role==='student'){try{await setAgePolicy(u.id,b);}catch(e){if(!b.guardianEmail)throw e;await recordEvent('guardian_delivery_failed','register');}}
  res.status(201).json({
    user: await session(res, u)
  });
});
app.post('/api/auth/login', async (req, res) => {
  const u = await one('SELECT * FROM users WHERE email=?', (req.body.email || '').trim().toLowerCase());
  const [salt, value] = (u?.password || hash('dummy-password')).split(':');
  const p = String(req.body.password || '');
  const valid = p.length <= 128 && timingSafeEqual(Buffer.from(value, 'hex'), scryptSync(p, salt, 64));
  if (!u || !valid || !u.active) fail('E-mail ou senha incorretos.', 401);
  res.json({
    user: await session(res, u)
  });
});
app.post('/api/auth/recover', async (req, res) => {
  if(process.env.NODE_ENV==='production'&&!mailConfigured())fail('A recuperação por e-mail ainda está sendo configurada. Tente novamente após a ativação do serviço.',503);
  const u = await one('SELECT * FROM users WHERE email=?', (req.body.email || '').trim().toLowerCase());
  if (u) {
    const token = randomBytes(32).toString('hex');
    await run('DELETE FROM resets WHERE user_id=?', u.id);
    await run('INSERT INTO resets VALUES(?,?,?)', token, u.id, Date.now() + 900000);
    if (mailConfigured()) {
      try {
        await sendRecovery(u.email, token);
      } catch {
        await run('DELETE FROM resets WHERE token=?', token);
        console.error('Falha na entrega de recuperação de acesso. Verifique a configuração do provedor.');
      }
    } else if (process.env.NODE_ENV !== 'production') {
      console.log('Recuperação local (entregue ao titular):', `http://localhost:${process.env.PORT || 3000}/?reset=${token}`);
    }
  }
  res.json({
    message: mailConfigured() ? 'Se a conta existir, você receberá instruções de recuperação no e-mail cadastrado.' : 'Se a conta existir, uma solicitação foi criada. Na instalação local, o responsável recebe o link no terminal. Envio por e-mail requer configurar um provedor.'
  });
});
app.post('/api/auth/reset', async (req, res) => {
  validAccount({
    name: 'Reset',
    email: 'reset@example.com',
    password: req.body.password
  });
  await transaction(async () => {
    const r=await one('DELETE FROM resets WHERE token=? AND expires>? RETURNING user_id',req.body.token||'',Date.now());
    if(!r)fail('Link inválido ou expirado.');
    await run('UPDATE users SET password=? WHERE id=?', hash(req.body.password), r.user_id);
    await run('DELETE FROM sessions WHERE user_id=?', r.user_id);
    await run('DELETE FROM resets WHERE user_id=?', r.user_id);
  });
  res.json({
    ok: true
  });
});
app.post('/api/auth/guardian-confirm',async(req,res)=>res.json(await confirmGuardian(req.body.token,req.body.consent)));
app.get('/api/health',async(req,res)=>{try{await one('SELECT 1 ok');res.json({status:'ok'});}catch{res.status(503).json({status:'unavailable'});}});
app.get('/api/cron/sync',async(req,res)=>{
 if(!process.env.CRON_SECRET||req.headers.authorization!==`Bearer ${process.env.CRON_SECRET}`)return res.status(401).json({error:'Acesso não autorizado.'});
 await run('DELETE FROM sessions WHERE expires<?',Date.now());await run('DELETE FROM resets WHERE expires<?',Date.now());
 if(postgres)await run('DELETE FROM auth_rate WHERE started<?',Date.now()-86400000);
 await run('DELETE FROM app_events WHERE created<?',Date.now()-7*86400000);
 const status=await integrationStatus();if(status.configured&&(!status.lastAttempt||Date.now()-status.lastAttempt>=3600000))await syncAdzuna();
 await sendAlerts();
 res.json({ok:true,count:(await integrationStatus()).count});
});
app.get('/api/cron/operations',async(req,res)=>{
 if(!process.env.CRON_SECRET||req.headers.authorization!==`Bearer ${process.env.CRON_SECRET}`)return res.status(401).json({error:'Acesso não autorizado.'});
 let backup;
 try{backup=await dailyBackup();await run('DELETE FROM operation_backup_runs WHERE day<?',new Date(Date.now()-30*86400000).toISOString().slice(0,10));}catch{await recordEvent('backup_failed','cron/operations');return res.status(503).json({error:'Falha no backup; confira o painel.'});}
 let retention={skipped:'disabled'};
 if(process.env.BACKUP_RETENTION_ENABLED==='1')try{const {retainGmailBackups}=await import('./backup-retention.js');retention=await retainGmailBackups();if(retention.skipped==='no-recent-verified-backup'){await recordEvent('backup_retention_waiting','cron/operations');return res.status(503).json({ok:false,backup,retention,error:'Não foi encontrado backup recente autenticado na caixa operacional.'});}}catch{await recordEvent('backup_retention_failed','cron/operations');return res.status(503).json({ok:false,backup,error:'Backup registrado; falha na limpeza dos anexos. Confira o painel.'});}
 res.json({ok:true,backup,retention});
});
const mountProtected=mountProduct(app,{role:(...args)=>role(...args),company:(...args)=>company(...args),profile:(...args)=>profile(...args)});
app.use('/api', async (req, res, next) => {
  const token = req.headers.cookie?.split(';').map(s => s.trim()).find(s => s.startsWith('cj_session='))?.slice(11);
  const s = token && (await one('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE token=? AND expires>? AND active=1', token, Date.now()));
  if (!s) return res.status(401).json({
    error: 'Entre na sua conta para continuar.'
  });
  req.user = s;
  req.token = token;
  next();
});
const role = (req, r) => {
  if (req.user.role !== r) fail('Você não tem permissão para esta ação.', 403);
};
mountProtected();
const company = async req => {
  role(req, 'company');
  const c=await one("SELECT c.*,COALESCE(v.status,'Pendente') verification,v.website,v.notes,m.membership_role \"membershipRole\",m.membership_status \"membershipStatus\" FROM companies c JOIN recruiters r ON r.company_id=c.id JOIN recruiter_memberships m ON m.user_id=r.user_id AND m.company_id=r.company_id LEFT JOIN company_verifications v ON v.company_id=c.id WHERE r.user_id=? AND m.membership_status='active'",req.user.id);
  if(!c)fail('Seu vínculo de recrutamento não está ativo.',403);return c;
};
const owner=async req=>{const c=await company(req);if(c.membershipRole!=='owner')fail('Apenas responsáveis da empresa podem gerenciar a equipe.',403);return c;};
const getJob = async id => {
  const j=(await readJobs('WHERE j.id=?',Number(id)))[0];
  if (!j) fail('Vaga não encontrada.', 404);
  return j;
};
const profile=readProfile;
app.post('/api/age-policy',async(req,res)=>{role(req,'student');res.json(await setAgePolicy(req.user.id,{...req.body,email:req.user.email}));});
app.post('/api/guardian/request',async(req,res)=>{role(req,'student');res.json(await requestGuardian(req.user.id));});
const notify = async (id, message) => {
  const p=await one('SELECT notifications FROM student_details WHERE user_id=?',id);
  if(p?.notifications!==0)await run('INSERT INTO notifications(user_id,message) VALUES(?,?)',id,message);
};
app.get('/api/me', async (req, res) => res.json({
  user: safe(req.user),
  profile: await profile(req.user.id),
  company: req.user.role === 'company' ? await company(req) : null
}));
app.get('/api/external/jobs', async (req, res) => {
 const status=await integrationStatus();
 if(process.env.VERCEL){
  if(status.configured&&(!status.lastSuccess||Date.now()-status.lastSuccess>=21600000)&&(!status.lastAttempt||Date.now()-status.lastAttempt>=3600000))waitUntil(syncAdzuna().catch(()=>recordEvent('source_sync_failed','external/jobs')));
  waitUntil(sendAlerts().catch(()=>recordEvent('alerts_failed','external/jobs')));
 }
 res.json({jobs:await externalJobs(),status});
});
app.get('/api/external/favorites', async (req, res) => {
  role(req, 'student');
  const ids = new Set((await all("SELECT source_id FROM external_favorites WHERE user_id=? AND source='Adzuna'", req.user.id)).map(f => f.source_id));
  res.json((await externalJobs()).filter(j => ids.has(j.id)));
});
app.post('/api/external/favorites/:id', async (req, res) => {
  role(req, 'student');
  const id = String(req.params.id);
  const has = await one("SELECT source_id FROM external_favorites WHERE user_id=? AND source='Adzuna' AND source_id=?", req.user.id, id);
  if (!has && !(await externalJobs()).some(j => j.id === id)) fail('Anúncio externo não está mais disponível.', 404);
  if (has) await run("DELETE FROM external_favorites WHERE user_id=? AND source='Adzuna' AND source_id=?", req.user.id, id);else await run("INSERT INTO external_favorites VALUES(?,'Adzuna',?)", req.user.id, id);
  res.json({
    saved: !has
  });
});
app.post('/api/admin/integrations/adzuna/sync', async (req, res) => {
  role(req, 'admin');
  try {
    res.json(await syncAdzuna());
  } catch (e) {
    res.status(503).json({
      error: e.message
    });
  }
});
app.post('/api/logout', async (req, res) => {
  await run('DELETE FROM sessions WHERE token=?', req.token);
  res.clearCookie('cj_session');
  res.json({
    ok: true
  });
});
app.put('/api/profile', async (req, res) => {
  role(req, 'student');
  const b = {
    ...emptyProfile,
    ...req.body
  };
  validateProfile(b);
  await saveProfile(req.user.id,b);
  res.json(await profile(req.user.id));
});
app.put('/api/profile/preferences',async(req,res)=>{role(req,'student');const b=req.body;if(b.visibility!==undefined&&!['Candidaturas','Público','Privado'].includes(b.visibility))validationError({visibility:'Visibilidade inválida.'});if(b.notifications!==undefined&&typeof b.notifications!=='boolean')validationError({notifications:'Preferência inválida.'});if(b.visibility!==undefined)await run('UPDATE student_details SET visibility=? WHERE user_id=?',b.visibility,req.user.id);if(b.notifications!==undefined)await run('UPDATE student_details SET notifications=? WHERE user_id=?',b.notifications?1:0,req.user.id);res.json(await profile(req.user.id));});
app.get('/api/jobs', async (req, res) => {
  const p = await profile(req.user.id);
  res.json((await readJobs("WHERE j.status='Aberta'")).filter(j => j.verification==='Aprovada'&&j.deadline >= new Date().toISOString().slice(0, 10)).map(j => ({
    ...j,
    compatibility: req.user.role === 'student' ? compatibility(p, j) : null
  })));
});
app.get('/api/favorites', async (req, res) => {
  role(req, 'student');
  res.json(await Promise.all((await all('SELECT job_id FROM favorites WHERE user_id=?', req.user.id)).map(async f => ({
    ...(await getJob(f.job_id)),
    compatibility: compatibility(await profile(req.user.id), await getJob(f.job_id))
  }))));
});
app.post('/api/favorites/:id', async (req, res) => {
  role(req, 'student');
  await getJob(req.params.id);
  const has = await one('SELECT * FROM favorites WHERE user_id=? AND job_id=?', req.user.id, Number(req.params.id));
  await run(has ? 'DELETE FROM favorites WHERE user_id=? AND job_id=?' : 'INSERT INTO favorites VALUES(?,?)', req.user.id, Number(req.params.id));
  res.json({
    saved: !has
  });
});
app.post('/api/jobs/:id/apply', async (req, res) => {
  role(req, 'student');
  const j = await getJob(req.params.id),
    p = await profile(req.user.id);
  if (j.verification!=='Aprovada'||j.status !== 'Aberta' || j.deadline < new Date().toISOString().slice(0, 10)) fail('Esta vaga não aceita novas candidaturas.', 409);
  if(!await eligible(req.user.id)){const e=new Error('Complete a política de idade e a autorização do responsável antes de se candidatar.');e.status=422;e.details={action:'age-policy'};throw e;}
  if (!p.course || !p.institution || !p.city || !p.availability || !p.modality) fail('Complete cidade, formação, instituição e disponibilidade no perfil.', 422);
  if (p.visibility === 'Privado') fail('Permita a visibilidade para candidaturas antes de enviar seu perfil.', 422);
  if (await one('SELECT id FROM applications WHERE user_id=? AND job_id=?', req.user.id, j.id)) fail('Sua candidatura já foi enviada.', 409);
  await transaction(async () => {
    const id = Number((await run('INSERT INTO applications(user_id,job_id) VALUES(?,?)', req.user.id, j.id)).lastInsertRowid);
    const h=await run('INSERT INTO history(application_id,author_id,status,reason) VALUES(?,?,?,?)', id, req.user.id, 'Enviada', 'Candidatura registrada pelo estudante');
    await run('INSERT INTO history_previous VALUES(?,?)',h.lastInsertRowid,null);
    await notify(req.user.id, `Sua candidatura para ${j.title} foi enviada!`);
    for (const r of await all('SELECT user_id FROM recruiters WHERE company_id=?', j.companyId)) await notify(r.user_id, `${req.user.name} se candidatou a ${j.title}.`);
  });
  res.status(201).json({
    ok: true
  });
});
async function applicationRows(req) {
  const isCompany = req.user.role === 'company';
  if(isCompany&&(await company(req)).verification!=='Aprovada')return [];
  const rows = isCompany ? await all('SELECT a.*,u.name,u.email FROM applications a JOIN users u ON u.id=a.user_id JOIN jobs j ON j.id=a.job_id WHERE j.company_id=? ORDER BY a.id DESC', (await company(req)).id) : await all('SELECT a.*,u.name,u.email FROM applications a JOIN users u ON u.id=a.user_id WHERE a.user_id=? ORDER BY a.id DESC', req.user.id);
  return await Promise.all(rows.map(async a => {
    const p = await profile(a.user_id);
    const {birthDate,guardianEmail,guardianStatus,...professionalProfile}=p;
    return {
      ...a,
      job: await getJob(a.job_id),
      profile: isCompany && p.visibility !== 'Privado' ? professionalProfile : null,
      email: isCompany && p.visibility === 'Privado' ? null : a.email,
      history: await all('SELECT h.status,h.reason,h.created,p.previous_status FROM history h LEFT JOIN history_previous p ON p.history_id=h.id WHERE h.application_id=? ORDER BY h.id', a.id)
    };
  }));
}
app.get('/api/applications', async (req, res) => {
  if (req.user.role === 'admin') fail('Use o painel administrativo.', 403);
  res.json(await applicationRows(req));
});
app.patch('/api/applications/:id', async (req, res) => {
  const a = await one('SELECT * FROM applications WHERE id=?', Number(req.params.id));
  if (!a) fail('Candidatura não encontrada.', 404);
  const j = await getJob(a.job_id),
    status = req.body.status;
  const cancel = req.user.role === 'student' && a.user_id === req.user.id && status === 'Cancelada pelo estudante' && transitions[a.status];
  if (!cancel) {
    if(req.user.role==='company'&&(await company(req)).verification!=='Aprovada')fail('Empresa sem aprovação para selecionar candidatos.',403);
    if (req.user.role !== 'company' || (await company(req)).id !== j.companyId) fail('Sem permissão.', 403);
    if (!transitions[a.status]?.includes(status)) fail('Esta transição de etapa não é permitida.');
  }
  await transaction(async () => {
    const updated=await run('UPDATE applications SET status=? WHERE id=? AND status=?', status, a.id,a.status);
    if(!updated.changes)fail('A candidatura foi atualizada por outra solicitação. Recarregue a página.',409);
    const h=await run('INSERT INTO history(application_id,author_id,status,reason) VALUES(?,?,?,?)', a.id, req.user.id, status, String(req.body.reason || 'Etapa atualizada').slice(0, 2000));
    await run('INSERT INTO history_previous VALUES(?,?)',h.lastInsertRowid,a.status);
    await notify(a.user_id, `${j.title}: sua candidatura está ${status.toLowerCase()}.`);
  });
  res.json({
    ok: true
  });
});
app.get('/api/notifications', async (req, res) => res.json(await all('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC', req.user.id)));
app.post('/api/notifications/read', async (req, res) => {
  await run('UPDATE notifications SET read=1 WHERE user_id=?', req.user.id);
  res.json({
    ok: true
  });
});
app.get('/api/company/jobs',async(req,res)=>res.json(await readJobs('WHERE j.company_id=?',(await company(req)).id)));
app.put('/api/company', async (req, res) => {
  const c = await company(req),
    b = req.body;
  if (!b.name?.trim() || !b.identifier?.trim()) fail('Nome e identificação são obrigatórios.');
  await run('UPDATE companies SET name=?,city=?,description=?,identifier=? WHERE id=?', b.name, b.city || '', b.description || '', b.identifier, c.id);
  if(c.identifier!==b.identifier||c.name!==b.name)await run("INSERT INTO company_verifications(company_id,status,updated) VALUES(?,'Pendente',?) ON CONFLICT(company_id) DO UPDATE SET status='Pendente',updated=excluded.updated",c.id,Date.now());
  res.json({
    ok: true
  });
});
app.get('/api/company/recruiters',async(req,res)=>res.json(await all('SELECT u.id,u.name,u.email,m.membership_role "membershipRole",m.membership_status "membershipStatus" FROM users u JOIN recruiters r ON r.user_id=u.id JOIN recruiter_memberships m ON m.user_id=r.user_id AND m.company_id=r.company_id WHERE r.company_id=?',(await company(req)).id)));
app.post('/api/company/recruiters', async (req, res) => {
  const c = await owner(req),
    b = req.body;
  validAccount(b);
  if (await one('SELECT id FROM users WHERE email=?', b.email.toLowerCase())) fail('Este e-mail já possui uma conta.', 409);
  await transaction(async () => {
    const id = Number((await run("INSERT INTO users(name,email,password,role) VALUES(?,?,?,'company')", b.name, b.email.toLowerCase(), hash(b.password))).lastInsertRowid);
    await run('INSERT INTO recruiters VALUES(?,?)', id, c.id);
    await run('INSERT INTO recruiter_memberships VALUES(?,?,?,?)',id,c.id,b.membershipRole==='owner'?'owner':'recruiter','active');
    await run('INSERT INTO audit(author_id,action,reason) VALUES(?,?,?)',req.user.id,'recruiter-add:'+id,'Vínculo criado pelo responsável empresarial.');
  });
  res.status(201).json({
    ok: true
  });
});
app.patch('/api/company/recruiters/:id',async(req,res)=>{
 const c=await owner(req),id=Number(req.params.id),b=req.body;
 if(!['owner','recruiter'].includes(b.membershipRole)||!['active','suspended','revoked'].includes(b.membershipStatus))fail('Papel ou situação inválidos.');
 await transaction(async()=>{
  await run('UPDATE companies SET name=name WHERE id=?',c.id);
  const member=await one('SELECT * FROM recruiter_memberships WHERE user_id=? AND company_id=?',id,c.id);if(!member)fail('Recrutador não encontrado.',404);
  if(member.membership_role==='owner'&&member.membership_status==='active'&&(b.membershipRole!=='owner'||b.membershipStatus!=='active')){const remaining=await one("SELECT count(*) count FROM recruiter_memberships m JOIN users u ON u.id=m.user_id WHERE m.company_id=? AND m.membership_role='owner' AND m.membership_status='active' AND u.active=1 AND m.user_id<>?",c.id,id);if(Number(remaining.count)<1)fail('Mantenha pelo menos um responsável ativo na empresa.',409);}
  await run('UPDATE recruiter_memberships SET membership_role=?,membership_status=? WHERE user_id=? AND company_id=?',b.membershipRole,b.membershipStatus,id,c.id);if(b.membershipStatus!=='active')await run('DELETE FROM sessions WHERE user_id=?',id);
  await run('INSERT INTO audit(author_id,action,reason) VALUES(?,?,?)',req.user.id,'recruiter-update:'+id,b.membershipRole+' / '+b.membershipStatus);
 });res.json({ok:true});
});
function jobData(b) {
  if(b.kind&&!['Estágio','Aprendiz'].includes(b.kind))fail('Tipo de contratação inválido.');
  const fields={};for(const k of ['title','description','area','city','modality','deadline','activities','benefits','shift'])if(typeof b[k]!=='string'||!b[k].trim()||b[k].length>5000)fields[k]='Campo obrigatório, com até 5.000 caracteres.';
  if(Object.keys(fields).length)validationError(fields);
  if (!['Remoto', 'Híbrido', 'Presencial'].includes(b.modality) || !['Manhã', 'Tarde', 'Noite'].includes(b.shift)) fail('Modalidade ou turno inválidos.');
  if(!/^\d{4}-\d{2}-\d{2}$/.test(b.deadline)||!Number.isFinite(Date.parse(b.deadline))||new Date(b.deadline).toISOString().slice(0,10)!==b.deadline||b.deadline<new Date().toISOString().slice(0,10))validationError({deadline:'Informe um prazo válido a partir de hoje.'});
  if (!Number.isFinite(Number(b.salary)) || Number(b.salary) < 0 || !Number.isInteger(Number(b.hours)) || Number(b.hours) < 1 || Number(b.hours) > 8) fail('Bolsa ou carga horária inválida.');
  if (!Array.isArray(b.skills) || !Array.isArray(b.courses) || !b.courses.length || [...b.skills, ...b.courses].some(v => typeof v !== 'string' || v.length > 100)) fail('Informe formações e habilidades válidas.');
  return {
    ...b,
    kind:b.kind||'Estágio',
    salary: Number(b.salary),
    hours: Number(b.hours)
  };
}
app.post('/api/company/jobs', async (req, res) => {
  const c = await company(req),
    b = jobData(req.body);
  if(c.verification!=='Aprovada')fail('Envie sua empresa para aprovação antes de publicar vagas.',403);
  const id=await transaction(async()=>{const id=Number((await run('INSERT INTO jobs(company_id,data) VALUES(?,?)',c.id,'{}')).lastInsertRowid);await saveJob(id,b);return id;});
  res.status(201).json({
    id
  });
});
app.put('/api/company/jobs/:id', async (req, res) => {
  const c = await company(req),
    j = await getJob(req.params.id);
  if (c.id !== j.companyId) fail('Sem permissão.', 403);
  await saveJob(j.id,jobData(req.body));
  res.json({
    ok: true
  });
});
app.patch('/api/company/jobs/:id', async (req, res) => {
  const c = await company(req),
    j = await getJob(req.params.id);
  if(req.body.status==='Aberta'&&c.verification!=='Aprovada')fail('Sua empresa precisa de aprovação para abrir vagas.',403);
  if (c.id !== j.companyId) fail('Sem permissão.', 403);
  if (j.status === 'Suspensa') fail('Uma vaga suspensa só pode ser liberada pela administração.', 403);
  if (!['Aberta', 'Pausada', 'Encerrada'].includes(req.body.status)) fail('Situação inválida.');
  if (req.body.status === 'Aberta') jobData(j);
  await run('UPDATE jobs SET status=? WHERE id=?', req.body.status, j.id);
  res.json({
    ok: true
  });
});
app.post('/api/reports', async (req, res) => {
  await getJob(req.body.jobId);
  if (!req.body.reason?.trim()) fail('Descreva o motivo da denúncia.');
  await run('INSERT INTO reports(user_id,job_id,reason) VALUES(?,?,?)', req.user.id, req.body.jobId, String(req.body.reason).slice(0, 2000));
  res.status(201).json({
    ok: true
  });
});
app.get('/api/admin', async (req, res) => {
  role(req, 'admin');
  res.json({
    users: await all('SELECT id,name,email,role,active FROM users'),
    companies:await all("SELECT c.*,COALESCE(v.status,'Pendente') verification,v.website,v.notes FROM companies c LEFT JOIN company_verifications v ON v.company_id=c.id"),
    jobs: await Promise.all((await all('SELECT id FROM jobs')).map(async j => await getJob(j.id))),
    reports: await all('SELECT * FROM reports'),
    applications:await all('SELECT a.id,a.status,a.user_id,u.name,j.title FROM applications a JOIN users u ON u.id=a.user_id JOIN job_details j ON j.job_id=a.job_id ORDER BY a.id DESC'),
    audit: await all('SELECT * FROM audit ORDER BY id DESC')
  });
});
app.post('/api/admin/action', async (req, res) => {
  role(req, 'admin');
  const b = req.body;
  if (typeof b.reason!=='string'||b.reason.trim().length<10||b.reason.trim().length>2000) fail('Informe um motivo entre 10 e 2000 caracteres.');
  b.reason=b.reason.trim();
  await transaction(async () => {
    if (b.type === 'user') {
      if(typeof b.active!=='boolean')fail('Informe uma situação válida para a conta.');
      if (Number(b.id) === req.user.id) fail('Não é possível suspender sua própria conta.');
      if (!(await one('SELECT id FROM users WHERE id=?', b.id))) fail('Conta não encontrada.');
      await run('UPDATE users SET active=? WHERE id=?', b.active ? 1 : 0, b.id);
    } else if(b.type==='company'){
      if(!['Aprovada','Rejeitada','Suspensa'].includes(b.status)||!(await one('SELECT id FROM companies WHERE id=?',b.id)))fail('Empresa ou decisão inválida.');
      await run('INSERT INTO company_verifications(company_id,status,reviewed_by,updated) VALUES(?,?,?,?) ON CONFLICT(company_id) DO UPDATE SET status=excluded.status,reviewed_by=excluded.reviewed_by,updated=excluded.updated',b.id,b.status,req.user.id,Date.now());
    } else if(b.type==='application'){
      const states=['Enviada','Em análise','Pré-selecionada','Entrevista','Aprovada','Não selecionada','Cancelada pelo estudante'];if(!states.includes(b.status))fail('Etapa inválida.');const a=await one('SELECT * FROM applications WHERE id=?',b.id);if(!a)fail('Candidatura não encontrada.',404);if(!['Aprovada','Não selecionada','Cancelada pelo estudante'].includes(a.status))fail('A correção excepcional é destinada a resultados finais.');if(a.status===b.status)fail('Selecione uma etapa diferente.');const updated=await run('UPDATE applications SET status=? WHERE id=? AND status=?',b.status,b.id,a.status);if(!updated.changes)fail('Etapa alterada em outra solicitação.',409);const h=await run('INSERT INTO history(application_id,author_id,status,reason) VALUES(?,?,?,?)',a.id,req.user.id,b.status,'Correção administrativa: '+b.reason);await run('INSERT INTO history_previous VALUES(?,?)',h.lastInsertRowid,a.status);await notify(a.user_id,'Correção administrativa da candidatura: '+b.status+'. Motivo: '+b.reason);
    } else if(b.type==='privacy'){
      const request=await one('SELECT user_id FROM privacy_requests WHERE id=?',b.id);if(!request)fail('Solicitação não encontrada.');
      await run("UPDATE privacy_requests SET status='Respondida' WHERE id=?",b.id);
      await notify(request.user_id,'Resposta à solicitação de dados: '+String(b.reason).slice(0,2000));
    } else if (b.type === 'job') {
      if(b.status!==undefined&&!['Aberta','Suspensa'].includes(b.status))fail('Informe uma situação válida para a vaga.');
      await getJob(b.id);
      await run("UPDATE jobs SET status=? WHERE id=?",b.status==='Aberta'?'Aberta':'Suspensa', b.id);
    } else if (b.type === 'report') {
      if (!(await one('SELECT id FROM reports WHERE id=?', b.id))) fail('Denúncia não encontrada.');
      await run("UPDATE reports SET status='Analisada' WHERE id=?", b.id);
    } else fail('Ação inválida.');
    await run('INSERT INTO audit(author_id,action,reason) VALUES(?,?,?)', req.user.id, `${b.type}:${b.id}`, b.reason);
  });
  res.json({
    ok: true
  });
});
app.delete('/api/account', async (req, res) => {
  if (req.body.confirmation !== 'EXCLUIR') fail('Digite EXCLUIR para confirmar.');
  if (req.user.role !== 'student') fail('Exclusão empresarial requer transferência de responsabilidade.', 409);
  await run('DELETE FROM users WHERE id=?', req.user.id);
  res.clearCookie('cj_session');
  res.json({
    ok: true
  });
});
app.use('/api',(req,res)=>res.status(404).json({error:'Recurso não encontrado.'}));
if (!process.env.VERCEL&&existsSync('dist/index.html')) {
  app.use(express.static('dist'));
  app.get('/{*path}', (req, res) => res.sendFile(path.resolve('dist/index.html')));
} else if(!process.env.VERCEL) {
  const {
    createServer
  } = await import('vite');
  const vite = await createServer({
    server: {
      middlewareMode: true
    },
    appType: 'spa'
  });
  app.use(vite.middlewares);
}
app.use((err, req, res, next) => {
  if(err.code==='23505'){err.status=409;err.message='Este registro já existe.';}
  if (!err.status){console.error('Falha de API:',err.code||'internal');const event=recordEvent('api_failure',req.path);if(process.env.VERCEL)waitUntil(event);}
  res.status(err.status || 500).json({
    error: err.status ? err.message : 'Não foi possível concluir a operação. Tente novamente.',
    fields:err.status?err.fields:undefined,details:err.status?err.details:undefined
  });
});
export default app;
if (!process.env.VERCEL) {
  app.listen(Number(process.env.PORT || 3000), '127.0.0.1', () => console.log('Conecta Jovem em http://localhost:' + (process.env.PORT || 3000)));
  if (configured()) {
    const refresh = async () => {
      const s = await integrationStatus();
      if (!s.lastSuccess || Date.now() - s.lastSuccess >= 21600000) await syncAdzuna();
      await sendAlerts();
    };
    refresh().catch(e => console.error(e.message));
    const timer = setInterval(() => refresh().catch(e => console.error(e.message)), 21600000);
    timer.unref();
  }
}
