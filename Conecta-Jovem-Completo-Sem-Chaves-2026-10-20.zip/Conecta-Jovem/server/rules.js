export const transitions = {'Enviada':['Em análise','Não selecionada'], 'Em análise':['Pré-selecionada','Não selecionada'], 'Pré-selecionada':['Entrevista','Não selecionada'], 'Entrevista':['Aprovada','Não selecionada']};
export function compatibility(profile, job) {
  if (!profile.course || !profile.city || !profile.availability || !profile.modality) return {score:null,criteria:[]};
  const same = (a,b) => a.toLocaleLowerCase('pt-BR')===b.toLocaleLowerCase('pt-BR');
  const criteria=[];
  if(job.courses.length) criteria.push({label:'Curso / área',weight:30,points:job.courses.some(c=>(profile.educations?.length?profile.educations.map(e=>e.course):[profile.course]).some(pc=>same(c,pc)))?30:0});
  if(job.skills.length) criteria.push({label:'Habilidades',weight:30,points:30*job.skills.filter(s=>profile.skills.some(p=>same(s,p))).length/job.skills.length});
  if(job.shift) criteria.push({label:'Disponibilidade',weight:20,points:profile.availability==='Qualquer turno'||same(profile.availability,job.shift)?20:0});
  criteria.push({label:'Modalidade e localização',weight:20,points:(profile.modality==='Todas'||same(profile.modality,job.modality))&&(job.modality==='Remoto'||same(profile.city,job.city))?20:0});
  return {score:Math.round(100*criteria.reduce((s,c)=>s+c.points,0)/criteria.reduce((s,c)=>s+c.weight,0)),criteria};
}
