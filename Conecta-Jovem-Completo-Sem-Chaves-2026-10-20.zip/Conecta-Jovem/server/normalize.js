import {randomUUID} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {all,one,run,transaction,sqlite,postgres} from './store.js';
import {emptyProfile} from './db.js';
const normalize=s=>String(s).normalize('NFD').replace(/\p{Diacritic}/gu,'').trim().toLowerCase();
export async function skillId(name){const key=normalize(name);await run('INSERT INTO skills(id,name,normalized_name) VALUES(?,?,?) ON CONFLICT(normalized_name) DO NOTHING',randomUUID(),name.trim(),key);return (await one('SELECT id FROM skills WHERE normalized_name=?',key)).id;}
function entries(p){return {...p,educations:p.educations||((p.course||p.institution)?[{course:p.course||'',institution:p.institution||'',semester:p.semester||'',period:''}]:[]),projectEntries:p.projectEntries?.length?p.projectEntries:(p.projects?[{title:'Projeto importado',description:p.projects,skills:[],link:''}]:[]),courseEntries:p.courseEntries?.length?p.courseEntries:(p.courses?[{title:p.courses,institution:'',period:''}]:[]),languageEntries:p.languageEntries?.length?p.languageEntries:(p.languages?[{name:p.languages,level:''}]:[])};}
export async function saveProfile(id,input){const p=entries({...emptyProfile,...input});await transaction(async()=>{
 const fields=['city','interest','objective','availability','modality','experience','phone','visibility'];
 await run(`INSERT INTO student_details(user_id,${fields.join(',')},notifications,photo) VALUES(${Array(11).fill('?').join(',')}) ON CONFLICT(user_id) DO UPDATE SET ${fields.map(k=>k+'=excluded.'+k).join(',')},notifications=excluded.notifications,photo=excluded.photo`,id,...fields.map(k=>p[k]||''),p.notifications===false?0:1,p.photo||'');
 for(const table of ['educations','student_skills','projects','complementary_courses','profile_languages'])await run(`DELETE FROM ${table} WHERE user_id=?`,id);
 for(const name of [...new Set(p.skills.map(s=>s.trim()).filter(Boolean))])await run('INSERT INTO student_skills VALUES(?,?) ON CONFLICT DO NOTHING',id,await skillId(name));
 for(const [position,e] of p.educations.entries())await run('INSERT INTO educations VALUES(?,?,?,?,?,?,?)',randomUUID(),id,e.course,e.institution,e.semester||'',e.period||'',position);
 for(const [position,e] of p.projectEntries.entries()){const pid=randomUUID();await run('INSERT INTO projects VALUES(?,?,?,?,?,?)',pid,id,e.title,e.description||'',e.link||'',position);for(const name of [...new Set(e.skills||[])])await run('INSERT INTO project_skills VALUES(?,?) ON CONFLICT DO NOTHING',pid,await skillId(name));}
 for(const [position,e] of p.courseEntries.entries())await run('INSERT INTO complementary_courses VALUES(?,?,?,?,?,?)',randomUUID(),id,e.title,e.institution||'',e.period||'',position);
 for(const [position,e] of p.languageEntries.entries())await run('INSERT INTO profile_languages VALUES(?,?,?,?,?)',randomUUID(),id,e.name,e.level||'',position);
});}
const jsonArray=(sql,pg,sl)=>postgres?`COALESCE((SELECT json_agg(x) FROM (${sql.replaceAll('{obj}',pg)}) x),'[]'::json)`:`COALESCE((SELECT json_group_array(json(obj)) FROM (${sql.replaceAll('{obj}',sl)}) x),'[]')`;
const parse=v=>typeof v==='string'?JSON.parse(v):v||[];
export async function readProfile(id){
 const d=await one(`SELECT d.*,
 ${jsonArray('SELECT {obj} FROM educations e WHERE e.user_id=d.user_id ORDER BY position',"e.course,e.institution,e.semester,e.period","json_object('course',e.course,'institution',e.institution,'semester',e.semester,'period',e.period) obj")} educations,
 ${jsonArray('SELECT {obj} FROM complementary_courses e WHERE e.user_id=d.user_id ORDER BY position',"e.title,e.institution,e.period","json_object('title',e.title,'institution',e.institution,'period',e.period) obj")} course_entries,
 ${jsonArray('SELECT {obj} FROM profile_languages e WHERE e.user_id=d.user_id ORDER BY position',"e.name,e.level","json_object('name',e.name,'level',e.level) obj")} language_entries,
 ${jsonArray('SELECT {obj} FROM skills s JOIN student_skills ss ON s.id=ss.skill_id WHERE ss.user_id=d.user_id ORDER BY s.name',"s.name","json_object('name',s.name) obj")} skills,
 ${jsonArray('SELECT {obj} FROM projects p WHERE p.user_id=d.user_id ORDER BY position',"p.id,p.title,p.description,p.link","json_object('id',p.id,'title',p.title,'description',p.description,'link',p.link) obj")} project_entries
 FROM student_details d WHERE d.user_id=?`,id);
 if(!d)return {...emptyProfile,educations:[],projectEntries:[],courseEntries:[],languageEntries:[],photo:'',guardianStatus:'unverified'};
 const e=parse(d.educations),pr=parse(d.project_entries);if(pr.length){const links=await all('SELECT ps.project_id,s.name FROM project_skills ps JOIN skills s ON s.id=ps.skill_id JOIN projects p ON p.id=ps.project_id WHERE p.user_id=?',id);for(const p of pr)p.skills=links.filter(x=>x.project_id===p.id).map(x=>x.name);}
 const courses=parse(d.course_entries),languages=parse(d.language_entries);
 return {city:d.city,interest:d.interest,objective:d.objective,availability:d.availability,modality:d.modality,experience:d.experience,phone:d.phone,visibility:d.visibility,notifications:Boolean(d.notifications),photo:d.photo,birthDate:d.birth_date||'',guardianEmail:d.guardian_email||'',guardianStatus:d.guardian_status,educations:e,projectEntries:pr,courseEntries:courses,languageEntries:languages,course:e[0]?.course||'',institution:e[0]?.institution||'',semester:e[0]?.semester||'',skills:parse(d.skills).map(x=>x.name),courses:courses.map(x=>[x.title,x.institution,x.period].filter(Boolean).join(' · ')).join('\n'),projects:pr.map(x=>[x.title,x.description,x.link].filter(Boolean).join(' · ')).join('\n'),languages:languages.map(x=>[x.name,x.level].filter(Boolean).join(' · ')).join('\n')};
}
export async function saveJob(id,j){await transaction(async()=>{const fields=['title','description','area','city','modality','deadline','activities','benefits','shift','salary','hours','experience','kind'];await run(`INSERT INTO job_details(job_id,${fields.join(',')}) VALUES(${Array(14).fill('?').join(',')}) ON CONFLICT(job_id) DO UPDATE SET ${fields.map(k=>k+'=excluded.'+k).join(',')}`,id,...fields.map(k=>k==='experience'?(j[k]?1:0):k==='kind'?(j[k]||'Estágio'):j[k]));await run('DELETE FROM job_courses WHERE job_id=?',id);await run('DELETE FROM job_skills WHERE job_id=?',id);for(const course of new Set(j.courses))await run('INSERT INTO job_courses VALUES(?,?)',id,course);for(const name of new Set(j.skills))await run('INSERT INTO job_skills VALUES(?,?) ON CONFLICT DO NOTHING',id,await skillId(name));});}
export async function readJobs(condition='',...params){const rows=await all(`SELECT j.id,j.company_id "companyId",j.status,c.name company,c.description "companyDescription",COALESCE(v.status,'Pendente') verification,d.*,
 ${jsonArray('SELECT {obj} FROM job_courses e WHERE e.job_id=j.id ORDER BY course',"e.course","json_object('course',e.course) obj")} courses,
 ${jsonArray('SELECT {obj} FROM skills s JOIN job_skills js ON s.id=js.skill_id WHERE js.job_id=j.id ORDER BY name',"s.name","json_object('name',s.name) obj")} skills
 FROM jobs j JOIN job_details d ON d.job_id=j.id JOIN companies c ON c.id=j.company_id LEFT JOIN company_verifications v ON v.company_id=c.id ${condition}`, ...params);return rows.map(({job_id,...j})=>({...j,id:Number(j.id),companyId:Number(j.companyId),experience:Boolean(j.experience),courses:parse(j.courses).map(x=>x.course),skills:parse(j.skills).map(x=>x.name)}));}
export async function migrateNormalized(){
 if(sqlite)sqlite.exec(readFileSync(new URL('./migrations/003-normalized.sql',import.meta.url),'utf8'));
 if(await one("SELECT name FROM schema_migrations WHERE name='003-backfill'"))return;
 await transaction(async()=>{
  if(postgres)await run('SELECT pg_advisory_xact_lock(?)',20261003);
  if(await one("SELECT name FROM schema_migrations WHERE name='003-backfill'"))return;
  for(const row of await all('SELECT p.user_id,p.data FROM profiles p LEFT JOIN student_details d ON d.user_id=p.user_id WHERE d.user_id IS NULL'))await saveProfile(row.user_id,JSON.parse(row.data));
  for(const row of await all('SELECT j.id,j.data FROM jobs j LEFT JOIN job_details d ON d.job_id=j.id WHERE d.job_id IS NULL'))await saveJob(row.id,JSON.parse(row.data));
  for(const r of await all('SELECT user_id,company_id FROM recruiters ORDER BY company_id,user_id')){const owner=!(await one('SELECT user_id FROM recruiter_memberships WHERE company_id=?',r.company_id));await run('INSERT INTO recruiter_memberships VALUES(?,?,?,?) ON CONFLICT DO NOTHING',r.user_id,r.company_id,owner?'owner':'recruiter','active');}
  for(const h of await all('SELECT id,application_id,status FROM history ORDER BY id')){const p=await one('SELECT status FROM history WHERE application_id=? AND id<? ORDER BY id DESC LIMIT 1',h.application_id,h.id);await run('INSERT INTO history_previous VALUES(?,?) ON CONFLICT DO NOTHING',h.id,p?.status||null);}
  await run('INSERT INTO schema_migrations VALUES(?,?)','003-backfill',new Date().toISOString());
 });
}
