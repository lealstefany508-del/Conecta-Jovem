import {db,run,one,all,transaction} from './db.js';
if(db)db.exec(`CREATE TABLE IF NOT EXISTS external_jobs(source TEXT,source_id TEXT,data TEXT,updated INTEGER,PRIMARY KEY(source,source_id));
CREATE TABLE IF NOT EXISTS integrations(source TEXT PRIMARY KEY,last_success INTEGER,last_attempt INTEGER,error TEXT);
CREATE TABLE IF NOT EXISTS external_favorites(user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,source TEXT,source_id TEXT,PRIMARY KEY(user_id,source,source_id));
PRAGMA user_version=2;`);
const sources=new Set(['adzuna.com.br','www.adzuna.com.br']);
const text=s=>String(s||'').replace(/<[^>]*>/g,' ').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/\s+/g,' ').trim();
export function normalizeAdzuna(item,now=Date.now()){
 if(!item.id||!item.title||!item.company?.display_name||!item.redirect_url)return null;
 const title=text(item.title);const normalized=title.normalize('NFD').replace(/\p{Diacritic}/gu,'').toLowerCase();
 if(!/(?:^|\W)(estagio|estagiari[oa]|aprendiz)(?:\W|$)/.test(normalized))return null;
 let url;try{url=new URL(item.redirect_url);}catch{return null;}if(!['http:','https:'].includes(url.protocol)||!sources.has(url.hostname)||url.username||url.password)return null;
 return {id:String(item.id),title,company:text(item.company.display_name),city:text(item.location?.display_name)||'Localização não informada',area:!item.category?.label||item.category.label==='Unknown'?'Área não informada':text(item.category.label),description:text(item.description).slice(0,6000),url:url.href,source:'Adzuna',created:item.created||null,updated:now};
}
export const configured=()=>Boolean(process.env.ADZUNA_APP_ID&&process.env.ADZUNA_APP_KEY);
export async function integrationStatus(){const r=await one("SELECT * FROM integrations WHERE source='Adzuna'");return {source:'Adzuna',configured:configured(),lastSuccess:Number(r?.last_success)||null,lastAttempt:Number(r?.last_attempt)||null,error:r?.error||null,count:Number((await one("SELECT count(*) count FROM external_jobs WHERE source='Adzuna' AND updated>?",Date.now()-86400000)).count)};}
export const externalJobs=async()=>configured()?(await all("SELECT data FROM external_jobs WHERE source='Adzuna' AND updated>? ORDER BY updated DESC",Date.now()-86400000)).map(r=>JSON.parse(r.data)):[];
let running=false;
export async function syncAdzuna({fetcher=fetch,now=Date.now()}={}){
 if(!configured())throw new Error('Configure ADZUNA_APP_ID e ADZUNA_APP_KEY no .env e reinicie o servidor.');
 if(running)throw new Error('Uma sincronização já está em andamento.');
 running=true;
 try{
  const claimed=await run("INSERT INTO integrations(source,last_attempt,error) VALUES('Adzuna',?,NULL) ON CONFLICT(source) DO UPDATE SET last_attempt=excluded.last_attempt,error=NULL WHERE integrations.last_attempt IS NULL OR integrations.last_attempt<=?",now,now-3600000);
  if(!claimed.changes)throw new Error('Aguarde uma hora entre sincronizações para respeitar os limites da fonte.');
  const records=new Map();
  for(const query of ['estágio','aprendiz']){
   const url=new URL('https://api.adzuna.com/v1/api/jobs/br/search/1');url.search=new URLSearchParams({app_id:process.env.ADZUNA_APP_ID,app_key:process.env.ADZUNA_APP_KEY,what:query,results_per_page:'50',sort_by:'date',max_days_old:'30','content-type':'application/json',...(process.env.ADZUNA_LOCATION?{where:process.env.ADZUNA_LOCATION}:{})}).toString();
   let response;try{response=await fetcher(url,{headers:{Accept:'application/json'},signal:AbortSignal.timeout(15000)});}catch{throw new Error('A fonte não respondeu. Verifique a conexão e tente novamente mais tarde.');}
   if(!response.ok)throw new Error(response.status===401||response.status===403?'A fonte recusou as credenciais. Confira o app_id e app_key.':response.status===429?'Limite de consultas da fonte atingido. Aguarde antes de sincronizar.':`A fonte retornou erro HTTP ${response.status}.`);
   let payload;try{payload=await response.json();}catch{throw new Error('Resposta inválida da fonte.');}if(!Array.isArray(payload.results))throw new Error('Formato de resposta inesperado da fonte.');
   for(const item of payload.results){const row=normalizeAdzuna(item,now);if(row)records.set(row.id,row);}
  }
  await transaction(async()=>{await run("DELETE FROM external_jobs WHERE source='Adzuna'");for(const j of records.values())await run('INSERT INTO external_jobs VALUES(?,?,?,?)','Adzuna',j.id,JSON.stringify(j),now);await run("UPDATE integrations SET last_success=?,error=NULL WHERE source='Adzuna'",now);});
  return {count:records.size};
 }catch(e){const message=e.message;if(!message.includes('uma hora'))await run("UPDATE integrations SET error=? WHERE source='Adzuna'",message);throw new Error(message);}finally{running=false;}
}
