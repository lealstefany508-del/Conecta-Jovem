import {DatabaseSync} from 'node:sqlite';
import {mkdirSync} from 'node:fs';
import {scryptSync,randomBytes} from 'node:crypto';
mkdirSync('data',{recursive:true});
export const db=new DatabaseSync(process.env.DB_PATH||'data/conecta.sqlite');
db.exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL,active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS profiles(user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS companies(id INTEGER PRIMARY KEY,name TEXT NOT NULL,city TEXT,description TEXT,identifier TEXT);
CREATE TABLE IF NOT EXISTS recruiters(user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,company_id INTEGER REFERENCES companies(id),PRIMARY KEY(user_id,company_id));
CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY,company_id INTEGER REFERENCES companies(id),data TEXT NOT NULL,status TEXT DEFAULT 'Aberta');
CREATE TABLE IF NOT EXISTS applications(id INTEGER PRIMARY KEY,user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,job_id INTEGER REFERENCES jobs(id),status TEXT DEFAULT 'Enviada',created TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(user_id,job_id));
CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY,application_id INTEGER REFERENCES applications(id) ON DELETE CASCADE,author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,status TEXT,reason TEXT,created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY,user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,message TEXT,read INTEGER DEFAULT 0,created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS favorites(user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,job_id INTEGER REFERENCES jobs(id),PRIMARY KEY(user_id,job_id));
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,expires INTEGER);
CREATE TABLE IF NOT EXISTS resets(token TEXT PRIMARY KEY,user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,expires INTEGER);
CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY,user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,job_id INTEGER REFERENCES jobs(id),reason TEXT,status TEXT DEFAULT 'Pendente');
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,action TEXT,reason TEXT,created TEXT DEFAULT CURRENT_TIMESTAMP);
PRAGMA user_version=1;`);
export function hash(password){const salt=randomBytes(16).toString('hex');return salt+':'+scryptSync(password,salt,64).toString('hex');}
export const emptyProfile={city:'',course:'',institution:'',semester:'',interest:'',objective:'',availability:'',modality:'',skills:[],languages:'',courses:'',projects:'',experience:'',phone:'',visibility:'Candidaturas',notifications:true};
if(!db.prepare("SELECT id FROM users WHERE role='admin'").get()) {
 const password=process.env.ADMIN_PASSWORD||randomBytes(18).toString('base64url');
 const email=process.env.ADMIN_EMAIL||'admin@conecta.local';
 db.prepare("INSERT INTO users(name,email,password,role) VALUES(?,?,?,'admin')").run('Administrador',email,hash(password));
 console.log('Administrador inicial:',email,'Senha:',password,'(guarde esta credencial; exibida apenas na criação)');
}
