import {ImapFlow} from 'imapflow';
import {simpleParser} from 'mailparser';
import {decryptSnapshot,operationalEmail} from './operations.js';
import {readdirSync,lstatSync,readFileSync,unlinkSync} from 'node:fs';
import {resolve,join} from 'node:path';

const dayMs=86400000;
export function verifyBackupMail(mail,{email,key,now=new Date()}={}){
 const match=/^\[Conecta backup\] (\d{4}-\d{2}-\d{2})$/.exec(mail.subject||'');
 if(!match||mail.from?.value?.length!==1||mail.from.value[0].address!==email||mail.to?.value?.length!==1||mail.to.value[0].address!==email||mail.attachments?.length!==1)return null;
 const attachment=mail.attachments[0];if(attachment.filename!==`conecta-${match[1]}.backup.json`)return null;
 try{const envelope=JSON.parse(attachment.content.toString());if(envelope.format!=='conecta-backup'||envelope.version!==2)return null;const snapshot=decryptSnapshot(attachment.content,key),created=Date.parse(snapshot.created);if(!Number.isFinite(created)||created>now.getTime()||new Date(created).toISOString().slice(0,10)!==match[1])return null;return {day:match[1],created};}catch{return null;}
}
export function pruneLocalBackups({directory='data/backups',key=process.env.BACKUP_ENCRYPTION_KEY,now=new Date()}={}){
 const root=resolve(directory);let entries;try{entries=readdirSync(root);}catch(e){if(e.code==='ENOENT')return {removed:0};throw e;}
 const verified=[];
 for(const name of entries){if(!/^postgres-\d{4}-\d{2}-\d{2}T[\d-]+Z\.backup\.json$/.test(name))continue;const file=join(root,name),stat=lstatSync(file);if(!stat.isFile()||stat.isSymbolicLink())continue;try{const bytes=readFileSync(file),envelope=JSON.parse(bytes.toString());if(envelope.format!=='conecta-backup'||envelope.version!==2)continue;const snapshot=decryptSnapshot(bytes,key),created=Date.parse(snapshot.created);if(Number.isFinite(created)&&created<=now.getTime())verified.push({file,created});}catch{}}
 if(!verified.some(b=>b.created>=now.getTime()-2*dayMs))return {removed:0,skipped:'no-recent-verified-backup'};
 let removed=0;for(const item of verified)if(item.created<now.getTime()-7*dayMs){unlinkSync(item.file);removed++;}return {removed};
}
export async function retainGmailBackups({env=process.env,now=new Date(),dryRun=false,client,parser=simpleParser}={}){
 const email=operationalEmail(env),key=env.BACKUP_ENCRYPTION_KEY;
 if(!/^[a-f0-9]{64}$/i.test(key||''))throw new Error('Chave de backup inválida.');
 if(!client)client=new ImapFlow({host:'imap.gmail.com',port:993,secure:true,auth:{user:email,pass:(env.SMTP_PASSWORD||'').replace(/\s/g,'')},logger:false,connectionTimeout:15000,socketTimeout:20000});
 let moved=0,deleted=0,verifiedRecent=0;
 try{
  await client.connect();if(!client.capabilities.has('UIDPLUS'))throw new Error('Limpeza requer exclusão seletiva por UID.');
  const boxes=await client.list(),all=boxes.find(b=>b.specialUse==='\\All'),trash=boxes.find(b=>b.specialUse==='\\Trash');if(!all||!trash)throw new Error('Pastas Gmail necessárias não encontradas.');
  async function collect(path){const lock=await client.getMailboxLock(path);try{const ids=(await client.search({from:email,to:email,subject:'[Conecta backup]'},{uid:true})).slice(-200);const result=[];for(const uid of ids){const metadata=await client.fetchOne(uid,{size:true,internalDate:true},{uid:true});if(!metadata||metadata.size>25*1024*1024)continue;const raw=await client.fetchOne(uid,{source:true},{uid:true});if(!raw?.source)continue;const proof=verifyBackupMail(await parser(raw.source,{skipHtmlToText:true,skipTextToHtml:true}),{email,key,now});if(proof)result.push({uid,...proof,received:metadata.internalDate?.getTime()});}return result;}finally{lock.release();}}
  const backups=await collect(all.path);verifiedRecent=backups.filter(b=>b.created>=now.getTime()-2*dayMs).length;
  if(!verifiedRecent)return {verifiedRecent:0,moved:0,deleted:0,skipped:'no-recent-verified-backup'};
  const expired=b=>b.created<now.getTime()-7*dayMs&&Number.isFinite(b.received)&&b.received<now.getTime()-7*dayMs;
  const old=backups.filter(expired);
  if(!dryRun){const lock=await client.getMailboxLock(all.path);try{for(const b of old){if(!await client.messageMove(b.uid,trash.path,{uid:true}))throw new Error('Movimentação do backup não confirmada.');moved++;}}finally{lock.release();}}
  const trashBackups=(await collect(trash.path)).filter(expired);
  if(!dryRun){const lock=await client.getMailboxLock(trash.path);try{for(const b of trashBackups){if(!await client.messageDelete(b.uid,{uid:true}))throw new Error('Exclusão do backup não confirmada.');deleted++;}}finally{lock.release();}}
  return {verifiedRecent,moved,deleted,dryRun,expired:old.length+trashBackups.length};
 }finally{await client.logout().catch(()=>{});}
}
