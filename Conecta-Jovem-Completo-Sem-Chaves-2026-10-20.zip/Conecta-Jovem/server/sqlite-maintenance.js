import {DatabaseSync} from 'node:sqlite';
import {randomBytes,scryptSync} from 'node:crypto';
import {mkdirSync,existsSync} from 'node:fs';
import path from 'node:path';
const command=process.argv[2],filename=process.env.DB_PATH||'data/conecta.sqlite';
if(!existsSync(filename))throw new Error('Banco ainda não criado. Execute npm run dev primeiro.');
const db=new DatabaseSync(filename);db.exec('PRAGMA foreign_keys=ON');
if(command==='backup'){
 mkdirSync('data/backups',{recursive:true});const file=path.resolve('data/backups/conecta-'+new Date().toISOString().replace(/[:.]/g,'-')+'.sqlite');db.prepare('VACUUM INTO ?').run(file);const copy=new DatabaseSync(file);if(copy.prepare('PRAGMA integrity_check').get().integrity_check!=='ok')throw new Error('Falha de integridade no backup.');copy.close();console.log('Backup validado:',file);
}else if(command==='check'){
 console.log('Integridade:',db.prepare('PRAGMA integrity_check').get());console.log('Chaves estrangeiras:',db.prepare('PRAGMA foreign_key_check').all());
}else if(command==='admin'){
 const email=process.argv[3]||'admin@conecta.local';const password=randomBytes(18).toString('base64url');const salt=randomBytes(16).toString('hex');const passwordHash=salt+':'+scryptSync(password,salt,64).toString('hex');const u=db.prepare("SELECT id FROM users WHERE email=? AND role='admin'").get(email);if(!u)throw new Error('Administrador não encontrado.');db.prepare('UPDATE users SET password=? WHERE id=?').run(passwordHash,u.id);db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id);console.log('Nova senha administrativa:',password,'Guarde-a em um gerenciador de senhas.');
}else throw new Error('Use backup, check ou admin.');
db.close();
