export function validationError(fields,message='Revise os campos indicados.'){const e=new Error(message);e.status=422;e.fields=fields;throw e;}
export function validateProfile(p){const errors={};const text=(v,max=5000)=>typeof v==='string'&&v.length<=max;
 const primary=p.educations?.[0]||p;for(const k of ['course','institution'])if(!String(primary[k]||'').trim())errors[k]='Campo obrigatório.';
 for(const k of ['city','availability','modality'])if(!String(p[k]||'').trim())errors[k]='Campo obrigatório.';
 if(p.availability&&!['Manhã','Tarde','Noite','Qualquer turno'].includes(p.availability))errors.availability='Selecione uma disponibilidade válida.';
 if(p.modality&&!['Todas','Remoto','Híbrido','Presencial'].includes(p.modality))errors.modality='Selecione uma modalidade válida.';
 for(const k of ['city','interest','objective','availability','modality','experience','phone'])if(!text(p[k]||''))errors[k]='Texto inválido ou muito longo.';
 if(!Array.isArray(p.skills)||p.skills.length>50||p.skills.some(s=>!text(s,80)||!s.trim()))errors.skills='Informe até 50 habilidades de até 80 caracteres.';
 if(typeof p.notifications!=='boolean')errors.notifications='Selecione uma preferência válida.';
 const collections={educations:['course','institution','semester','period'],projectEntries:['title','description','link'],courseEntries:['title','institution','period'],languageEntries:['name','level']};
 for(const [key,fields] of Object.entries(collections)){if(p[key]===undefined)continue;if(!Array.isArray(p[key])||p[key].length>20){errors[key]='Informe até 20 itens.';continue;}for(const [i,e] of p[key].entries()){if(!e||typeof e!=='object'){errors[key]='Item inválido.';continue;}for(const f of fields)if(!text(e[f]||''))errors[`${key}.${i}.${f}`]='Texto inválido ou muito longo.';const required=key==='educations'?['course','institution']:key==='languageEntries'?['name']:['title'];for(const f of required)if(!String(e[f]||'').trim())errors[`${key}.${i}.${f}`]='Campo obrigatório.';if(key==='projectEntries'){if(!Array.isArray(e.skills)||e.skills.length>50||e.skills.some(s=>!text(s,80)||!s.trim()))errors[`${key}.${i}.skills`]='Habilidades inválidas.';if(e.link){try{const u=new URL(e.link);if(!['https:','http:'].includes(u.protocol)||u.username||u.password)throw Error();}catch{errors[`${key}.${i}.link`]='Use um link HTTP ou HTTPS válido.';}}}}}
 if(p.photo){if(typeof p.photo!=='string'||p.photo.length>110000||!/^data:image\/(jpeg|png);base64,[A-Za-z0-9+/]+=*$/.test(p.photo))errors.photo='Use uma imagem JPEG ou PNG de até 80 KB.';else{const b=Buffer.from(p.photo.split(',')[1],'base64');if(b.length>81920||!(b.subarray(0,3).equals(Buffer.from([255,216,255]))||b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))))errors.photo='Formato de imagem inválido.';}}
 if(!['Candidaturas','Público','Privado'].includes(p.visibility))errors.visibility='Selecione uma visibilidade válida.';
 if(Object.keys(errors).length)validationError(errors);
}
