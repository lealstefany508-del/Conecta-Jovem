export {run,one,all,transaction,close,postgres,pool,sqlite as db} from './store.js';
import {scryptSync,randomBytes} from 'node:crypto';
export function hash(password){const salt=randomBytes(16).toString('hex');return salt+':'+scryptSync(password,salt,64).toString('hex');}
export const emptyProfile={city:'',course:'',institution:'',semester:'',interest:'',objective:'',availability:'',modality:'',skills:[],languages:'',courses:'',projects:'',experience:'',phone:'',visibility:'Candidaturas',notifications:true};
