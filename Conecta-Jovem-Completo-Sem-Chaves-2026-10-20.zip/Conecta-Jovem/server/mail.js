import nodemailer from 'nodemailer';
export async function sendMessage(to,subject,text,{attachments=[]}={}){
 if(!mailConfigured())throw new Error('E-mail indisponível.');
 if(smtpConfigured()){const port=Number(process.env.SMTP_PORT||465);const transport=nodemailer.createTransport({host:process.env.SMTP_HOST,port,secure:port===465,requireTLS:port===587,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASSWORD},connectionTimeout:10000,greetingTimeout:10000,socketTimeout:15000});try{const result=await transport.sendMail({from:process.env.EMAIL_FROM||process.env.SMTP_USER,to,subject,text,attachments});if(!result.accepted?.includes(to)||result.rejected?.length)throw Error();}catch{throw new Error('Envio não confirmado.');}finally{transport.close();}return true;}
 const response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${process.env.RESEND_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({from:process.env.EMAIL_FROM,to:[to],subject,text,attachments:attachments.map(a=>({filename:a.filename,content:Buffer.from(a.content).toString('base64')}))}),signal:AbortSignal.timeout(15000)});if(!response.ok||!(await response.json()).id)throw new Error('Envio não confirmado.');return true;
}
export const smtpConfigured=()=>Boolean(process.env.SMTP_HOST&&process.env.SMTP_USER&&process.env.SMTP_PASSWORD);
export const mailConfigured=()=>Boolean(process.env.APP_PUBLIC_URL&&(smtpConfigured()||(process.env.RESEND_API_KEY&&process.env.EMAIL_FROM)));
export async function sendRecovery(email,token,{fetcher=fetch,transportFactory=nodemailer.createTransport}={}){
 if(!mailConfigured())return false;
 let base;try{base=new URL(process.env.APP_PUBLIC_URL);}catch{throw new Error('URL pública do aplicativo inválida.');}
 if(base.protocol!=='https:'&&!['localhost','127.0.0.1'].includes(base.hostname))throw new Error('Configure uma URL pública com HTTPS.');
 const link=new URL('/',base);link.searchParams.set('reset',token);
 const message={from:process.env.EMAIL_FROM||process.env.SMTP_USER,to:email,subject:'Recupere seu acesso · Conecta Jovem',text:`Você solicitou uma nova senha no Conecta Jovem. Acesse o link em até 15 minutos: ${link.href}\n\nSe não foi você, ignore esta mensagem.`};
 if(smtpConfigured()){
  const port=Number(process.env.SMTP_PORT||465);if(![465,587].includes(port))throw new Error('Configure a porta SMTP 465 ou 587.');
  const transport=transportFactory({host:process.env.SMTP_HOST,port,secure:port===465,requireTLS:port===587,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASSWORD},connectionTimeout:10000,greetingTimeout:10000,socketTimeout:15000});
  try{const sent=await transport.sendMail(message);if(!sent.accepted?.includes(email)||sent.rejected?.length)throw new Error('Destinatário não aceito.');return true;}catch{throw new Error('O servidor SMTP não confirmou o envio. Verifique a conta e a senha de app.');}finally{transport.close?.();}
 }
 let response;try{response=await fetcher('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${process.env.RESEND_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({from:process.env.EMAIL_FROM,to:[email],subject:'Recupere seu acesso · Conecta Jovem',text:`Você solicitou uma nova senha no Conecta Jovem. Acesse o link em até 15 minutos: ${link.href}\n\nSe não foi você, ignore esta mensagem.`}),signal:AbortSignal.timeout(15000)});}catch{throw new Error('O provedor de e-mail não respondeu.');}
 if(!response.ok)throw new Error('O provedor recusou o envio. Verifique a configuração do e-mail.');
 const payload=await response.json();if(!payload.id)throw new Error('O provedor não confirmou o envio do e-mail.');return true;
}
