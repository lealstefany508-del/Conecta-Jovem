import './env.js';
if(!process.env.DATABASE_URL||process.env.DB_PATH){await import('./sqlite-maintenance.js');}
else{
 const {pool,all,one,run,transaction,close,hash}=await import('./db.js');
 const {mkdirSync,writeFileSync,readFileSync}=await import('node:fs');
 const {randomBytes}=await import('node:crypto');
 const command=process.argv[2];
 try{
  if(command==='backup'){
   const {createSnapshot,encryptSnapshot,decryptSnapshot}=await import('./operations.js');const client=await pool.connect();let backup;try{backup=await createSnapshot(client);}finally{client.release();}
   mkdirSync('data/backups',{recursive:true});const file='data/backups/postgres-'+new Date().toISOString().replace(/[:.]/g,'-')+(process.env.BACKUP_ENCRYPTION_KEY?'.backup.json':'.json');writeFileSync(file,process.env.BACKUP_ENCRYPTION_KEY?encryptSnapshot(backup):JSON.stringify(backup),{mode:0o600});const verified=decryptSnapshot(readFileSync(file));for(const table of Object.keys(backup.data))if(verified.data[table].length!==backup.data[table].length)throw new Error('Contagem inválida: '+table);const {pruneLocalBackups}=await import('./backup-retention.js');const retention=pruneLocalBackups();console.log('Snapshot PostgreSQL validado:',file,'· vencidos removidos:',retention.removed);
  }else if(command==='check'){console.log({database:'PostgreSQL',connected:Boolean((await one('SELECT 1 ok')).ok),users:Number((await one('SELECT count(*) count FROM users')).count),realExternalJobs:Number((await one('SELECT count(*) count FROM external_jobs')).count)});}
  else if(command==='admin'){const email=process.argv[3]||'admin@conecta.local',password=randomBytes(18).toString('base64url');const user=await one("SELECT id FROM users WHERE email=? AND role='admin'",email);if(!user)throw new Error('Administrador não encontrado.');await transaction(async()=>{await run('UPDATE users SET password=? WHERE id=?',hash(password),user.id);await run('DELETE FROM sessions WHERE user_id=?',user.id);});console.log('Nova senha administrativa:',password);}
  else throw new Error('Use backup, check ou admin.');
 }finally{await close();}
}
